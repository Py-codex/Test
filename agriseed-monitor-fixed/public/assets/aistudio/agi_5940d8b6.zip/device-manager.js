/**
 * device-manager.js
 * ----------------------------------------------------------------------------
 * Manages ESP32 chamber registration, device-key authentication, ownership
 * binding, sensor payload validation, and requested-vs-acknowledged config
 * reconciliation.
 */

import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import { nowUtc } from './db.js';
import { raiseAlertWithCooldown } from './controller.js';

// Short-lived in-memory cache of verified (deviceId + sha256(rawKey) -> device_key_hash)
// so 5-second local ESP32 polls remain lightweight while SQLite stores only bcrypt hashes.
const verifiedKeyCache = new Map();

function makeCacheToken(deviceId, rawKey, keyHash) {
  const digest = crypto.createHash('sha256').update(`${deviceId}:${rawKey}`).digest('hex');
  return `${digest}:${keyHash}`;
}

export function verifyDeviceCredentials(db, deviceId, rawKey) {
  if (typeof deviceId !== 'string' || !deviceId.trim() || typeof rawKey !== 'string' || !rawKey) {
    return null;
  }
  const cleanId = deviceId.trim();
  const device = db.prepare('SELECT * FROM devices WHERE id = ?').get(cleanId);
  if (!device) {
    return null;
  }

  const cacheToken = makeCacheToken(cleanId, rawKey, device.device_key_hash);
  if (verifiedKeyCache.has(cacheToken)) {
    return device;
  }

  const ok = bcrypt.compareSync(rawKey, device.device_key_hash);
  if (!ok) {
    return null;
  }

  if (verifiedKeyCache.size > 200) {
    verifiedKeyCache.clear();
  }
  verifiedKeyCache.set(cacheToken, true);
  return device;
}

/**
 * Ensures a newly registered user has a chamber bound to their account:
 * - If the default `chamber-01` is not yet claimed by any user, bind it to this
 *   first farmer so `simulate.js` and `seed_chamber.ino` work out of the box.
 * - Subsequent users receive their own isolated chamber (`chamber-u<id>`) so
 *   users never share or view another user's chamber, batches, or alerts.
 */
export function ensureUserHasChamber(db, userId) {
  const existingOwned = db
    .prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY created_at ASC LIMIT 1')
    .get(userId);
  if (existingOwned) {
    return existingOwned;
  }

  const defaultId = (process.env.DEFAULT_DEVICE_ID || 'chamber-01').trim();
  const claimResult = db
    .prepare('UPDATE devices SET user_id = ? WHERE id = ? AND user_id IS NULL')
    .run(userId, defaultId);

  if (claimResult.changes > 0) {
    return db.prepare('SELECT * FROM devices WHERE id = ?').get(defaultId);
  }

  // Create an isolated chamber for additional user accounts
  const newDeviceId = `chamber-u${userId}`;
  const generatedKey = crypto.randomBytes(12).toString('hex');
  const keyHash = bcrypt.hashSync(generatedKey, 10);
  const now = nowUtc();

  const createTx = db.transaction(() => {
    db.prepare(`
      INSERT INTO devices (id, user_id, device_key_hash, device_name, status, created_at)
      VALUES (?, ?, ?, ?, 'offline', ?)
    `).run(newDeviceId, userId, keyHash, `Seed Chamber (${newDeviceId})`, now);

    db.prepare(`
      INSERT INTO device_config (
        device_id, target_temp, temp_min, temp_max,
        cooling_on_temp, cooling_off_temp,
        fan_min_percent, fan_max_percent, manual_fan_percent,
        control_mode, manual_expires_at, config_version, updated_at
      ) VALUES (?, 17.5, 15.0, 20.0, 18.2, 16.8, 25, 85, 45, 'auto', NULL, 1, ?)
    `).run(newDeviceId, now);
  });
  createTx();

  return db.prepare('SELECT * FROM devices WHERE id = ?').get(newDeviceId);
}

export function registerNewDevice(db, { userId, deviceId, deviceName, deviceKey }) {
  const cleanId = String(deviceId || '').trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9-_]{2,31}$/.test(cleanId)) {
    return {
      ok: false,
      error: 'Device ID must be 3–32 characters using lowercase letters, numbers, hyphens, or underscores.'
    };
  }
  const cleanName = String(deviceName || '').trim();
  if (cleanName.length < 2 || cleanName.length > 60) {
    return { ok: false, error: 'Device name must be between 2 and 60 characters.' };
  }
  const rawKey = String(deviceKey || '').trim();
  if (rawKey.length < 8 || rawKey.length > 128) {
    return { ok: false, error: 'Device key must be between 8 and 128 characters.' };
  }

  const exists = db.prepare('SELECT id FROM devices WHERE id = ?').get(cleanId);
  if (exists) {
    return { ok: false, error: 'A device with that ID is already registered.' };
  }

  const now = nowUtc();
  const keyHash = bcrypt.hashSync(rawKey, 10);

  const tx = db.transaction(() => {
    db.prepare(`
      INSERT INTO devices (id, user_id, device_key_hash, device_name, status, created_at)
      VALUES (?, ?, ?, ?, 'offline', ?)
    `).run(cleanId, userId, keyHash, cleanName, now);

    db.prepare(`
      INSERT INTO device_config (
        device_id, target_temp, temp_min, temp_max,
        cooling_on_temp, cooling_off_temp,
        fan_min_percent, fan_max_percent, manual_fan_percent,
        control_mode, manual_expires_at, config_version, updated_at
      ) VALUES (?, 17.5, 15.0, 20.0, 18.2, 16.8, 25, 85, 45, 'auto', NULL, 1, ?)
    `).run(cleanId, now);
  });
  tx();

  return {
    ok: true,
    device: db.prepare('SELECT id, user_id, device_name, status, created_at FROM devices WHERE id = ?').get(cleanId)
  };
}

/**
 * Strictly validates incoming sensor readings from ESP32 / simulator.
 * Physical DHT22 bounds: -40 to +80 °C, 0 to 100% RH.
 */
export function validateIncomingReading(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return { valid: false, error: 'Request body must be a JSON object.' };
  }

  const sensorOk = body.sensor_ok === undefined ? true : Boolean(body.sensor_ok);

  let temp = null;
  let humidity = null;

  if (sensorOk) {
    temp = Number(body.temp);
    humidity = Number(body.humidity);

    if (!Number.isFinite(temp) || temp < -40 || temp > 80) {
      return {
        valid: false,
        error: 'Invalid temperature reading: must be a finite number between -40 °C and 80 °C.'
      };
    }
    if (!Number.isFinite(humidity) || humidity < 0 || humidity > 100) {
      return {
        valid: false,
        error: 'Invalid humidity reading: must be a finite number between 0% and 100%.'
      };
    }
    temp = Number(temp.toFixed(2));
    humidity = Number(humidity.toFixed(2));
  }

  const fanSpeedPercent = Number(body.fan_speed_percent);
  if (!Number.isFinite(fanSpeedPercent) || fanSpeedPercent < 0 || fanSpeedPercent > 100) {
    return {
      valid: false,
      error: 'Invalid fan_speed_percent: must be a finite number between 0 and 100.'
    };
  }

  let fanRpm = null;
  if (body.fan_rpm !== null && body.fan_rpm !== undefined && body.fan_rpm !== '') {
    const parsedRpm = Number(body.fan_rpm);
    if (!Number.isFinite(parsedRpm) || parsedRpm < 0 || parsedRpm > 15000) {
      return {
        valid: false,
        error: 'Invalid fan_rpm: must be null or an integer between 0 and 15000.'
      };
    }
    fanRpm = Math.round(parsedRpm);
  }

  if (typeof body.cooling_on !== 'boolean' && body.cooling_on !== 0 && body.cooling_on !== 1) {
    return {
      valid: false,
      error: 'Invalid cooling_on: must be boolean or 0/1.'
    };
  }

  const coolingOn = body.cooling_on ? 1 : 0;
  const isSimulated = body.is_simulated ? 1 : 0;

  return {
    valid: true,
    value: {
      temp,
      humidity,
      fan_speed_percent: Number(fanSpeedPercent.toFixed(1)),
      fan_rpm: fanRpm,
      cooling_on: coolingOn,
      sensor_ok: sensorOk ? 1 : 0,
      is_simulated: isSimulated,
      applied_config:
        body.applied_config && typeof body.applied_config === 'object'
          ? body.applied_config
          : null,
      diagnostics:
        body.diagnostics && typeof body.diagnostics === 'object'
          ? body.diagnostics
          : null
    }
  };
}

/**
 * Records device status/config acknowledgement and raises `config_rejected`
 * alert if the ESP32 reports rejecting a configuration update.
 */
export async function recordDeviceStatusUpdate(db, device, payload = {}) {
  const now = nowUtc();
  const statusValue = payload.sensor_ok === false ? 'fault' : 'online';

  let ackJson = device.acknowledged_config_json;
  let lastAckAt = device.last_ack_at;
  if (payload.applied_config && typeof payload.applied_config === 'object') {
    ackJson = JSON.stringify(payload.applied_config);
    lastAckAt = now;
  }

  let diagJson = device.diagnostics_json;
  if (payload.diagnostics && typeof payload.diagnostics === 'object') {
    diagJson = JSON.stringify(payload.diagnostics);
  }

  db.prepare(`
    UPDATE devices
    SET status = ?, last_seen_at = ?, acknowledged_config_json = ?, last_ack_at = ?, diagnostics_json = ?
    WHERE id = ?
  `).run(statusValue, now, ackJson, lastAckAt, diagJson, device.id);

  if (payload.config_rejected && device.user_id) {
    const reason =
      typeof payload.rejection_reason === 'string' && payload.rejection_reason.trim()
        ? payload.rejection_reason.trim().slice(0, 200)
        : 'ESP32 rejected received parameters during local safety check.';
    await raiseAlertWithCooldown(db, {
      userId: device.user_id,
      deviceId: device.id,
      kind: 'config_rejected',
      message: `Configuration rejected by ${device.id}: ${reason}`
    });
  }
}

export function computeDeviceConnectivity(device) {
  const offlineThresholdSec = Math.max(10, Number(process.env.DEVICE_OFFLINE_SECONDS || 30));
  if (!device || !device.last_seen_at) {
    return {
      is_online: false,
      is_stale: true,
      seconds_since_seen: null,
      offline_threshold_sec: offlineThresholdSec
    };
  }
  const seenMs = Date.parse(device.last_seen_at);
  const ageSec = Number.isNaN(seenMs) ? null : Math.max(0, Math.round((Date.now() - seenMs) / 1000));
  const isOnline = ageSec !== null && ageSec <= offlineThresholdSec;
  return {
    is_online: isOnline,
    is_stale: !isOnline,
    seconds_since_seen: ageSec,
    offline_threshold_sec: offlineThresholdSec
  };
}

export function isConfigAcknowledged(configRow, deviceRow) {
  if (!configRow || !deviceRow || !deviceRow.acknowledged_config_json) {
    return { synced: false, acknowledged: null };
  }
  try {
    const ack = JSON.parse(deviceRow.acknowledged_config_json);
    const synced =
      Number(ack.config_version) === Number(configRow.config_version) ||
      (Number(ack.target_temp) === Number(configRow.target_temp) &&
        Number(ack.temp_min) === Number(configRow.temp_min) &&
        Number(ack.temp_max) === Number(configRow.temp_max) &&
        Number(ack.fan_min_percent) === Number(configRow.fan_min_percent) &&
        Number(ack.fan_max_percent) === Number(configRow.fan_max_percent) &&
        String(ack.control_mode) === String(configRow.control_mode) &&
        (configRow.control_mode !== 'manual' ||
          Number(ack.manual_fan_percent) === Number(configRow.manual_fan_percent)));
    return { synced, acknowledged: ack };
  } catch {
    return { synced: false, acknowledged: null };
  }
}
