/**
 * ============================================================================
 * firmware/seed_chamber.ino
 * AgriSeed Monitor — Autonomous ESP32 Smart Seed Storage Controller
 * ============================================================================
 *
 * HARDWARE & SAFETY NOTES (READ BEFORE WIRING):
 * 1. GPIO Assignments (Verify against your specific ESP32 dev board pinout!):
 *    - GPIO 4  : DHT22 temperature/humidity data pin (with 4.7k–10k pull-up to 3.3V)
 *    - GPIO 25 : PWM output -> MOSFET / dedicated DC fan driver input
 *                NEVER connect a 12V or high-current fan directly to an ESP32 GPIO!
 *    - GPIO 26 : Cooling control output -> Opto-isolated relay / SSR / contactor interface
 *                NEVER drive a refrigeration compressor directly from an ESP32 GPIO!
 *    - GPIO 2  : Onboard status LED (blinks fast on sensor fault, solid when Wi-Fi online)
 *    - GPIO 27 : Optional fan tachometer pulse input (only if HAS_TACHOMETER == true)
 *
 * 2. Compressor & Refrigeration Safety:
 *    - Enforces a 3-minute (180s) startup inhibit and minimum OFF rest time to
 *      allow refrigerant pressure equalisation and prevent locked-rotor damage.
 *    - Enforces a 1-minute (60s) minimum ON time and >= 0.6 °C temperature
 *      hysteresis to prevent rapid relay chattering.
 *    - If the DHT22 fails validation 3 times in a row, the controller enters
 *      SENSOR_FAULT fallback: disables cooling safely, sets fan circulation to a
 *      safe moderate speed (40%), blinks the status LED, and reports a fault.
 *      Note: Without valid temperature measurements, safe refrigeration cannot
 *      be guaranteed — inspect the chamber physically when an alarm occurs!
 *
 * 3. Local Autonomy:
 *    - The local control loop runs every 1 second using non-blocking `millis()`
 *      timers. If Wi-Fi or the laptop server disconnects, the ESP32 continues
 *      regulating cooling and fan speed using its last validated configuration.
 *
 * Arduino IDE Libraries Required:
 *    - "DHT sensor library" by Adafruit (+ "Adafruit Unified Sensor")
 *    - "ArduinoJson" by Benoit Blanchon (v6 or v7)
 * ============================================================================
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <esp_task_wdt.h>

// ===================== USER NETWORK & DEVICE SETTINGS =======================
const char* WIFI_SSID     = "YOUR_LOCAL_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_LOCAL_WIFI_PASSWORD";

// Replace 192.168.1.5 with your laptop's actual local LAN IPv4 address:
const char* SERVER_BASE   = "http://192.168.1.5:3000";
const char* DEVICE_ID     = "chamber-01";
const char* DEVICE_KEY    = "chamber-01-local-secret-key";

// ===================== PIN ASSIGNMENTS (VERIFY HARDWARE) ====================
constexpr uint8_t PIN_DHT         = 4;
constexpr uint8_t PIN_FAN_PWM     = 25;
constexpr uint8_t PIN_COOL_RELAY  = 26;
constexpr uint8_t PIN_STATUS_LED  = 2;
constexpr uint8_t PIN_FAN_TACH    = 27;

// Relay polarity: set true if your opto-isolated relay module triggers on LOW
constexpr bool RELAY_ACTIVE_LOW   = false;

// Set true ONLY if a 4-wire fan tachometer open-collector output (level-shifted
// safely to 3.3V) is wired to PIN_FAN_TACH. Otherwise leave false so RPM is
// honestly reported as `null` (unavailable) rather than invented.
constexpr bool HAS_TACHOMETER     = false;

// ===================== PWM & TIMING CONSTANTS ===============================
constexpr uint32_t PWM_FREQ_HZ             = 25000; // 25 kHz standard 4-wire PWM DC fan frequency
constexpr uint8_t  PWM_RESOLUTION_BITS     = 8;     // 0..255 duty cycle
constexpr uint8_t  PWM_CHANNEL_LEGACY      = 0;     // Used on ESP32 Arduino Core 2.x

constexpr uint32_t SENSOR_READ_INTERVAL_MS = 2500;  // DHT22 minimum sampling period is ~2s
constexpr uint32_t CONTROL_LOOP_INTERVAL_MS= 1000;  // Independent 1s local control loop
constexpr uint32_t TELEMETRY_BASE_MS       = 5000;  // Send reading every 5s when online
constexpr uint32_t CONFIG_POLL_BASE_MS     = 10000; // Poll server config every 10s
constexpr uint32_t MAX_BACKOFF_MS          = 60000; // Max retry backoff when server is offline
constexpr uint32_t WIFI_RETRY_INTERVAL_MS  = 10000;

// Compressor protection timers (milliseconds)
constexpr uint32_t STARTUP_COMPRESSOR_INHIBIT_MS = 180000UL; // 3 min safe startup delay
constexpr uint32_t DEFAULT_MIN_OFF_MS            = 180000UL; // 3 min minimum OFF rest
constexpr uint32_t DEFAULT_MIN_ON_MS             = 60000UL;  // 1 min minimum ON run

#define DHTTYPE DHT22
DHT dht(PIN_DHT, DHTTYPE);

// ===================== VALIDATED CONTROL CONFIGURATION ======================
struct ControlConfig {
  uint32_t configVersion   = 1;
  float    targetTemp      = 17.5f;
  float    tempMin         = 15.0f;
  float    tempMax         = 20.0f;
  float    coolingOnTemp   = 18.2f;
  float    coolingOffTemp  = 16.8f;
  uint32_t minOffMs        = DEFAULT_MIN_OFF_MS;
  uint32_t minOnMs         = DEFAULT_MIN_ON_MS;
  uint8_t  fanMinPercent   = 25;
  uint8_t  fanMaxPercent   = 85;
  uint8_t  manualFanPercent= 45;
  bool     manualMode      = false;
};

ControlConfig activeConfig;

// ===================== RUNTIME STATE ========================================
float    lastValidTemp      = NAN;
float    lastValidHumidity  = NAN;
uint8_t  badSensorStreak    = 0;
bool     sensorFaultActive  = true; // Start in safe state until first valid DHT22 read

bool     coolingRelayOn     = false;
uint32_t lastRelaySwitchMs  = 0;
float    currentFanPercent  = 30.0f;

volatile uint32_t tachPulseCount = 0;
int32_t  measuredFanRpm     = -1; // -1 means unavailable

uint32_t bootMs             = 0;
uint32_t lastSensorReadMs   = 0;
uint32_t lastControlTickMs  = 0;
uint32_t lastTachCalcMs     = 0;
uint32_t nextTelemetryMs    = 5000;
uint32_t nextConfigPollMs   = 3000;
uint32_t currentBackoffMs   = TELEMETRY_BASE_MS;
uint32_t lastWifiAttemptMs  = 0;
uint32_t commFailureCount   = 0;

bool     pendingRejectionReport = false;
String   lastRejectionReason    = "";

// ===================== HARDWARE ABSTRACTION HELPERS =========================
void IRAM_ATTR onTachPulse() {
  tachPulseCount++;
}

void writeCoolingRelayHardware(bool turnOn) {
  coolingRelayOn = turnOn;
  bool pinHigh = RELAY_ACTIVE_LOW ? !turnOn : turnOn;
  digitalWrite(PIN_COOL_RELAY, pinHigh ? HIGH : LOW);
}

void setupPwmOutput() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  ledcAttach(PIN_FAN_PWM, PWM_FREQ_HZ, PWM_RESOLUTION_BITS);
#else
  ledcSetup(PWM_CHANNEL_LEGACY, PWM_FREQ_HZ, PWM_RESOLUTION_BITS);
  ledcAttachPin(PIN_FAN_PWM, PWM_CHANNEL_LEGACY);
#endif
}

void writeFanPwmPercent(float percent) {
  float clamped = constrain(percent, 0.0f, 100.0f);
  uint32_t duty = (uint32_t)roundf((clamped / 100.0f) * 255.0f);
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  ledcWrite(PIN_FAN_PWM, duty);
#else
  ledcWrite(PWM_CHANNEL_LEGACY, duty);
#endif
}

// ===================== SENSOR & LOCAL CONTROL LOOP ==========================
void sampleDhtSensor() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  bool valid = !isnan(t) && !isnan(h) && (t >= -20.0f && t <= 70.0f) && (h >= 0.0f && h <= 100.0f);
  if (valid) {
    lastValidTemp     = t;
    lastValidHumidity = h;
    badSensorStreak   = 0;
    if (sensorFaultActive) {
      Serial.println("[SENSOR] Valid DHT22 measurement restored; exiting fault fallback.");
    }
    sensorFaultActive = false;
  } else {
    if (badSensorStreak < 255) badSensorStreak++;
    Serial.printf("[SENSOR WARN] Invalid DHT22 read (streak=%u)\n", badSensorStreak);
    if (badSensorStreak >= 3) {
      sensorFaultActive = true;
    }
  }
}

void updateTachometerRpm(uint32_t nowMs) {
  if (!HAS_TACHOMETER) {
    measuredFanRpm = -1;
    return;
  }
  uint32_t elapsed = nowMs - lastTachCalcMs;
  if (elapsed < 1000) return;

  noInterrupts();
  uint32_t pulses = tachPulseCount;
  tachPulseCount = 0;
  interrupts();
  lastTachCalcMs = nowMs;

  // Standard brushless DC fan outputs 2 pulses per revolution
  measuredFanRpm = (int32_t)((pulses * 30000UL) / elapsed);
}

/**
 * Local autonomous temperature + fan speed control loop.
 * Runs every 1000 ms regardless of Wi-Fi or HTTP server state.
 */
void runLocalControlLoop(uint32_t nowMs) {
  // 1. SENSOR FAULT FALLBACK POLICY
  if (sensorFaultActive) {
    // Turn off compressor once minimum ON run time is satisfied (or immediately if safe)
    if (coolingRelayOn && (nowMs - lastRelaySwitchMs >= activeConfig.minOnMs)) {
      writeCoolingRelayHardware(false);
      lastRelaySwitchMs = nowMs;
      Serial.println("[SAFETY] Sensor fault fallback -> Cooling relay turned OFF.");
    }
    // Maintain gentle air circulation to prevent moisture pockets
    float fallbackFan = constrain(40.0f, (float)activeConfig.fanMinPercent, (float)activeConfig.fanMaxPercent);
    currentFanPercent = fallbackFan;
    writeFanPwmPercent(currentFanPercent);

    // Blink status LED rapidly to alert nearby farmer visually
    digitalWrite(PIN_STATUS_LED, ((nowMs / 250) % 2) ? HIGH : LOW);
    return;
  }

  // Solid LED when Wi-Fi connected and sensor healthy
  digitalWrite(PIN_STATUS_LED, (WiFi.status() == WL_CONNECTED) ? HIGH : LOW);

  // 2. SEPARATE COOLING HYSTERESIS + COMPRESSOR RESTART DELAY
  bool bootInhibitPassed = (nowMs - bootMs) >= STARTUP_COMPRESSOR_INHIBIT_MS;
  uint32_t sinceSwitchMs = nowMs - lastRelaySwitchMs;

  if (!coolingRelayOn) {
    if (bootInhibitPassed &&
        lastValidTemp >= activeConfig.coolingOnTemp &&
        sinceSwitchMs >= activeConfig.minOffMs) {
      writeCoolingRelayHardware(true);
      lastRelaySwitchMs = nowMs;
      Serial.printf("[COOLING] Relay ON (Temp=%.2f C >= %.2f C)\n", lastValidTemp, activeConfig.coolingOnTemp);
    }
  } else {
    if (lastValidTemp <= activeConfig.coolingOffTemp &&
        sinceSwitchMs >= activeConfig.minOnMs) {
      writeCoolingRelayHardware(false);
      lastRelaySwitchMs = nowMs;
      Serial.printf("[COOLING] Relay OFF (Temp=%.2f C <= %.2f C)\n", lastValidTemp, activeConfig.coolingOffTemp);
    }
  }

  // 3. SEPARATE PWM CIRCULATION FAN CONTROL (RAMPED AUTO OR MANUAL)
  float targetFan = (float)activeConfig.fanMinPercent;
  if (activeConfig.manualMode) {
    targetFan = constrain(
      (float)activeConfig.manualFanPercent,
      (float)activeConfig.fanMinPercent,
      (float)activeConfig.fanMaxPercent
    );
  } else {
    // Prototype Automatic Strategy:
    // At or below targetTemp -> fanMinPercent; smoothly ramp toward fanMaxPercent near tempMax
    if (lastValidTemp <= activeConfig.targetTemp) {
      targetFan = (float)activeConfig.fanMinPercent;
    } else if (lastValidTemp >= activeConfig.tempMax) {
      targetFan = (float)activeConfig.fanMaxPercent;
    } else {
      float span = max(0.5f, activeConfig.tempMax - activeConfig.targetTemp);
      float ratio = (lastValidTemp - activeConfig.targetTemp) / span;
      targetFan = activeConfig.fanMinPercent + ratio * (activeConfig.fanMaxPercent - activeConfig.fanMinPercent);
    }
  }

  // Ramp-rate limit: maximum 5% duty change per second to avoid fan hunting
  float delta = targetFan - currentFanPercent;
  if (fabsf(delta) <= 5.0f) {
    currentFanPercent = targetFan;
  } else {
    currentFanPercent += (delta > 0.0f ? 5.0f : -5.0f);
  }
  writeFanPwmPercent(currentFanPercent);
}

// ===================== CONFIGURATION VALIDATION =============================
bool validateAndApplyServerConfig(const JsonDocument& doc, String& outError) {
  if (!doc.containsKey("target_temp") || !doc.containsKey("temp_min") || !doc.containsKey("temp_max")) {
    outError = "Missing required temperature fields.";
    return false;
  }

  float tTarget = doc["target_temp"].as<float>();
  float tMin    = doc["temp_min"].as<float>();
  float tMax    = doc["temp_max"].as<float>();
  float cOn     = doc["cooling_on_temp"] | (tTarget + 0.7f);
  float cOff    = doc["cooling_off_temp"] | (tTarget - 0.7f);
  int   fMin    = doc["fan_min_percent"] | 25;
  int   fMax    = doc["fan_max_percent"] | 85;
  int   fManual = doc["manual_fan_percent"] | fMin;
  const char* modeStr = doc["control_mode"] | "auto";

  if (isnan(tTarget) || isnan(tMin) || isnan(tMax) || tMin < 2.0f || tMax > 35.0f || (tMax - tMin) < 1.5f) {
    outError = "Unsafe temperature bounds rejected by ESP32.";
    return false;
  }
  if (tTarget < tMin || tTarget > tMax) {
    outError = "target_temp outside [temp_min, temp_max].";
    return false;
  }
  if ((cOn - cOff) < 0.6f) {
    outError = "Cooling hysteresis < 0.6 C rejected to protect compressor.";
    return false;
  }
  if (fMin < 0 || fMax > 100 || fMin > fMax) {
    outError = "Invalid fan speed limits.";
    return false;
  }

  activeConfig.configVersion    = doc["config_version"] | activeConfig.configVersion;
  activeConfig.targetTemp       = tTarget;
  activeConfig.tempMin          = tMin;
  activeConfig.tempMax          = tMax;
  activeConfig.coolingOnTemp    = cOn;
  activeConfig.coolingOffTemp   = cOff;
  activeConfig.fanMinPercent    = (uint8_t)fMin;
  activeConfig.fanMaxPercent    = (uint8_t)fMax;
  activeConfig.manualFanPercent = (uint8_t)constrain(fManual, fMin, fMax);
  activeConfig.manualMode       = (strcmp(modeStr, "manual") == 0);

  uint32_t minOffSec = doc["min_compressor_off_sec"] | 180;
  uint32_t minOnSec  = doc["min_compressor_on_sec"]  | 60;
  activeConfig.minOffMs = max(60000UL, minOffSec * 1000UL);
  activeConfig.minOnMs  = max(30000UL, minOnSec * 1000UL);

  return true;
}

// ===================== NON-BLOCKING BACKGROUND WIFI & HTTP ==================
void maintainWifiConnection(uint32_t nowMs) {
  if (WiFi.status() == WL_CONNECTED) return;
  if (nowMs - lastWifiAttemptMs < WIFI_RETRY_INTERVAL_MS) return;

  lastWifiAttemptMs = nowMs;
  Serial.println("[WIFI] Reconnecting to local Wi-Fi in background...");
  WiFi.disconnect();
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void fillAppliedConfigJson(JsonObject obj) {
  obj["config_version"]    = activeConfig.configVersion;
  obj["target_temp"]       = activeConfig.targetTemp;
  obj["temp_min"]          = activeConfig.tempMin;
  obj["temp_max"]          = activeConfig.tempMax;
  obj["cooling_on_temp"]   = activeConfig.coolingOnTemp;
  obj["cooling_off_temp"]  = activeConfig.coolingOffTemp;
  obj["fan_min_percent"]   = activeConfig.fanMinPercent;
  obj["fan_max_percent"]   = activeConfig.fanMaxPercent;
  obj["control_mode"]      = activeConfig.manualMode ? "manual" : "auto";
  obj["manual_fan_percent"]= activeConfig.manualFanPercent;
}

void postDeviceRejectionStatus() {
  if (!pendingRejectionReport || WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = String(SERVER_BASE) + "/api/device/status";
  http.begin(url);
  http.setConnectTimeout(1800);
  http.setTimeout(2200);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);

  StaticJsonDocument<512> doc;
  doc["device_id"]        = DEVICE_ID;
  doc["sensor_ok"]        = !sensorFaultActive;
  doc["config_rejected"]  = true;
  doc["rejection_reason"] = lastRejectionReason;
  fillAppliedConfigJson(doc.createNestedObject("applied_config"));

  String body;
  serializeJson(doc, body);
  int code = http.POST(body);
  if (code >= 200 && code < 300) {
    pendingRejectionReport = false;
  }
  http.end();
}

void pollServerConfig(uint32_t nowMs) {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = String(SERVER_BASE) + "/api/device/config?device_id=" + DEVICE_ID;
  http.begin(url);
  http.setConnectTimeout(1800);
  http.setTimeout(2200);
  http.addHeader("X-Device-Key", DEVICE_KEY);

  int httpCode = http.GET();
  if (httpCode == 200) {
    StaticJsonDocument<768> doc;
    DeserializationError err = deserializeJson(doc, http.getString());
    if (!err) {
      String reason;
      if (validateAndApplyServerConfig(doc, reason)) {
        Serial.printf("[CONFIG] Applied config v%lu (Target=%.1f C)\n",
                      (unsigned long)activeConfig.configVersion, activeConfig.targetTemp);
      } else {
        Serial.printf("[CONFIG REJECTED] %s\n", reason.c_str());
        lastRejectionReason    = reason;
        pendingRejectionReport = true;
      }
    }
  } else {
    commFailureCount++;
    Serial.printf("[HTTP WARN] Config GET failed (code=%d, failures=%lu)\n",
                  httpCode, (unsigned long)commFailureCount);
  }
  http.end();
  nextConfigPollMs = nowMs + CONFIG_POLL_BASE_MS;
}

void postSensorReading(uint32_t nowMs) {
  if (WiFi.status() != WL_CONNECTED) {
    commFailureCount++;
    currentBackoffMs = min(MAX_BACKOFF_MS, currentBackoffMs * 2);
    nextTelemetryMs  = nowMs + currentBackoffMs;
    Serial.printf("[OFFLINE] Laptop/Wi-Fi unavailable (failures=%lu). Continuing local control.\n",
                  (unsigned long)commFailureCount);
    return;
  }

  HTTPClient http;
  String url = String(SERVER_BASE) + "/api/device/readings";
  http.begin(url);
  http.setConnectTimeout(1800);
  http.setTimeout(2200);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Key", DEVICE_KEY);

  StaticJsonDocument<768> doc;
  doc["device_id"]         = DEVICE_ID;
  doc["sensor_ok"]         = !sensorFaultActive;
  if (!sensorFaultActive) {
    doc["temp"]            = serialized(String(lastValidTemp, 2));
    doc["humidity"]        = serialized(String(lastValidHumidity, 1));
  } else {
    doc["temp"]            = nullptr;
    doc["humidity"]        = nullptr;
  }
  doc["fan_speed_percent"] = roundf(currentFanPercent);
  if (HAS_TACHOMETER && measuredFanRpm >= 0) {
    doc["fan_rpm"]         = measuredFanRpm;
  } else {
    doc["fan_rpm"]         = nullptr;
  }
  doc["cooling_on"]        = coolingRelayOn;
  doc["is_simulated"]      = false;

  fillAppliedConfigJson(doc.createNestedObject("applied_config"));
  JsonObject diag = doc.createNestedObject("diagnostics");
  diag["wifi_rssi_dbm"]    = WiFi.RSSI();
  diag["uptime_sec"]       = nowMs / 1000UL;
  diag["comm_failures"]    = commFailureCount;

  String payload;
  serializeJson(doc, payload);

  int httpCode = http.POST(payload);
  if (httpCode >= 200 && httpCode < 300) {
    currentBackoffMs = TELEMETRY_BASE_MS;
    nextTelemetryMs  = nowMs + TELEMETRY_BASE_MS;
    Serial.printf("[TELEMETRY OK] Temp=%.2f C, RH=%.1f%%, Fan=%.0f%%, Cooling=%s\n",
                  lastValidTemp, lastValidHumidity, currentFanPercent, coolingRelayOn ? "ON" : "OFF");
  } else {
    commFailureCount++;
    currentBackoffMs = min(MAX_BACKOFF_MS, currentBackoffMs * 2);
    nextTelemetryMs  = nowMs + currentBackoffMs;
    Serial.printf("[TELEMETRY FAIL] HTTP %d — never reporting false success; retry in %lu ms\n",
                  httpCode, (unsigned long)currentBackoffMs);
  }
  http.end();
}

// ===================== ARDUINO SETUP & LOOP =================================
void setup() {
  Serial.begin(115200);
  bootMs = millis();

  pinMode(PIN_COOL_RELAY, OUTPUT);
  writeCoolingRelayHardware(false); // Safe startup: compressor OFF during 3-minute inhibit

  pinMode(PIN_STATUS_LED, OUTPUT);
  digitalWrite(PIN_STATUS_LED, LOW);

  setupPwmOutput();
  writeFanPwmPercent(currentFanPercent);

  if (HAS_TACHOMETER) {
    pinMode(PIN_FAN_TACH, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(PIN_FAN_TACH), onTachPulse, FALLING);
  }

  dht.begin();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  lastWifiAttemptMs = bootMs;

  Serial.println("==========================================================");
  Serial.println(" AgriSeed Monitor ESP32 Controller Booted");
  Serial.println(" Safe Startup: Compressor inhibited for 180s pressure rest");
  Serial.println("==========================================================");
}

void loop() {
  uint32_t nowMs = millis();

  // 1. Sample DHT22 periodically (always non-blocking)
  if (nowMs - lastSensorReadMs >= SENSOR_READ_INTERVAL_MS) {
    lastSensorReadMs = nowMs;
    sampleDhtSensor();
  }

  // 2. Compute optional hardware tachometer RPM
  updateTachometerRpm(nowMs);

  // 3. Execute local autonomous temperature + fan loop FIRST
  if (nowMs - lastControlTickMs >= CONTROL_LOOP_INTERVAL_MS) {
    lastControlTickMs = nowMs;
    runLocalControlLoop(nowMs);
  }

  // 4. Background Wi-Fi & Local Laptop HTTP Synchronisation
  maintainWifiConnection(nowMs);
  postDeviceRejectionStatus();

  if ((int32_t)(nowMs - nextConfigPollMs) >= 0) {
    pollServerConfig(nowMs);
  }

  if ((int32_t)(nowMs - nextTelemetryMs) >= 0) {
    postSensorReading(nowMs);
  }

  delay(10); // Yield cleanly to FreeRTOS / watchdog
}
