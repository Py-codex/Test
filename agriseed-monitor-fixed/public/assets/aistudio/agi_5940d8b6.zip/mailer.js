/**
 * mailer.js
 * ----------------------------------------------------------------------------
 * Optional SMTP email notification helper using Nodemailer.
 *
 * Design Rule:
 * - Normal operation of AgriSeed Monitor requires ZERO internet connectivity.
 * - If SMTP_HOST / SMTP_USER / SMTP_PASS are blank or if the Wi-Fi router has
 *   no internet access, email sending fails gracefully without throwing
 *   unhandled exceptions or blocking chamber monitoring.
 */

import nodemailer from 'nodemailer';

export function isSmtpConfigured() {
  return Boolean(
    process.env.SMTP_HOST &&
      process.env.SMTP_HOST.trim() !== '' &&
      process.env.SMTP_PORT
  );
}

export async function sendAlertEmail({ to, subject, text }) {
  if (!isSmtpConfigured()) {
    return {
      sent: false,
      skipped: true,
      reason: 'SMTP not configured (offline local mode).'
    };
  }

  try {
    const port = Number(process.env.SMTP_PORT) || 587;
    const secure = String(process.env.SMTP_SECURE || 'false').toLowerCase() === 'true';

    const transportConfig = {
      host: process.env.SMTP_HOST.trim(),
      port,
      secure,
      connectionTimeout: 4000,
      greetingTimeout: 4000,
      socketTimeout: 5000
    };

    if (process.env.SMTP_USER && process.env.SMTP_PASS) {
      transportConfig.auth = {
        user: process.env.SMTP_USER.trim(),
        pass: process.env.SMTP_PASS
      };
    }

    const transporter = nodemailer.createTransport(transportConfig);
    await transporter.sendMail({
      from: process.env.SMTP_FROM || 'AgriSeed Monitor <alerts@localhost>',
      to,
      subject,
      text
    });

    return { sent: true, skipped: false };
  } catch (err) {
    return {
      sent: false,
      skipped: false,
      reason: err instanceof Error ? err.message : 'Unknown SMTP error'
    };
  }
}
