/**
 * db.js
 * ----------------------------------------------------------------------------
 * Local SQLite database connection, automatic schema creation, indexes,
 * foreign-key enforcement, and starter seed-profile initialisation.
 *
 * Timestamp & Date Policy:
 * - Every timestamp in SQLite is stored in UTC ISO-8601 format
 *   (e.g. "2026-10-28T09:30:00.000Z") via `nowUtc()`.
 * - Batch storage duration (`days_stored`) is calculated consistently as:
 *     Math.max(0, Math.floor((nowMs - Date.parse(started_at)) / 86_400_000))
 * - Remaining storage duration (`days_remaining`) is calculated as:
 *     Math.max(0, planned_days - days_stored)
 */

import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import { STARTER_SEED_PROFILES } from './seed-data.js';

export function nowUtc() {
  return new Date().toISOString();
}

export function computeBatchDayMetrics(startedAtIso, plannedDays, referenceMs = Date.now()) {
  const startedMs = Date.parse(startedAtIso);
  if (Number.isNaN(startedMs)) {
    return { days_stored: 0, days_remaining: plannedDays, is_overdue: false };
  }
  const elapsedMs = Math.max(0, referenceMs - startedMs);
  const daysStored = Math.floor(elapsedMs / 86_400_000);
  const daysRemaining = Math.max(0, Number(plannedDays) - daysStored);
  const isOverdue = daysStored >= Number(plannedDays);
  return {
    days_stored: daysStored,
    days_remaining: daysRemaining,
    is_overdue: isOverdue
  };
}

let dbInstance = null;

export function initDatabase(customDbPath) {
  if (dbInstance && !customDbPath) {
    return dbInstance;
  }

  const resolvedPath = path.resolve(
    customDbPath || process.env.DB_PATH || './data/app.db'
  );
  fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

  const db = new Database(resolvedPath);

  // Enable WAL journal mode for reliable concurrent reads/writes and enforce foreign keys.
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS seed_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      temp_min REAL NOT NULL,
      temp_max REAL NOT NULL,
      rh_min REAL NOT NULL,
      rh_max REAL NOT NULL,
      shelf_days INTEGER NOT NULL,
      notes TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY,
      user_id INTEGER NULL REFERENCES users(id) ON DELETE SET NULL,
      device_key_hash TEXT NOT NULL,
      device_name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'offline',
      last_seen_at TEXT NULL,
      acknowledged_config_json TEXT NULL,
      last_ack_at TEXT NULL,
      diagnostics_json TEXT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
      seed_profile_id INTEGER NOT NULL REFERENCES seed_profiles(id) ON DELETE RESTRICT,
      label TEXT NOT NULL,
      quantity_kg REAL NOT NULL CHECK (quantity_kg > 0),
      started_at TEXT NOT NULL,
      planned_days INTEGER NOT NULL CHECK (planned_days > 0),
      status TEXT NOT NULL CHECK (status IN ('active', 'closed')),
      closed_at TEXT NULL
    );

    -- Enforce at most ONE active batch per physical chamber at any time.
    CREATE UNIQUE INDEX IF NOT EXISTS idx_batches_one_active_per_device
      ON batches(device_id) WHERE status = 'active';

    CREATE INDEX IF NOT EXISTS idx_batches_user_status
      ON batches(user_id, status, started_at DESC);

    CREATE TABLE IF NOT EXISTS readings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
      batch_id INTEGER NULL REFERENCES batches(id) ON DELETE SET NULL,
      temp REAL NULL,
      humidity REAL NULL,
      fan_speed_percent REAL NOT NULL,
      fan_rpm INTEGER NULL,
      cooling_on INTEGER NOT NULL CHECK (cooling_on IN (0, 1)),
      sensor_ok INTEGER NOT NULL DEFAULT 1 CHECK (sensor_ok IN (0, 1)),
      is_simulated INTEGER NOT NULL DEFAULT 0 CHECK (is_simulated IN (0, 1)),
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_readings_device_created
      ON readings(device_id, created_at DESC);

    CREATE INDEX IF NOT EXISTS idx_readings_batch_created
      ON readings(batch_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS device_config (
      device_id TEXT PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
      target_temp REAL NOT NULL,
      temp_min REAL NOT NULL,
      temp_max REAL NOT NULL,
      cooling_on_temp REAL NOT NULL,
      cooling_off_temp REAL NOT NULL,
      fan_min_percent INTEGER NOT NULL,
      fan_max_percent INTEGER NOT NULL,
      manual_fan_percent INTEGER NOT NULL DEFAULT 40,
      control_mode TEXT NOT NULL CHECK (control_mode IN ('auto', 'manual')),
      manual_expires_at TEXT NULL,
      config_version INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
      batch_id INTEGER NULL REFERENCES batches(id) ON DELETE SET NULL,
      kind TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL,
      acknowledged INTEGER NOT NULL DEFAULT 0 CHECK (acknowledged IN (0, 1)),
      acknowledged_at TEXT NULL,
      resolved_at TEXT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_alerts_user_ack_created
      ON alerts(user_id, acknowledged, created_at DESC);

    CREATE INDEX IF NOT EXISTS idx_alerts_device_kind_created
      ON alerts(device_id, kind, created_at DESC);
  `);

  seedInitialData(db);

  if (!customDbPath) {
    dbInstance = db;
  }
  return db;
}

function seedInitialData(db) {
  // 1. Insert starter seed profiles ONLY when seed_profiles is empty.
  const countRow = db.prepare('SELECT COUNT(*) AS count FROM seed_profiles').get();
  if (countRow.count === 0) {
    const insertProfile = db.prepare(`
      INSERT INTO seed_profiles (name, temp_min, temp_max, rh_min, rh_max, shelf_days, notes)
      VALUES (@name, @temp_min, @temp_max, @rh_min, @rh_max, @shelf_days, @notes)
    `);
    const insertMany = db.transaction((profiles) => {
      for (const profile of profiles) {
        insertProfile.run(profile);
      }
    });
    insertMany(STARTER_SEED_PROFILES);
  }

  // 2. Ensure the default local operator exists (no login/signup screen required).
  const now = nowUtc();
  let operator = db
    .prepare('SELECT id, email FROM users ORDER BY id ASC LIMIT 1')
    .get();
  if (!operator) {
    const placeholderHash = bcrypt.hashSync('local-operator-managed', 10);
    const info = db
      .prepare('INSERT INTO users (email, password_hash, created_at) VALUES (?, ?, ?)')
      .run('operator@agriseed.local', placeholderHash, now);
    operator = { id: Number(info.lastInsertRowid), email: 'operator@agriseed.local' };
  }

  // 3. Ensure the default physical chamber ("chamber-01") exists and is bound to the local operator.
  const defaultDeviceId = (process.env.DEFAULT_DEVICE_ID || 'chamber-01').trim();
  const defaultDeviceKey = process.env.DEVICE_KEY || 'chamber-01-local-secret-key';

  const existingDevice = db
    .prepare('SELECT id, user_id FROM devices WHERE id = ?')
    .get(defaultDeviceId);

  if (!existingDevice) {
    const keyHash = bcrypt.hashSync(defaultDeviceKey, 10);
    const createDefaultChamber = db.transaction(() => {
      db.prepare(`
        INSERT INTO devices (id, user_id, device_key_hash, device_name, status, created_at)
        VALUES (?, ?, ?, ?, 'offline', ?)
      `).run(defaultDeviceId, operator.id, keyHash, 'Primary Seed Chamber 01', now);

      // Safe initial prototype operating configuration (Wheat/Barley/Rice range: 15-20 °C)
      db.prepare(`
        INSERT INTO device_config (
          device_id, target_temp, temp_min, temp_max,
          cooling_on_temp, cooling_off_temp,
          fan_min_percent, fan_max_percent, manual_fan_percent,
          control_mode, manual_expires_at, config_version, updated_at
        ) VALUES (?, 17.5, 15.0, 20.0, 18.2, 16.8, 25, 85, 45, 'auto', NULL, 1, ?)
      `).run(defaultDeviceId, now);
    });
    createDefaultChamber();
  } else if (existingDevice.user_id === null) {
    db.prepare('UPDATE devices SET user_id = ? WHERE id = ?').run(operator.id, defaultDeviceId);
  }

  // 4. Create a starter active batch on chamber-01 if no batches exist yet.
  const batchCount = db.prepare('SELECT COUNT(*) AS count FROM batches').get().count;
  if (batchCount === 0) {
    const wheatProfile = db
      .prepare('SELECT id, shelf_days FROM seed_profiles WHERE name = ?')
      .get('Wheat');
    if (wheatProfile) {
      db.prepare(`
        INSERT INTO batches (user_id, device_id, seed_profile_id, label, quantity_kg, started_at, planned_days, status)
        VALUES (?, ?, ?, 'Rabi Wheat Lot A-101', 45.0, ?, ?, 'active')
      `).run(operator.id, defaultDeviceId, wheatProfile.id, now, wheatProfile.shelf_days);
    }
  }
}

export function getDb() {
  if (!dbInstance) {
    return initDatabase();
  }
  return dbInstance;
}
