# AgriSeed Monitor — Smart Seed Storage Refrigerator

An offline-capable, local-network IoT monitoring and control platform for small-scale agricultural seed storage chambers. It pairs an autonomous ESP32 environmental controller (with local cooling hysteresis, compressor short-cycle protection, and PWM circulation fan control) with a Node.js, Express, and SQLite laptop server and a responsive vanilla web dashboard inspired by the **AgriSeed Monitor** reference interface.

## User Review & Critical Decisions

> [!IMPORTANT]
> All four architectural and design choices from our clarification step have been locked in below. Review the plan and click **Proceed** to build the complete prototype across all five stages.

- **Confirmed Frontend & Server Stack**: Plain HTML5, CSS3, and vanilla JavaScript served by Node.js, Express, and SQLite (`better-sqlite3`) with local `Chart.js` (`0` CDN or cloud dependencies during normal operation).
- **Confirmed Delivery Scope**: Complete end-to-end build covering all 5 stages at once — authentication & security, device & seed batch management, live AgriSeed Monitor dashboard, historical analytics with CSV export & alert cooldowns, and complete Arduino ESP32 firmware plus documentation.
- **Confirmed UI & Safety Synthesis**: Blends the **AgriSeed Monitor** visual layout and sidebar views (*Dashboard Overview*, *WiFi Connection*, *Seed Selection*, *Seed Guide*, *Storage Logs*, plus *Alerts & Safety*) with strict engineering distinctions: commanded fan percentage (`%`) vs. measured tachometer `RPM` (showing `Unavailable` when hardware feedback is absent), cooling relay status, requested vs. device-acknowledged configuration state, and manual override auto-expiry.
- **Confirmed Dual Simulation Mode**: Includes both a standalone terminal simulator for local command-line testing and an optional built-in browser simulator control bar (supporting normal drift, threshold breach, sensor fault, and offline disconnect scenarios) for immediate hardware-free verification.

---

## 1. Overview & Core Concept

- **What It Does**: Continuously tracks chamber temperature and relative humidity, regulates a refrigeration relay and variable-speed PWM DC circulation fan directly on the ESP32, logs batch-linked telemetry to a local SQLite database, triggers deduplicated alerts (in-app and optional SMTP email), and lets authorised farmers manage seed batches and safe operating setpoints from any phone or laptop on the same Wi-Fi network.
- **Target Audience / Persona**: Smallholder farmers, community seed banks, and student agricultural innovators operating a local seed-storage refrigerator where internet connectivity may be intermittent or absent.
- **Key Value**: Preserves seed viability by combining autonomous hardware-level climate control (which continues safely even if Wi-Fi or the laptop goes offline) with clear, mobile-friendly batch tracking, historical audit logs, and unverified seed-profile guidance.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Authentication & Session Onboarding**: Users sign up or log in on a clean local gateway protected by `bcryptjs` password hashing, login rate limiting, and session-bound CSRF tokens. First-time users can immediately register or connect to the default `chamber-01` controller and toggle the built-in simulator for instant live telemetry.
2. **Dashboard Overview (AgriSeed Monitor Workspace)**:
   - **Live Status Grid**: Displays Current Temperature (`°C`) vs. allowed range, Relative Humidity (`%`) vs. allowed range, Fan Speed card (clearly separating **Commanded `%`** from **Measured `RPM`** radial gauge or explicit `RPM Unavailable` notice), Cooling Unit state (`Cooling Active`, `Standby`, `Compressor Delay`, or `Fault Fallback`), Live Clock with last-reading age, and a clear 4-state health banner (**Green**: Nominal, **Amber**: Approaching limit / manual override / compressor delay, **Red**: Limit exceeded or sensor fault, **Grey**: Device offline / stale data).
   - **Control Panel**: Interactive sliders and numeric inputs for Target Temperature, Operating Limits (`temp_min` / `temp_max`), Fan Speed bounds (`fan_min_percent` / `fan_max_percent`), Automatic vs. Manual Fan Override (with countdown timer and one-click return to Auto), Seed Profile quick-apply, and side-by-side comparison of **Requested Settings** vs. **Device-Acknowledged Config**.
   - **Real-Time Dual-Axis Graph**: Smooth local Chart.js time-series area graph plotting Temperature (`°C`, left axis) and Relative Humidity (`%`, right axis) with hover crosshair tooltips.
   - **Recent Storage History & Active Alerts**: Quick-glance tabular log of recent readings alongside active chamber alerts with one-click **Acknowledge** buttons.
3. **WiFi Connection & Device Diagnostics**: Displays laptop LAN IP discovery instructions, `chamber-01` online/offline heartbeat status, device authentication credential rotation/setup, last configuration sync timestamp, and the interactive **Built-In Simulator Console** (Start/Stop, Inject High Temp, Inject Sensor Fault, Simulate Offline).
4. **Seed Selection (Batch Management)**: Enforces single active batch per physical chamber (`chamber-01`) while keeping historical closed batches. Users select a starter Seed Profile, enter batch label, quantity (`kg`), and planned storage days, monitor **Days Stored** vs. **Days Remaining**, and close completed batches.
5. **Seed Guide**: Reference table and cards for the six starter profiles (*Wheat*, *Barley*, *Rice*, *Maize*, *Chickpea*, *Mustard*), prominently marked as **provisional unverified demonstration values** requiring verification against ICAR / NBPGR standards before field reliance.
6. **Storage Logs & Full History**: Dedicated analytics view with `24h`, `7d`, and `30d` range selectors; separate aggregated charts for Temperature/Humidity, Fan Speed (`%` & `RPM`), and Cooling Duty State; summary statistics (`Min`, `Max`, `Avg`, `Sample Count`); paginated raw readings table (`50` rows per page); and one-click **CSV Export**.

### Visual Identity & Theme
- **Aesthetic Direction**: Calibrated Botanical Instrument — faithful to the uploaded **AgriSeed Monitor** reference image while enforcing laboratory telemetry clarity and anti-clutter discipline.
- **Color Palette & Mood (60-30-10 Discipline)**:
  - **60% Dominant Neutral Canvas**: Warm alabaster / soft sage-tinted off-white (`--bg-canvas: #F3F5F0`) with crisp card surfaces (`--bg-surface: #FCFDFB`).
  - **30% Structural Surfaces & Typography**: Subtle botanical hairline borders (`--border-subtle: #DCE3D8`), deep forest charcoal ink (`--text-primary: #18261C`), and muted olive-slate labels (`--text-muted: #5A6B5E`).
  - **10% Calibrated Accents & Semantic States**: Forest green primary control accent (`--accent-primary: #1F5C3A`, soft active nav wash `#D9EBDF`), paired with explicit text-and-icon status tones: Nominal Green (`#166534`), Warning Amber (`#B45309`), Critical Crimson (`#B91C1C`), and Offline Slate (`#64748B`).
- **Typography & Hierarchy**:
  - Clean local geometric/humanist system stack with serif editorial brand wordmark (`AgriSeed Monitor` styled in crisp serif matching the reference header) and clean sans-serif body (`15px` body, `12px–13px` labels).
  - Strict `font-variant-numeric: tabular-nums` and monospace numerals on every temperature, humidity, percentage, RPM, countdown, and table cell so live polling updates never cause horizontal layout jitter.
- **Component Styling & Responsive Layout**:
  - **Desktop (`1440px`)**: Left sidebar (`240px`) + fluid main workspace with single-elevation flat cards (`1px` subtle border, generous `20px–24px` outer padding, zero nested card-in-card boxes).
  - **Mobile (`380px`)**: Collapsible top navigation drawer/bar keeping sticky height well under `15%` of viewport height, Touch targets `>= 44px`, horizontally scrollable raw log table, and stacked single-column control sliders.
- **Interactive Feedback & Motion**:
  - Fast `150ms` compositor-only transitions on controls and tab switches.
  - Explicit **Stale Data Guard**: If the last reading exceeds the offline threshold (e.g., `20s`), live metric cards visually dim into the **Grey Offline/Stale** state with a clear `"Stale — Last seen X min ago"` label rather than masquerading as live conditions.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Autonomous Edge Control vs. Server-Driven Relay Switching**
  - *Chosen Approach*: The server only validates and stores target parameters (`target_temp`, `temp_min`, `temp_max`, `fan_min_percent`, `fan_max_percent`, `control_mode`). The ESP32 polls configuration, validates bounds locally, and executes its own non-blocking hysteresis control loop and compressor minimum ON/OFF delay timers.
  - *Why*: Guarantees seed safety and prevents compressor short-cycling even if the Wi-Fi router drops or the laptop sleeps.
  - *Alternatives Considered*: Server-sent `RELAY_ON` / `RELAY_OFF` HTTP commands — rejected because network latency or disconnection could freeze the compressor ON (freezing seeds) or cycle it rapidly.

- **Decision 2: Commanded Fan `%` vs. Measured `RPM` Representation**
  - *Chosen Approach*: Store and display `fan_speed_percent` (`0–100%`) as the primary control variable while keeping `fan_rpm` nullable. In the AgriSeed radial gauge card, display both the commanded `%` and actual `RPM` when reported (or `"RPM Unavailable — 2/3-wire fan"` when `null`, and clearly badge `"Simulated RPM"` when driven by the simulator).
  - *Why*: Respects the reference image's visual RPM gauge while honoring hardware reality when a tachometer pulse wire is not installed.

- **Decision 3: Raw Readings vs. Downsampled Historical Charts**
  - *Chosen Approach*: Keep raw `readings` rows untouched for accurate `Min / Max / Avg` SQL aggregates, `50`-row pagination, and CSV export, while serving bucket-averaged time-series points for `24h`, `7d`, and `30d` Chart.js views.
  - *Why*: Prevents browser canvas lag when thousands of 5-second readings accumulate over 30 days while preserving 100% audit fidelity in exports.

- **Decision 4: Manual Fan Override Safety Timeout**
  - *Chosen Approach*: Manual fan override requires an authenticated user session, enforces configured hardware `fan_min_percent` / `fan_max_percent` limits, never disables temperature/compressor safety cutoffs, and automatically reverts to `auto` mode after a configurable timeout (default `30` minutes) unless renewed or cancelled early.
  - *Why*: Prevents an operator from accidentally leaving chamber airflow at `0%` indefinitely during maintenance.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                     LOCAL WI-FI NETWORK (NO INTERNET REQUIRED)               │
└──────────────────────┬────────────────────────────────────┬──────────────────┘
                       │ Local HTTP + X-Device-Key          │ Browser HTTP + Session + CSRF
                       ▼                                    ▼
┌─────────────────────────────────────────┐  ┌─────────────────────────────────┐
│ ESP32 Controller OR Simulator           │  │ Vanilla Web Client (380px–1440px)│
│ ┌─────────────────────────────────────┐ │  │ ┌─────────────────────────────┐ │
│ │ Non-Blocking Control Loop (2s tick) │ │  │ │ Auth Gateway (Login/Signup) │ │
│ │ • DHT22 Read & Fault Validation     │ │  │ └──────────────┬──────────────┘ │
│ │ • Cooling Hysteresis + Min Off/On   │ │  │                ▼                │
│ │ • PWM Fan Ramp / Auto / Manual %    │ │  │ ┌─────────────────────────────┐ │
│ │ • Safe Fallback on Sensor Fault     │ │  │ │ AgriSeed Sidebar Workspace  │ │
│ └─────────────────┬───────────────────┘ │  │ │ • Dashboard Overview        │ │
│                   │ POST /readings      │  │ │ • WiFi & Built-in Simulator │ │
│                   │ GET  /config        │  │ │ • Seed Selection (Batches)  │ │
│                   ▼                     │  │ │ • Seed Guide (Provisional)  │ │
└───────────────────┼─────────────────────┘  │ │ • Storage Logs & CSV Export │ │
                    │                        │ │ • Active Alerts & Cooldowns │ │
                    │                        │ └──────────────┬──────────────┘ │
                    │                        └────────────────┼────────────────┘
                    ▼                                         ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                     LAPTOP NODE.JS + EXPRESS SERVER                          │
│ ┌──────────────────────┐ ┌────────────────────────┐ ┌──────────────────────┐ │
│ │ Device Protocol API  │ │ Session & User Web API │ │ Background Scheduler │ │
│ │ • Key Hash Auth      │ │ • bcryptjs + RateLimit │ │ • Offline Detection  │ │
│ │ • Range Validation   │ │ • Session + CSRF Guard │ │ • Manual Mode Expiry │ │
│ │ • Ack Config Sync    │ │ • User Ownership Check │ │ • Batch Expiry Cron  │ │
│ └──────────┬───────────┘ └───────────┬────────────┘ └──────────┬───────────┘ │
│            └─────────────────────────┼─────────────────────────┘             │
│                                      ▼                                       │
│            ┌───────────────────────────────────────────────────┐             │
│            │ SQLite Database (WAL + Foreign Keys + Prepared)   │             │
│            │ users │ seed_profiles │ devices │ device_config   │             │
│            │ batches │ readings │ alerts                       │             │
│            └───────────────────────────────────────────────────┘             │
│                                      │ (Optional when SMTP configured)       │
│                                      ▼                                       │
│                        ┌───────────────────────────┐                         │
│                        │ Optional Nodemailer Alert │                         │
│                        │ (Graceful no-op on error) │                         │
│                        └───────────────────────────┘                         │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
All timestamps are stored in ISO-8601 UTC (`YYYY-MM-DDTHH:MM:SS.sssZ`), with **Days Stored** calculated as `floor((now_utc - started_at_utc) / 86400s)` and **Days Remaining** as `max(0, planned_days - days_stored)`. Foreign keys (`PRAGMA foreign_keys = ON`) and WAL mode are enabled at startup:

- **`users`**: `id`, `email` (unique), `password_hash` (`bcryptjs`), `created_at`.
- **`seed_profiles`**: `id`, `name`, `temp_min`, `temp_max`, `rh_min`, `rh_max`, `shelf_days`, `notes` (seeded once when empty with provisional *Wheat*, *Barley*, *Rice*, *Maize*, *Chickpea*, and *Mustard* profiles).
- **`devices`**: `id` (e.g., `chamber-01`), `user_id` (owner binding for strict multi-user isolation), `device_key_hash`, `device_name`, `status` (`online` / `offline` / `fault`), `last_seen_at`, `acknowledged_config_json`, `last_ack_at`, `created_at`.
- **`device_config`**: `device_id` (PK/FK), `target_temp`, `temp_min`, `temp_max`, `cooling_hysteresis`, `fan_min_percent`, `fan_max_percent`, `manual_fan_percent`, `control_mode` (`auto` / `manual`), `manual_expires_at`, `updated_at`.
- **`batches`**: `id`, `user_id`, `device_id`, `seed_profile_id`, `label`, `quantity_kg`, `started_at`, `planned_days`, `status` (`active` / `closed`), `closed_at` — partial unique constraint ensuring at most one `active` batch per `device_id`.
- **`readings`**: `id`, `device_id`, `batch_id` (nullable), `temp`, `humidity`, `fan_speed_percent`, `fan_rpm` (nullable), `cooling_on`, `sensor_ok`, `is_simulated`, `created_at` — composite index on `(device_id, created_at DESC)`.
- **`alerts`**: `id`, `user_id`, `device_id`, `batch_id` (nullable), `kind` (`high_temp`, `low_temp`, `high_humidity`, `low_humidity`, `device_offline`, `sensor_failure`, `config_rejected`, `batch_expiring`, `email_warning`), `message`, `created_at`, `acknowledged`, `acknowledged_at`, `resolved_at` — indexed by `(user_id, acknowledged, created_at DESC)`.

### Interactive Component & State Mapping
- **Auth & CSRF Lifecycle**: Login/signup establishes an `httpOnly`, `sameSite: 'lax'` session and issues a per-session CSRF token exposed via `/api/auth/me`. Every state-changing `POST` / `PUT` / `DELETE` browser request sends `X-CSRF-Token`; unauthenticated or cross-user ID tampering returns `401`/`403`/`404`.
- **Control Panel Submission & Device Ack Reconciliation**: Adjusting sliders updates live value readouts immediately; clicking **Save Configuration** validates safety invariants (`temp_min < target_temp < temp_max`, `0 <= fan_min_percent <= fan_max_percent <= 100`, safe refrigeration bounds `2°C–30°C`) on the server, updates `device_config`, and displays `"Pending Device Sync"` until the ESP32 or simulator fetches `GET /api/device/config` and reports its applied config hash/snapshot in `POST /api/device/status` or `POST /api/device/readings`.
- **Batch Creation & Profile Sync**: Starting a new batch checks that no other active batch exists on `chamber-01` (or prompts to close the existing batch first), links incoming readings automatically to the active `batch_id`, and optionally offers a one-click button to apply the selected seed profile's recommended temperature range to the Control Panel.
- **Alert Engine, Cooldowns & Auto-Recovery**: Incoming readings and the 15-second cron job evaluate thresholds against active batch/device limits. Duplicate alerts of the same `kind` on the same `device_id` are suppressed within the configurable cooldown window (`ALERT_COOLDOWN_MINUTES`, default `15` min). When readings return within safe bounds or an offline device reconnects, open alerts automatically populate `resolved_at` while remaining auditable in the Alerts log.
- **Built-In & CLI Hardware Simulation**: Both the standalone terminal simulator and the optional in-app simulator model realistic thermal inertia (chamber warms slowly toward ambient when cooling is OFF, cools toward setpoint when cooling relay is ON), compressor minimum ON/OFF protection (`120s` real firmware / scaled indicator), PWM fan ramp response, simulated tachometer RPM marked explicitly as simulated, and one-click fault injection so all 18 acceptance criteria can be verified live.
