/**
 * simulate.js
 * ----------------------------------------------------------------------------
 * Hardware-free ESP32 Seed Chamber Simulator.
 *
 * Can run in two ways:
 * 1. Standalone terminal process (`npm run simulate` or `node simulate.js`):
 *      node simulate.js
 *      node simulate.js --mode=high_temp
 *      node simulate.js --mode=high_humidity
 *      node simulate.js --mode=sensor_fault
 *      node simulate.js --mode=no_rpm
 *      node simulate.js --disconnect-after=6
 * 2. Imported as `ChamberSimulator` by `server.js` for the optional built-in
 *    dashboard simulator toggle.
 *
 * IMPORTANT:
 * Every simulated reading sets `is_simulated: true` so the server and web UI
 * clearly distinguish simulated sensor / RPM telemetry from physical hardware.
 */

import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export class ChamberSimulator {
  constructor({
    serverUrl = `http://127.0.0.1:${process.env.PORT || 3000}`,
    deviceId = process.env.DEFAULT_DEVICE_ID || 'chamber-01',
    deviceKey = process.env.DEVICE_KEY || 'chamber-01-local-secret-key',
    intervalMs = 5000,
    mode = 'normal',
    disconnectAfterTicks = null,
    logToConsole = false
  } = {}) {
    this.serverUrl = serverUrl.replace(/\/+$/, '');
    this.deviceId = deviceId;
    this.deviceKey = deviceKey;
    this.intervalMs = intervalMs;
    this.mode = mode; // 'normal' | 'high_temp' | 'low_temp' | 'high_humidity' | 'sensor_fault' | 'no_rpm' | 'offline'
    this.disconnectAfterTicks = disconnectAfterTicks;
    this.logToConsole = logToConsole;

    this.running = false;
    this.timer = null;
    this.tickCount = 0;
    this.lastError = null;
    this.lastSentAt = null;

    // Local simulated physics state (mirrors ESP32 local state machine)
    this.temp = 18.2;
    this.humidity = 45.0;
    this.coolingOn = false;
    this.lastCoolingSwitchMs = Date.now() - 240_000;
    this.commandedFanPercent = 35;

    // Last valid configuration received from laptop server (persists if server disconnects)
    this.config = {
      config_version: 1,
      target_temp: 17.5,
      temp_min: 15.0,
      temp_max: 20.0,
      cooling_on_temp: 18.2,
      cooling_off_temp: 16.8,
      min_compressor_off_sec: 15, // Faster cycle in simulation while modeling real delay logic
      min_compressor_on_sec: 10,
      fan_min_percent: 25,
      fan_max_percent: 85,
      control_mode: 'auto',
      manual_fan_percent: 45
    };
  }

  setMode(newMode) {
    const allowed = [
      'normal',
      'high_temp',
      'low_temp',
      'high_humidity',
      'sensor_fault',
      'no_rpm',
      'offline'
    ];
    if (allowed.includes(newMode)) {
      this.mode = newMode;
    }
    return this.getStatus();
  }

  start() {
    if (this.running) return this.getStatus();
    this.running = true;
    this.step().catch(() => {});
    this.timer = setInterval(() => {
      this.step().catch(() => {});
    }, this.intervalMs);
    if (typeof this.timer.unref === 'function') {
      this.timer.unref();
    }
    return this.getStatus();
  }

  stop() {
    this.running = false;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    return this.getStatus();
  }

  getStatus() {
    return {
      running: this.running,
      device_id: this.deviceId,
      mode: this.mode,
      interval_ms: this.intervalMs,
      tick_count: this.tickCount,
      temp: Number(this.temp.toFixed(2)),
      humidity: Number(this.humidity.toFixed(1)),
      cooling_on: this.coolingOn,
      fan_speed_percent: this.commandedFanPercent,
      last_sent_at: this.lastSentAt,
      last_error: this.lastError
    };
  }

  /**
   * Executes one local control & telemetry step:
   * 1. Polls approved configuration from GET /api/device/config (unless simulating offline).
   * 2. Runs local temperature hysteresis + PWM fan ramp calculation.
   * 3. Sends reading to POST /api/device/readings.
   */
  async step() {
    this.tickCount += 1;

    if (
      this.disconnectAfterTicks !== null &&
      this.tickCount > this.disconnectAfterTicks
    ) {
      this.mode = 'offline';
    }

    // 1. Poll configuration from laptop server if online
    if (this.mode !== 'offline') {
      try {
        const cfgRes = await fetch(
          `${this.serverUrl}/api/device/config?device_id=${encodeURIComponent(this.deviceId)}`,
          {
            method: 'GET',
            headers: {
              'X-Device-Key': this.deviceKey,
              Accept: 'application/json'
            },
            signal: AbortSignal.timeout(3000)
          }
        );

        if (cfgRes.ok) {
          const incoming = await cfgRes.json();
          if (this.validateReceivedConfig(incoming)) {
            this.config = {
              ...this.config,
              ...incoming,
              // Keep short compressor delay in simulator so students can observe relay transitions quickly
              min_compressor_off_sec: 15,
              min_compressor_on_sec: 10
            };
          }
        } else if (this.logToConsole) {
          console.error(`[SIM] Config fetch HTTP ${cfgRes.status}`);
        }
      } catch (err) {
        this.lastError = err instanceof Error ? err.message : String(err);
        if (this.logToConsole) {
          console.error(
            `[SIM] Server unreachable (${this.lastError}) — continuing local control loop.`
          );
        }
      }
    }

    // 2. Run local physics + control loop
    this.updateLocalPhysicsAndControl();

    if (this.mode === 'offline') {
      if (this.logToConsole) {
        console.log(
          `[SIM OFFLINE] Local loop active | Temp=${this.temp.toFixed(2)}°C | Fan=${this.commandedFanPercent}% | Cooling=${this.coolingOn ? 'ON' : 'OFF'} (radio disconnected)`
        );
      }
      return this.getStatus();
    }

    // 3. Construct telemetry payload
    const sensorOk = this.mode !== 'sensor_fault';
    // Simulated 4-wire PC/industrial DC fan: ~450 RPM at 20% up to ~2200 RPM at 100%
    const simulatedRpm =
      this.mode === 'no_rpm'
        ? null
        : this.commandedFanPercent <= 0
          ? 0
          : Math.round(
              260 +
                (this.commandedFanPercent / 100) * 1940 +
                (Math.random() - 0.5) * 28
            );

    const payload = {
      device_id: this.deviceId,
      temp: sensorOk ? Number(this.temp.toFixed(2)) : null,
      humidity: sensorOk ? Number(this.humidity.toFixed(1)) : null,
      fan_speed_percent: this.commandedFanPercent,
      fan_rpm: simulatedRpm,
      cooling_on: this.coolingOn,
      sensor_ok: sensorOk,
      is_simulated: true,
      applied_config: {
        config_version: this.config.config_version,
        target_temp: this.config.target_temp,
        temp_min: this.config.temp_min,
        temp_max: this.config.temp_max,
        cooling_on_temp: this.config.cooling_on_temp,
        cooling_off_temp: this.config.cooling_off_temp,
        fan_min_percent: this.config.fan_min_percent,
        fan_max_percent: this.config.fan_max_percent,
        control_mode: this.config.control_mode,
        manual_fan_percent: this.config.manual_fan_percent
      },
      diagnostics: {
        firmware: 'sim-esp32-v1.0',
        wifi_rssi_dbm: -54 + Math.round((Math.random() - 0.5) * 6),
        uptime_sec: this.tickCount * Math.round(this.intervalMs / 1000),
        mode: this.mode
      }
    };

    try {
      const postRes = await fetch(`${this.serverUrl}/api/device/readings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-Key': this.deviceKey
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(3000)
      });

      if (!postRes.ok) {
        const errBody = await postRes.text();
        this.lastError = `HTTP ${postRes.status}: ${errBody}`;
        if (this.logToConsole) {
          console.error(`[SIM ERROR] ${this.lastError}`);
        }
      } else {
        this.lastError = null;
        this.lastSentAt = new Date().toISOString();
        if (this.logToConsole) {
          console.log(
            `[SIM OK] ${this.lastSentAt} | Temp=${sensorOk ? payload.temp + '°C' : 'FAULT'} | RH=${sensorOk ? payload.humidity + '%' : 'FAULT'} | Fan=${payload.fan_speed_percent}% (${payload.fan_rpm !== null ? payload.fan_rpm + ' sim RPM' : 'RPM N/A'}) | Cooling=${this.coolingOn ? 'ON' : 'OFF'}`
          );
        }
      }
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err);
      if (this.logToConsole) {
        console.error(`[SIM NETWORK ERROR] ${this.lastError}`);
      }
    }

    return this.getStatus();
  }

  validateReceivedConfig(cfg) {
    if (!cfg || typeof cfg !== 'object') return false;
    if (!Number.isFinite(cfg.target_temp) || !Number.isFinite(cfg.temp_min) || !Number.isFinite(cfg.temp_max)) {
      return false;
    }
    if (cfg.temp_min >= cfg.temp_max) return false;
    if (cfg.cooling_on_temp - cfg.cooling_off_temp < 0.5) return false;
    if (cfg.fan_min_percent < 0 || cfg.fan_max_percent > 100 || cfg.fan_min_percent > cfg.fan_max_percent) {
      return false;
    }
    return true;
  }

  updateLocalPhysicsAndControl() {
    const now = Date.now();
    const cfg = this.config;

    // Fault fallback: turn off compressor safely and hold moderate air circulation
    if (this.mode === 'sensor_fault') {
      this.coolingOn = false;
      this.commandedFanPercent = Math.min(cfg.fan_max_percent, Math.max(cfg.fan_min_percent, 40));
      return;
    }

    // Scenario overrides for testing threshold alerts cleanly
    if (this.mode === 'high_temp') {
      this.temp = cfg.temp_max + 2.1 + (Math.random() - 0.5) * 0.3;
      this.humidity = 46.0 + (Math.random() - 0.5) * 1.2;
    } else if (this.mode === 'low_temp') {
      this.temp = cfg.temp_min - 1.8 + (Math.random() - 0.5) * 0.3;
      this.humidity = 44.0 + (Math.random() - 0.5) * 1.2;
    } else if (this.mode === 'high_humidity') {
      this.temp = cfg.target_temp + (Math.random() - 0.5) * 0.4;
      this.humidity = 64.5 + (Math.random() - 0.5) * 1.5;
    } else {
      // Realistic chamber thermal drift:
      // Warm ambient heat ingress (+0.11 °C/step) vs active compressor cooling (-0.24 °C/step)
      const noise = (Math.random() - 0.5) * 0.12;
      const delta = this.coolingOn ? -0.22 : +0.11;
      this.temp = Math.max(4.0, Math.min(34.0, this.temp + delta + noise));

      // Gentle relative humidity drift around 44.5% RH
      const rhPull = (44.5 - this.humidity) * 0.14;
      const rhCoolingEffect = this.coolingOn ? -0.15 : +0.1;
      this.humidity = Math.max(
        25.0,
        Math.min(85.0, this.humidity + rhPull + rhCoolingEffect + (Math.random() - 0.5) * 0.6)
      );
    }

    // Separate Cooling Hysteresis + Minimum ON/OFF Compressor Protection
    const elapsedSinceSwitchSec = (now - this.lastCoolingSwitchMs) / 1000;
    if (!this.coolingOn) {
      if (
        this.temp >= cfg.cooling_on_temp &&
        elapsedSinceSwitchSec >= cfg.min_compressor_off_sec
      ) {
        this.coolingOn = true;
        this.lastCoolingSwitchMs = now;
      }
    } else {
      if (
        this.temp <= cfg.cooling_off_temp &&
        elapsedSinceSwitchSec >= cfg.min_compressor_on_sec
      ) {
        this.coolingOn = false;
        this.lastCoolingSwitchMs = now;
      }
    }

    // Separate Circulation Fan Control (Auto ramp vs Manual override)
    let desiredFan = cfg.fan_min_percent;
    if (cfg.control_mode === 'manual') {
      desiredFan = Math.min(cfg.fan_max_percent, Math.max(cfg.fan_min_percent, cfg.manual_fan_percent));
    } else {
      // Prototype Automatic Strategy:
      // Near or below target_temp -> fan_min_percent
      // Rising from target_temp toward temp_max -> smooth ramp up to fan_max_percent
      if (this.temp <= cfg.target_temp) {
        desiredFan = cfg.fan_min_percent;
      } else if (this.temp >= cfg.temp_max) {
        desiredFan = cfg.fan_max_percent;
      } else {
        const span = Math.max(0.5, cfg.temp_max - cfg.target_temp);
        const ratio = (this.temp - cfg.target_temp) / span;
        desiredFan = Math.round(
          cfg.fan_min_percent + ratio * (cfg.fan_max_percent - cfg.fan_min_percent)
        );
      }
    }

    // Ramp-rate limit (max 15% step per 5s tick) to prevent abrupt speed jumps
    const maxStep = 15;
    const diff = desiredFan - this.commandedFanPercent;
    if (Math.abs(diff) <= maxStep) {
      this.commandedFanPercent = desiredFan;
    } else {
      this.commandedFanPercent += Math.sign(diff) * maxStep;
    }
  }
}

// Run standalone CLI simulator if executed directly (`node simulate.js ...`)
const currentFile = fileURLToPath(import.meta.url);
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(currentFile)) {
  const args = Object.fromEntries(
    process.argv.slice(2).map((arg) => {
      const cleaned = arg.replace(/^--/, '');
      const [k, v] = cleaned.split('=');
      return [k, v === undefined ? 'true' : v];
    })
  );

  const serverUrl = args.url || `http://127.0.0.1:${process.env.PORT || 3000}`;
  const deviceId = args.device || process.env.DEFAULT_DEVICE_ID || 'chamber-01';
  const deviceKey = args.key || process.env.DEVICE_KEY || 'chamber-01-local-secret-key';
  let mode = args.mode || 'normal';
  if (args['breach-temp'] === 'true') mode = 'high_temp';
  if (args['breach-humidity'] === 'true') mode = 'high_humidity';
  if (args['sensor-fault'] === 'true') mode = 'sensor_fault';
  if (args['no-rpm'] === 'true') mode = 'no_rpm';

  const disconnectAfter = args['disconnect-after']
    ? Number(args['disconnect-after'])
    : null;

  console.log('==============================================================');
  console.log(' AgriSeed Monitor — Hardware-Free ESP32 Local Simulator');
  console.log(` Target Server : ${serverUrl}`);
  console.log(` Device ID     : ${deviceId}`);
  console.log(` Scenario Mode : ${mode} (all values flagged as SIMULATED)`);
  if (disconnectAfter) {
    console.log(` Auto-Offline  : after ${disconnectAfter} readings`);
  }
  console.log(' Press Ctrl+C to stop.');
  console.log('==============================================================');

  const sim = new ChamberSimulator({
    serverUrl,
    deviceId,
    deviceKey,
    intervalMs: 5000,
    mode,
    disconnectAfterTicks: disconnectAfter,
    logToConsole: true
  });

  sim.start();
}
