/**
 * test-acceptance.js
 * ----------------------------------------------------------------------------
 * Automated runnable acceptance test suite verifying direct local dashboard
 * access (no login/signup screen), CSRF protection, SQLite persistence,
 * device-key protocol, invalid reading rejection, narrow hysteresis rejection,
 * batch day math, alert cooldowns & auto-recovery, history pagination (50/page)
 * & CSV export, and offline/stale detection.
 */

import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from './server.js';
import { initDatabase } from './db.js';
import { runMaintenanceChecks } from './jobs.js';

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'agriseed-test-'));
const testDbPath = path.join(tmpDir, 'test-app.db');

delete process.env.SMTP_HOST;
process.env.DEVICE_OFFLINE_SECONDS = '10';
process.env.ALERT_COOLDOWN_MINUTES = '15';

class TestClient {
  constructor(baseUrl) {
    this.baseUrl = baseUrl;
    this.cookie = '';
    this.csrfToken = '';
  }

  async request(urlPath, { method = 'GET', body, headers = {} } = {}) {
    const reqHeaders = { ...headers };
    if (this.cookie) reqHeaders.Cookie = this.cookie;
    if (this.csrfToken && method !== 'GET') {
      reqHeaders['X-CSRF-Token'] = this.csrfToken;
    }
    let payload = body;
    if (body && typeof body === 'object') {
      reqHeaders['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    }

    const res = await fetch(`${this.baseUrl}${urlPath}`, {
      method,
      headers: reqHeaders,
      body: payload
    });

    const setCookie = res.headers.get('set-cookie');
    if (setCookie) {
      this.cookie = setCookie.split(';')[0];
    }

    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('application/json') ? await res.json() : await res.text();
    if (data && typeof data === 'object' && data.csrfToken) {
      this.csrfToken = data.csrfToken;
    }
    return { status: res.status, data, headers: res.headers };
  }
}

async function runTests() {
  console.log('Running AgriSeed Monitor Acceptance Suite...\n');

  const { app, db } = createApp({ customDbPath: testDbPath });
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;
  const deviceKey = process.env.DEVICE_KEY || 'chamber-01-local-secret-key';

  try {
    // 1. Health & Missing SMTP Startup Resilience
    const health = await fetch(`${baseUrl}/api/health`).then((r) => r.json());
    assert.equal(health.status, 'ok');
    assert.equal(health.smtp_configured, false);
    console.log('PASS [1/9] Server started cleanly without SMTP or internet.');

    // 2. Direct Dashboard Access (No Sign-In / Create Account Screen) & CSRF Protection
    const rootHtml = await fetch(`${baseUrl}/`).then((r) => r.text());
    assert.ok(rootHtml.includes('Dashboard Overview'));
    assert.ok(!rootHtml.includes('Create Account'));

    const client = new TestClient(baseUrl);
    const sessionRes = await client.request('/api/auth/me');
    assert.equal(sessionRes.status, 200);
    assert.equal(sessionRes.data.authenticated, true);
    assert.ok(sessionRes.data.csrfToken);

    // State-changing route must still enforce CSRF token
    const noCsrfPut = await fetch(`${baseUrl}/api/devices/chamber-01/config`, {
      method: 'PUT',
      headers: {
        Cookie: client.cookie,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ target_temp: 18.0 })
    });
    assert.equal(noCsrfPut.status, 403);
    console.log('PASS [2/9] Direct dashboard access (no login screen) and CSRF guard verified.');

    // 3. SQLite Persistence Check Across Re-Open
    const secondDbHandle = initDatabase(testDbPath);
    const profileCount = secondDbHandle
      .prepare('SELECT COUNT(*) AS c FROM seed_profiles')
      .get().c;
    assert.equal(profileCount, 6);
    secondDbHandle.close();
    console.log('PASS [3/9] SQLite persistence and 6 starter provisional seed profiles verified.');

    // 4. Device Authentication & Invalid Sensor Reading Rejection
    const unauthDev = await fetch(`${baseUrl}/api/device/readings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Device-Key': 'wrong-key' },
      body: JSON.stringify({
        device_id: 'chamber-01',
        temp: 18.0,
        humidity: 45.0,
        fan_speed_percent: 40,
        cooling_on: false
      })
    });
    assert.equal(unauthDev.status, 401);

    const invalidTemp = await fetch(`${baseUrl}/api/device/readings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Device-Key': deviceKey },
      body: JSON.stringify({
        device_id: 'chamber-01',
        temp: 145.0,
        humidity: 45.0,
        fan_speed_percent: 40,
        cooling_on: false
      })
    });
    assert.equal(invalidTemp.status, 400);
    console.log('PASS [4/9] Unauthorised device keys and out-of-range readings rejected.');

    // 5. Unsafe Control Configuration Rejection
    const unsafeCfg = await client.request('/api/devices/chamber-01/config', {
      method: 'PUT',
      body: {
        target_temp: 17.5,
        temp_min: 15.0,
        temp_max: 20.0,
        cooling_off_temp: 17.4,
        cooling_on_temp: 17.6,
        fan_min_percent: 25,
        fan_max_percent: 85,
        control_mode: 'auto'
      }
    });
    assert.equal(unsafeCfg.status, 400);
    console.log('PASS [5/9] Unsafe narrow hysteresis configuration rejected to protect relay.');

    // 6. Batch Management & Date Math Verification
    const batchesInit = await client.request('/api/batches');
    const starterBatch = batchesInit.data.batches[0];
    assert.ok(starterBatch);

    await client.request(`/api/batches/${starterBatch.id}/close`, { method: 'POST' });

    const profilesRes = await client.request('/api/seed-profiles');
    const maize = profilesRes.data.profiles.find((p) => p.name === 'Maize');
    const createBatch = await client.request('/api/batches', {
      method: 'POST',
      body: {
        device_id: 'chamber-01',
        seed_profile_id: maize.id,
        label: 'Maize Test Batch',
        quantity_kg: 120,
        planned_days: 210
      }
    });
    assert.equal(createBatch.status, 201);
    const maizeBatchId = createBatch.data.batch.id;

    const tenDaysAgo = new Date(Date.now() - 10 * 86_400_000 - 5000).toISOString();
    db.prepare('UPDATE batches SET started_at = ? WHERE id = ?').run(tenDaysAgo, maizeBatchId);

    const dashCheck = await client.request('/api/dashboard?device_id=chamber-01');
    assert.equal(dashCheck.data.active_batch.days_stored, 10);
    assert.equal(dashCheck.data.active_batch.days_remaining, 200);
    console.log('PASS [6/9] Batch creation, single-active constraint, and stored/remaining days verified.');

    // 7. Readings, Alert Cooldowns & Auto-Recovery
    for (let i = 0; i < 55; i++) {
      const r = await fetch(`${baseUrl}/api/device/readings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Device-Key': deviceKey },
        body: JSON.stringify({
          device_id: 'chamber-01',
          temp: 16.5,
          humidity: 44.0,
          fan_speed_percent: 35,
          fan_rpm: i % 2 === 0 ? null : 1120,
          cooling_on: i % 3 === 0,
          sensor_ok: true,
          is_simulated: true
        })
      });
      assert.equal(r.status, 201);
    }

    for (let j = 0; j < 2; j++) {
      await fetch(`${baseUrl}/api/device/readings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Device-Key': deviceKey },
        body: JSON.stringify({
          device_id: 'chamber-01',
          temp: 21.4,
          humidity: 44.0,
          fan_speed_percent: 85,
          fan_rpm: null,
          cooling_on: true,
          sensor_ok: true,
          is_simulated: true
        })
      });
    }

    const alertsAfterBreach = await client.request('/api/alerts?device_id=chamber-01');
    const highTempAlerts = alertsAfterBreach.data.alerts.filter((a) => a.kind === 'high_temp');
    assert.equal(highTempAlerts.length, 1);

    await fetch(`${baseUrl}/api/device/readings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Device-Key': deviceKey },
      body: JSON.stringify({
        device_id: 'chamber-01',
        temp: 16.4,
        humidity: 44.0,
        fan_speed_percent: 30,
        fan_rpm: null,
        cooling_on: false,
        sensor_ok: true,
        is_simulated: true
      })
    });

    const alertsAfterRecovery = await client.request('/api/alerts?device_id=chamber-01');
    const recoveredAlert = alertsAfterRecovery.data.alerts.find((a) => a.kind === 'high_temp');
    assert.ok(recoveredAlert.resolved_at);
    console.log('PASS [7/9] Alert trigger, cooldown deduplication, and auto-recovery verified.');

    // 8. History Pagination (50 rows/page) & CSV Export
    const histPage1 = await client.request('/api/history?device_id=chamber-01&range=24h&page=1');
    assert.equal(histPage1.data.readings.length, 50);
    assert.equal(histPage1.data.pagination.total_rows, 58);
    assert.equal(histPage1.data.pagination.total_pages, 2);

    const csvRes = await client.request('/api/history/export?device_id=chamber-01&range=24h');
    assert.equal(csvRes.status, 200);
    assert.ok(csvRes.data.includes('fan_command_percent,fan_measured_rpm'));
    console.log('PASS [8/9] History 50-row pagination, summary stats, and CSV export verified.');

    // 9. Offline Device & Stale Reading Detection
    const stalePast = new Date(Date.now() - 45_000).toISOString();
    db.prepare('UPDATE devices SET last_seen_at = ? WHERE id = ?').run(stalePast, 'chamber-01');
    await runMaintenanceChecks(db);

    const staleDash = await client.request('/api/dashboard?device_id=chamber-01');
    assert.equal(staleDash.data.device.connectivity.is_online, false);
    assert.equal(staleDash.data.device.connectivity.is_stale, true);
    assert.equal(staleDash.data.visual_status.level, 'grey');
    console.log('PASS [9/9] Offline chamber detection and stale reading marking verified.');

    console.log('\nALL 9 AUTOMATED ACCEPTANCE SUITES PASSED.');
  } finally {
    server.close();
    db.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

runTests().catch((err) => {
  console.error('ACCEPTANCE TEST FAILED:', err);
  process.exit(1);
});
