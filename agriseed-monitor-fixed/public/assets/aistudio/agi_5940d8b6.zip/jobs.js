/**
 * jobs.js
 * ----------------------------------------------------------------------------
 * Background scheduled maintenance using `node-cron`:
 * 1. Offline device detection when heartbeats stop arriving.
 * 2. Automatic expiration of manual fan overrides back to `auto` mode.
 * 3. Scheduled seed batch storage duration reminders.
 */

import cron from 'node-cron';
import { computeBatchDayMetrics, nowUtc } from './db.js';
import { raiseAlertWithCooldown } from './controller.js';

export async function runMaintenanceChecks(db) {
  const nowIso = nowUtc();
  const offlineSec = Math.max(10, Number(process.env.DEVICE_OFFLINE_SECONDS || 30));
  const offlineCutoffIso = new Date(Date.now() - offlineSec * 1000).toISOString();

  // 1. Expire timed-out manual fan overrides back to safe automatic mode
  const expiredOverrides = db
    .prepare(
      `SELECT device_id FROM device_config
       WHERE control_mode = 'manual'
         AND manual_expires_at IS NOT NULL
         AND manual_expires_at <= ?`
    )
    .all(nowIso);

  if (expiredOverrides.length > 0) {
    const revertStmt = db.prepare(`
      UPDATE device_config
      SET control_mode = 'auto',
          manual_expires_at = NULL,
          config_version = config_version + 1,
          updated_at = ?
      WHERE device_id = ?
    `);
    for (const row of expiredOverrides) {
      revertStmt.run(nowIso, row.device_id);
    }
  }

  // 2. Detect devices that stopped sending readings and mark them offline
  const staleDevices = db
    .prepare(
      `SELECT id, user_id, last_seen_at
       FROM devices
       WHERE status != 'offline'
         AND last_seen_at IS NOT NULL
         AND last_seen_at < ?`
    )
    .all(offlineCutoffIso);

  for (const dev of staleDevices) {
    db.prepare(`UPDATE devices SET status = 'offline' WHERE id = ?`).run(dev.id);
    if (dev.user_id) {
      const activeBatch = db
        .prepare(`SELECT id FROM batches WHERE device_id = ? AND status = 'active' LIMIT 1`)
        .get(dev.id);

      await raiseAlertWithCooldown(db, {
        userId: dev.user_id,
        deviceId: dev.id,
        batchId: activeBatch ? activeBatch.id : null,
        kind: 'device_offline',
        message: `Chamber ${dev.id} has not reported for over ${offlineSec}s. ESP32 continues local temperature control using its last valid configuration.`
      });
    }
  }

  // 3. Check active batches nearing or exceeding planned storage duration
  const activeBatches = db
    .prepare(
      `SELECT id, user_id, device_id, label, started_at, planned_days
       FROM batches
       WHERE status = 'active'`
    )
    .all();

  for (const batch of activeBatches) {
    const metrics = computeBatchDayMetrics(batch.started_at, batch.planned_days);
    if (metrics.is_overdue) {
      await raiseAlertWithCooldown(db, {
        userId: batch.user_id,
        deviceId: batch.device_id,
        batchId: batch.id,
        kind: 'batch_overdue',
        message: `Seed batch "${batch.label}" has reached its planned storage limit (${batch.planned_days} days). Inspect seed viability.`
      });
    } else if (metrics.days_remaining <= 7) {
      await raiseAlertWithCooldown(db, {
        userId: batch.user_id,
        deviceId: batch.device_id,
        batchId: batch.id,
        kind: 'batch_expiring',
        message: `Seed batch "${batch.label}" has ${metrics.days_remaining} day(s) remaining out of ${batch.planned_days} planned days.`
      });
    }
  }
}

export function startScheduledJobs(db) {
  // Run maintenance every minute via node-cron, plus a 10-second interval for snappy offline detection
  const cronTask = cron.schedule('* * * * *', () => {
    runMaintenanceChecks(db).catch((err) => {
      console.error('[jobs] Scheduled check error:', err.message);
    });
  });

  const fastTimer = setInterval(() => {
    runMaintenanceChecks(db).catch((err) => {
      console.error('[jobs] Fast check error:', err.message);
    });
  }, 10_000);

  if (typeof fastTimer.unref === 'function') {
    fastTimer.unref();
  }

  return {
    stop() {
      cronTask.stop();
      clearInterval(fastTimer);
    }
  };
}
