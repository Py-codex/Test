/**
 * server.js
 * ----------------------------------------------------------------------------
 * Local Express + SQLite application server for AgriSeed Monitor.
 *
 * Responsibilities:
 * - Serves plain HTML5, CSS3, and vanilla JS frontend from `public/`.
 * - Provides session-based user authentication (bcryptjs + express-session + CSRF + rate limit).
 * - Exposes local ESP32 HTTP protocol (`/api/device/readings`, `/api/device/config`, `/api/device/status`).
 * - Enforces strict resource ownership on every batch, device config, history export, and alert route.
 * - Runs wholly on the local Wi-Fi network without requiring internet access.
 */

import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import session from 'express-session';
import bcrypt from 'bcryptjs';

import { initDatabase, nowUtc, computeBatchDayMetrics } from './db.js';
import { PROVISIONAL_DISCLAIMER } from './seed-data.js';
import {
  verifyDeviceCredentials,
  ensureUserHasChamber,
  registerNewDevice,
  validateIncomingReading,
  recordDeviceStatusUpdate,
  computeDeviceConnectivity,
  isConfigAcknowledged
} from './device-manager.js';
import {
  validateControlConfig,
  buildDeviceConfigPayload,
  evaluateReadingAlerts,
  computeVisualChamberStatus
} from './controller.js';
import { startScheduledJobs } from './jobs.js';
import { isSmtpConfigured } from './mailer.js';
import { ChamberSimulator } from './simulate.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createApp({ customDbPath } = {}) {
  const db = initDatabase(customDbPath);
  const app = express();

  // Parse JSON payloads with strict size limit and catch malformed JSON cleanly
  app.use(express.json({ limit: '64kb' }));
  app.use((err, _req, res, next) => {
    if (err instanceof SyntaxError && 'body' in err) {
      return res.status(400).json({ error: 'Malformed JSON request body.' });
    }
    return next(err);
  });

  // Trust 1 proxy hop when previewed behind a reverse proxy while staying compatible with direct LAN HTTP
  app.set('trust proxy', 1);

  const sessionSecret =
    process.env.SESSION_SECRET || 'local-agriseed-prototype-session-secret-key';

  app.use(
    session({
      name: 'agriseed.sid',
      secret: sessionSecret,
      resave: false,
      saveUninitialized: false,
      rolling: true,
      cookie: {
        httpOnly: true,
        sameSite: 'lax',
        // Local HTTP over LAN (e.g. http://192.168.1.5:3000) requires secure=false
        secure: false,
        maxAge: 7 * 24 * 60 * 60 * 1000
      }
    })
  );

  // Automatically attach the local operator profile + CSRF token to every local session
  function ensureLocalOperatorSession(req) {
    if (!req.session.userId) {
      const localOperator = db
        .prepare('SELECT id FROM users ORDER BY id ASC LIMIT 1')
        .get();
      if (localOperator) {
        req.session.userId = localOperator.id;
        ensureUserHasChamber(db, localOperator.id);
      }
    }
    if (!req.session.csrfToken) {
      req.session.csrfToken = crypto.randomBytes(24).toString('hex');
    }
    return req.session.csrfToken;
  }

  function requireAuth(req, _res, next) {
    ensureLocalOperatorSession(req);
    return next();
  }

  function requireCsrf(req, res, next) {
    const expected = req.session ? req.session.csrfToken : null;
    const provided = req.get('X-CSRF-Token') || (req.body && req.body._csrf);
    if (!expected || !provided || provided !== expected) {
      return res.status(403).json({
        error: 'Invalid or missing CSRF token. Refresh the page and try again.'
      });
    }
    return next();
  }

  // Helper: fetch a device ONLY if owned by the logged-in user
  function getOwnedDevice(userId, requestedDeviceId) {
    if (requestedDeviceId) {
      return db
        .prepare('SELECT * FROM devices WHERE id = ? AND user_id = ?')
        .get(String(requestedDeviceId).trim(), userId);
    }
    return db
      .prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY created_at ASC LIMIT 1')
      .get(userId);
  }

  // Device authentication helper for ESP32 / Simulator endpoints
  function authenticateDeviceRequest(req, res) {
    const deviceId =
      (req.body && req.body.device_id) ||
      req.query.device_id ||
      req.get('X-Device-Id');
    const rawKey =
      req.get('X-Device-Key') ||
      (req.body && req.body.device_key);

    if (!deviceId || !rawKey) {
      res.status(401).json({
        error: 'Missing device_id or X-Device-Key authentication header.'
      });
      return null;
    }

    const device = verifyDeviceCredentials(db, String(deviceId), String(rawKey));
    if (!device) {
      res.status(401).json({
        error: 'Unauthorised device credentials or unknown device_id.'
      });
      return null;
    }
    return device;
  }

  // Optional built-in background simulator instance (bound to local loopback)
  let builtInSimulator = null;
  function getOrCreateSimulator(port) {
    if (!builtInSimulator) {
      builtInSimulator = new ChamberSimulator({
        serverUrl: `http://127.0.0.1:${port}`,
        deviceId: process.env.DEFAULT_DEVICE_ID || 'chamber-01',
        deviceKey: process.env.DEVICE_KEY || 'chamber-01-local-secret-key',
        intervalMs: 5000,
        mode: 'normal',
        logToConsole: false
      });
    }
    return builtInSimulator;
  }

  // ==========================================================================
  // 1. HEALTH & LOCAL NETWORK INFO
  // ==========================================================================
  app.get('/api/health', (_req, res) => {
    const dbOk = Boolean(db.prepare('SELECT 1 AS ok').get());
    res.json({
      status: dbOk ? 'ok' : 'degraded',
      timestamp_utc: nowUtc(),
      offline_capable: true,
      smtp_configured: isSmtpConfigured()
    });
  });

  app.get('/api/network-info', requireAuth, (req, res) => {
    const nets = os.networkInterfaces();
    const addresses = [];
    for (const [name, list] of Object.entries(nets)) {
      for (const iface of list || []) {
        if (iface.family === 'IPv4' && !iface.internal) {
          addresses.push({ interface: name, ip: iface.address });
        }
      }
    }
    const port = Number(process.env.PORT) || 3000;
    res.json({
      port,
      lan_addresses: addresses,
      example_url:
        addresses.length > 0
          ? `http://${addresses[0].ip}:${port}`
          : `http://192.168.1.5:${port}`,
      default_device_id: process.env.DEFAULT_DEVICE_ID || 'chamber-01',
      smtp_configured: isSmtpConfigured(),
      user_owns_default: Boolean(
        getOwnedDevice(req.session.userId, process.env.DEFAULT_DEVICE_ID || 'chamber-01')
      )
    });
  });

  app.get('/api/firmware/download', requireAuth, (_req, res) => {
    const fwPath = path.join(__dirname, 'firmware', 'seed_chamber.ino');
    if (!fs.existsSync(fwPath)) {
      return res.status(404).json({ error: 'Firmware sketch not found.' });
    }
    return res.download(fwPath, 'seed_chamber.ino');
  });

  // ==========================================================================
  // 2. LOCAL SESSION & CSRF BOOTSTRAP ROUTES (No Sign-In / Signup Required)
  // ==========================================================================
  app.get('/api/auth/csrf', (req, res) => {
    const token = ensureLocalOperatorSession(req);
    res.json({ csrfToken: token });
  });

  app.get('/api/auth/me', (req, res) => {
    const csrfToken = ensureLocalOperatorSession(req);
    const user = db
      .prepare('SELECT id, email, created_at FROM users WHERE id = ?')
      .get(req.session.userId);

    const devices = user
      ? db
          .prepare(
            'SELECT id, device_name, status, last_seen_at, created_at FROM devices WHERE user_id = ? ORDER BY created_at ASC'
          )
          .all(user.id)
      : [];

    return res.json({
      authenticated: true,
      user,
      devices,
      csrfToken
    });
  });

  // ==========================================================================
  // 3. LOCAL ESP32 DEVICE PROTOCOL ENDPOINTS (X-Device-Key Authenticated)
  // ==========================================================================
  app.get('/api/device/config', (req, res) => {
    const device = authenticateDeviceRequest(req, res);
    if (!device) return;

    const configRow = db
      .prepare('SELECT * FROM device_config WHERE device_id = ?')
      .get(device.id);
    if (!configRow) {
      return res.status(404).json({ error: 'Configuration missing for device.' });
    }

    const activeBatch = db
      .prepare(
        `SELECT b.*, sp.rh_min, sp.rh_max, sp.name AS profile_name
         FROM batches b
         JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE b.device_id = ? AND b.status = 'active'
         LIMIT 1`
      )
      .get(device.id);

    return res.json(buildDeviceConfigPayload(configRow, activeBatch || null));
  });

  app.post('/api/device/readings', async (req, res) => {
    const device = authenticateDeviceRequest(req, res);
    if (!device) return;

    const validation = validateIncomingReading(req.body);
    if (!validation.valid) {
      return res.status(400).json({ error: validation.error });
    }

    const r = validation.value;
    const now = nowUtc();

    const activeBatch = db
      .prepare(
        `SELECT b.*, sp.rh_min, sp.rh_max, sp.name AS profile_name
         FROM batches b
         JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE b.device_id = ? AND b.status = 'active'
         LIMIT 1`
      )
      .get(device.id);

    const batchId = activeBatch ? activeBatch.id : null;

    const info = db
      .prepare(
        `INSERT INTO readings (
           device_id, batch_id, temp, humidity,
           fan_speed_percent, fan_rpm, cooling_on,
           sensor_ok, is_simulated, created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        device.id,
        batchId,
        r.temp,
        r.humidity,
        r.fan_speed_percent,
        r.fan_rpm,
        r.cooling_on,
        r.sensor_ok,
        r.is_simulated,
        now
      );

    await recordDeviceStatusUpdate(db, device, {
      sensor_ok: Boolean(r.sensor_ok),
      applied_config: r.applied_config,
      diagnostics: r.diagnostics
    });

    const configRow = db
      .prepare('SELECT * FROM device_config WHERE device_id = ?')
      .get(device.id);

    if (configRow) {
      await evaluateReadingAlerts(db, {
        device,
        config: configRow,
        activeBatch,
        reading: {
          temp: r.temp,
          humidity: r.humidity,
          sensor_ok: Boolean(r.sensor_ok)
        }
      });
    }

    return res.status(201).json({
      ok: true,
      reading_id: Number(info.lastInsertRowid),
      recorded_at: now,
      config_version: configRow ? configRow.config_version : 1
    });
  });

  app.post('/api/device/status', async (req, res) => {
    const device = authenticateDeviceRequest(req, res);
    if (!device) return;

    if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
      return res.status(400).json({ error: 'Status payload must be a JSON object.' });
    }

    await recordDeviceStatusUpdate(db, device, {
      sensor_ok: req.body.sensor_ok !== false,
      applied_config: req.body.applied_config,
      diagnostics: req.body.diagnostics,
      config_rejected: Boolean(req.body.config_rejected),
      rejection_reason: req.body.rejection_reason
    });

    return res.json({ ok: true, updated_at: nowUtc() });
  });

  // ==========================================================================
  // 4. SEED PROFILES, DEVICES & CONFIGURATION ROUTES
  // ==========================================================================
  app.get('/api/seed-profiles', requireAuth, (_req, res) => {
    const profiles = db
      .prepare('SELECT * FROM seed_profiles ORDER BY id ASC')
      .all();
    res.json({
      disclaimer: PROVISIONAL_DISCLAIMER,
      profiles
    });
  });

  app.get('/api/devices', requireAuth, (req, res) => {
    const rows = db
      .prepare(
        'SELECT id, device_name, status, last_seen_at, last_ack_at, created_at FROM devices WHERE user_id = ? ORDER BY created_at ASC'
      )
      .all(req.session.userId);
    res.json({
      devices: rows.map((d) => ({
        ...d,
        connectivity: computeDeviceConnectivity(d)
      }))
    });
  });

  app.post('/api/devices', requireAuth, requireCsrf, (req, res) => {
    const result = registerNewDevice(db, {
      userId: req.session.userId,
      deviceId: req.body && req.body.device_id,
      deviceName: req.body && req.body.device_name,
      deviceKey: req.body && req.body.device_key
    });
    if (!result.ok) {
      return res.status(400).json({ error: result.error });
    }
    return res.status(201).json({ device: result.device });
  });

  app.put('/api/devices/:deviceId/config', requireAuth, requireCsrf, (req, res) => {
    const device = getOwnedDevice(req.session.userId, req.params.deviceId);
    if (!device) {
      return res.status(404).json({ error: 'Chamber not found or access denied.' });
    }

    const currentConfig = db
      .prepare('SELECT * FROM device_config WHERE device_id = ?')
      .get(device.id);

    const validation = validateControlConfig(req.body || {}, currentConfig);
    if (!validation.valid) {
      return res.status(400).json({
        error: validation.errors[0],
        errors: validation.errors
      });
    }

    const v = validation.value;
    const now = nowUtc();

    db.prepare(`
      UPDATE device_config
      SET target_temp = ?,
          temp_min = ?,
          temp_max = ?,
          cooling_on_temp = ?,
          cooling_off_temp = ?,
          fan_min_percent = ?,
          fan_max_percent = ?,
          manual_fan_percent = ?,
          control_mode = ?,
          manual_expires_at = ?,
          config_version = config_version + 1,
          updated_at = ?
      WHERE device_id = ?
    `).run(
      v.target_temp,
      v.temp_min,
      v.temp_max,
      v.cooling_on_temp,
      v.cooling_off_temp,
      v.fan_min_percent,
      v.fan_max_percent,
      v.manual_fan_percent,
      v.control_mode,
      v.manual_expires_at,
      now,
      device.id
    );

    const updated = db
      .prepare('SELECT * FROM device_config WHERE device_id = ?')
      .get(device.id);

    return res.json({
      ok: true,
      config: updated,
      reconciliation: isConfigAcknowledged(updated, device)
    });
  });

  app.post('/api/devices/:deviceId/return-auto', requireAuth, requireCsrf, (req, res) => {
    const device = getOwnedDevice(req.session.userId, req.params.deviceId);
    if (!device) {
      return res.status(404).json({ error: 'Chamber not found or access denied.' });
    }

    const now = nowUtc();
    db.prepare(`
      UPDATE device_config
      SET control_mode = 'auto',
          manual_expires_at = NULL,
          config_version = config_version + 1,
          updated_at = ?
      WHERE device_id = ?
    `).run(now, device.id);

    const updated = db
      .prepare('SELECT * FROM device_config WHERE device_id = ?')
      .get(device.id);

    return res.json({ ok: true, config: updated });
  });

  // ==========================================================================
  // 5. LIVE DASHBOARD AGGREGATE ENDPOINT
  // ==========================================================================
  app.get('/api/dashboard', requireAuth, (req, res) => {
    const device = getOwnedDevice(req.session.userId, req.query.device_id);
    if (!device) {
      return res.status(404).json({ error: 'No chamber bound to this account.' });
    }

    const config = db
      .prepare('SELECT * FROM device_config WHERE device_id = ?')
      .get(device.id);

    const activeBatchRow = db
      .prepare(
        `SELECT b.*, sp.name AS seed_name, sp.temp_min AS profile_temp_min,
                sp.temp_max AS profile_temp_max, sp.rh_min, sp.rh_max,
                sp.shelf_days, sp.notes AS profile_notes
         FROM batches b
         JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE b.device_id = ? AND b.status = 'active' AND b.user_id = ?
         LIMIT 1`
      )
      .get(device.id, req.session.userId);

    const activeBatch = activeBatchRow
      ? {
          ...activeBatchRow,
          ...computeBatchDayMetrics(activeBatchRow.started_at, activeBatchRow.planned_days)
        }
      : null;

    const latestReading = db
      .prepare(
        `SELECT r.*, sp.name AS seed_name, b.label AS batch_label
         FROM readings r
         LEFT JOIN batches b ON b.id = r.batch_id
         LEFT JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE r.device_id = ?
         ORDER BY r.created_at DESC, r.id DESC
         LIMIT 1`
      )
      .get(device.id);

    const recentReadingsDesc = db
      .prepare(
        `SELECT r.id, r.temp, r.humidity, r.fan_speed_percent, r.fan_rpm,
                r.cooling_on, r.sensor_ok, r.is_simulated, r.created_at,
                COALESCE(sp.name, 'Unassigned') AS seed_name,
                COALESCE(b.label, 'No Active Batch') AS batch_label
         FROM readings r
         LEFT JOIN batches b ON b.id = r.batch_id
         LEFT JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE r.device_id = ?
         ORDER BY r.created_at DESC, r.id DESC
         LIMIT 36`
      )
      .all(device.id);

    const connectivity = computeDeviceConnectivity(device);
    const reconciliation = isConfigAcknowledged(config, device);

    const rhMin = activeBatch ? activeBatch.rh_min : 35.0;
    const rhMax = activeBatch ? activeBatch.rh_max : 55.0;

    const visualStatus = computeVisualChamberStatus({
      isOnline: connectivity.is_online,
      isStale: connectivity.is_stale,
      latestReading,
      config,
      rhMin,
      rhMax,
      configSynced: reconciliation.synced
    });

    const activeAlerts = db
      .prepare(
        `SELECT id, device_id, batch_id, kind, message, created_at, acknowledged, resolved_at
         FROM alerts
         WHERE user_id = ? AND device_id = ? AND acknowledged = 0
         ORDER BY created_at DESC
         LIMIT 20`
      )
      .all(req.session.userId, device.id);

    let diagnostics = null;
    if (device.diagnostics_json) {
      try {
        diagnostics = JSON.parse(device.diagnostics_json);
      } catch {
        diagnostics = null;
      }
    }

    const defaultDeviceId = process.env.DEFAULT_DEVICE_ID || 'chamber-01';
    const simInfo =
      device.id === defaultDeviceId && builtInSimulator
        ? builtInSimulator.getStatus()
        : null;

    return res.json({
      server_time_utc: nowUtc(),
      device: {
        id: device.id,
        device_name: device.device_name,
        status: connectivity.is_online ? device.status : 'offline',
        last_seen_at: device.last_seen_at,
        last_ack_at: device.last_ack_at,
        diagnostics,
        connectivity
      },
      visual_status: visualStatus,
      allowed_ranges: {
        temp_min: config.temp_min,
        temp_max: config.temp_max,
        rh_min: rhMin,
        rh_max: rhMax
      },
      config,
      reconciliation,
      active_batch: activeBatch,
      latest_reading: latestReading || null,
      chart_points: [...recentReadingsDesc].reverse(),
      recent_logs: recentReadingsDesc.slice(0, 10),
      active_alerts: activeAlerts,
      simulator: simInfo
    });
  });

  // ==========================================================================
  // 6. BATCH MANAGEMENT ROUTES (Strict User Ownership + 1 Active per Chamber)
  // ==========================================================================
  app.get('/api/batches', requireAuth, (req, res) => {
    const rows = db
      .prepare(
        `SELECT b.*, sp.name AS seed_name, sp.temp_min, sp.temp_max, sp.rh_min, sp.rh_max, sp.shelf_days
         FROM batches b
         JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE b.user_id = ?
         ORDER BY CASE WHEN b.status = 'active' THEN 0 ELSE 1 END, b.started_at DESC`
      )
      .all(req.session.userId);

    const enriched = rows.map((b) => ({
      ...b,
      ...computeBatchDayMetrics(
        b.started_at,
        b.planned_days,
        b.closed_at ? Date.parse(b.closed_at) : Date.now()
      )
    }));

    res.json({ batches: enriched });
  });

  app.post('/api/batches', requireAuth, requireCsrf, (req, res) => {
    const body = req.body || {};
    const device = getOwnedDevice(req.session.userId, body.device_id);
    if (!device) {
      return res.status(404).json({ error: 'Target chamber not found or access denied.' });
    }

    const profileId = Number(body.seed_profile_id);
    const profile = db
      .prepare('SELECT * FROM seed_profiles WHERE id = ?')
      .get(profileId);
    if (!profile) {
      return res.status(400).json({ error: 'Selected seed profile does not exist.' });
    }

    const label = String(body.label || '').trim();
    if (label.length < 2 || label.length > 80) {
      return res
        .status(400)
        .json({ error: 'Batch label must be between 2 and 80 characters.' });
    }

    const quantityKg = Number(body.quantity_kg);
    if (!Number.isFinite(quantityKg) || quantityKg <= 0 || quantityKg > 50000) {
      return res
        .status(400)
        .json({ error: 'Quantity must be a positive number up to 50,000 kg.' });
    }

    const plannedDays = Math.round(Number(body.planned_days || profile.shelf_days));
    if (!Number.isFinite(plannedDays) || plannedDays < 1 || plannedDays > 3650) {
      return res
        .status(400)
        .json({ error: 'Planned storage days must be between 1 and 3,650 days.' });
    }

    const activeExisting = db
      .prepare("SELECT id, label FROM batches WHERE device_id = ? AND status = 'active'")
      .get(device.id);
    if (activeExisting) {
      return res.status(409).json({
        error: `Chamber ${device.id} already has an active batch ("${activeExisting.label}"). Close the current batch before starting a new one.`
      });
    }

    const now = nowUtc();
    let batchId;

    const createTx = db.transaction(() => {
      const info = db
        .prepare(
          `INSERT INTO batches (
             user_id, device_id, seed_profile_id, label,
             quantity_kg, started_at, planned_days, status
           ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')`
        )
        .run(
          req.session.userId,
          device.id,
          profile.id,
          label,
          Number(quantityKg.toFixed(2)),
          now,
          plannedDays
        );
      batchId = Number(info.lastInsertRowid);

      // Optionally sync chamber temperature envelope to the chosen seed profile
      if (body.apply_profile_temps !== false) {
        const midpoint = Number(((profile.temp_min + profile.temp_max) / 2).toFixed(1));
        const halfHyst = Math.max(
          0.4,
          Math.min(0.8, Number(((profile.temp_max - profile.temp_min) * 0.2).toFixed(1)))
        );
        db.prepare(`
          UPDATE device_config
          SET target_temp = ?,
              temp_min = ?,
              temp_max = ?,
              cooling_on_temp = ?,
              cooling_off_temp = ?,
              config_version = config_version + 1,
              updated_at = ?
          WHERE device_id = ?
        `).run(
          midpoint,
          profile.temp_min,
          profile.temp_max,
          Number((midpoint + halfHyst).toFixed(1)),
          Number((midpoint - halfHyst).toFixed(1)),
          now,
          device.id
        );
      }
    });
    createTx();

    const created = db.prepare('SELECT * FROM batches WHERE id = ?').get(batchId);
    return res.status(201).json({
      batch: {
        ...created,
        seed_name: profile.name,
        ...computeBatchDayMetrics(created.started_at, created.planned_days)
      }
    });
  });

  app.post('/api/batches/:batchId/close', requireAuth, requireCsrf, (req, res) => {
    const batchId = Number(req.params.batchId);
    if (!Number.isInteger(batchId) || batchId <= 0) {
      return res.status(400).json({ error: 'Invalid batch ID.' });
    }

    const batch = db
      .prepare('SELECT * FROM batches WHERE id = ? AND user_id = ?')
      .get(batchId, req.session.userId);

    if (!batch) {
      return res.status(404).json({ error: 'Batch not found or access denied.' });
    }

    if (batch.status === 'closed') {
      return res.status(400).json({ error: 'Batch is already closed.' });
    }

    const now = nowUtc();
    db.prepare(`UPDATE batches SET status = 'closed', closed_at = ? WHERE id = ? AND user_id = ?`).run(
      now,
      batchId,
      req.session.userId
    );

    return res.json({ ok: true, closed_at: now });
  });

  // ==========================================================================
  // 7. HISTORY, AGGREGATED CHARTS, PAGINATION (50/page) & CSV EXPORT
  // ==========================================================================
  function resolveRangeWindow(rangeParam) {
    const key = String(rangeParam || '24h').toLowerCase();
    if (key === '7d') {
      return { key: '7d', hours: 168, bucketSeconds: 1800 }; // 30-min buckets
    }
    if (key === '30d') {
      return { key: '30d', hours: 720, bucketSeconds: 7200 }; // 2-hour buckets
    }
    return { key: '24h', hours: 24, bucketSeconds: 300 }; // 5-min buckets (or raw if sparse)
  }

  app.get('/api/history', requireAuth, (req, res) => {
    const device = getOwnedDevice(req.session.userId, req.query.device_id);
    if (!device) {
      return res.status(404).json({ error: 'Chamber not found or access denied.' });
    }

    const { key: rangeKey, hours, bucketSeconds } = resolveRangeWindow(req.query.range);
    const sinceIso = new Date(Date.now() - hours * 3600_000).toISOString();

    const page = Math.max(1, Math.floor(Number(req.query.page) || 1));
    const pageSize = 50; // Strictly 50 rows per page per specification
    const offset = (page - 1) * pageSize;

    // 1. Summary statistics over raw readings in window
    const summary = db
      .prepare(
        `SELECT
           COUNT(*) AS sample_count,
           MIN(temp) AS temp_min,
           MAX(temp) AS temp_max,
           AVG(temp) AS temp_avg,
           MIN(humidity) AS humidity_min,
           MAX(humidity) AS humidity_max,
           AVG(humidity) AS humidity_avg,
           AVG(fan_speed_percent) AS fan_avg,
           AVG(cooling_on) * 100.0 AS cooling_duty_percent
         FROM readings
         WHERE device_id = ? AND created_at >= ?`
      )
      .get(device.id, sinceIso);

    // 2. Downsampled chart series (kept separate from raw table rows)
    let chartSeries;
    if (summary.sample_count <= 120) {
      chartSeries = db
        .prepare(
          `SELECT
             created_at AS bucket_time,
             temp AS avg_temp,
             humidity AS avg_humidity,
             fan_speed_percent AS avg_fan_percent,
             fan_rpm AS avg_fan_rpm,
             cooling_on * 100.0 AS cooling_duty_percent
           FROM readings
           WHERE device_id = ? AND created_at >= ?
           ORDER BY created_at ASC`
        )
        .all(device.id, sinceIso);
    } else {
      chartSeries = db
        .prepare(
          `SELECT
             MIN(created_at) AS bucket_time,
             ROUND(AVG(temp), 2) AS avg_temp,
             ROUND(AVG(humidity), 2) AS avg_humidity,
             ROUND(AVG(fan_speed_percent), 1) AS avg_fan_percent,
             ROUND(AVG(fan_rpm), 0) AS avg_fan_rpm,
             ROUND(AVG(cooling_on) * 100.0, 1) AS cooling_duty_percent,
             COUNT(*) AS bucket_samples
           FROM readings
           WHERE device_id = ? AND created_at >= ?
           GROUP BY CAST(strftime('%s', created_at) / ? AS INTEGER)
           ORDER BY bucket_time ASC`
        )
        .all(device.id, sinceIso, bucketSeconds);
    }

    // 3. Paginated raw readings (50 rows per page)
    const rawRows = db
      .prepare(
        `SELECT r.id, r.device_id, r.batch_id, r.temp, r.humidity,
                r.fan_speed_percent, r.fan_rpm, r.cooling_on,
                r.sensor_ok, r.is_simulated, r.created_at,
                COALESCE(sp.name, 'Unassigned') AS seed_name,
                COALESCE(b.label, '—') AS batch_label
         FROM readings r
         LEFT JOIN batches b ON b.id = r.batch_id
         LEFT JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE r.device_id = ? AND r.created_at >= ?
         ORDER BY r.created_at DESC, r.id DESC
         LIMIT ? OFFSET ?`
      )
      .all(device.id, sinceIso, pageSize, offset);

    const totalRows = Number(summary.sample_count || 0);
    const totalPages = Math.max(1, Math.ceil(totalRows / pageSize));

    return res.json({
      device_id: device.id,
      range: rangeKey,
      since_utc: sinceIso,
      summary: {
        sample_count: totalRows,
        temp_min: summary.temp_min !== null ? Number(summary.temp_min.toFixed(2)) : null,
        temp_max: summary.temp_max !== null ? Number(summary.temp_max.toFixed(2)) : null,
        temp_avg: summary.temp_avg !== null ? Number(summary.temp_avg.toFixed(2)) : null,
        humidity_min: summary.humidity_min !== null ? Number(summary.humidity_min.toFixed(1)) : null,
        humidity_max: summary.humidity_max !== null ? Number(summary.humidity_max.toFixed(1)) : null,
        humidity_avg: summary.humidity_avg !== null ? Number(summary.humidity_avg.toFixed(1)) : null,
        fan_avg: summary.fan_avg !== null ? Number(summary.fan_avg.toFixed(1)) : null,
        cooling_duty_percent:
          summary.cooling_duty_percent !== null
            ? Number(summary.cooling_duty_percent.toFixed(1))
            : null
      },
      chart_series: chartSeries,
      pagination: {
        page,
        page_size: pageSize,
        total_rows: totalRows,
        total_pages: totalPages
      },
      readings: rawRows
    });
  });

  app.get('/api/history/export', requireAuth, (req, res) => {
    const device = getOwnedDevice(req.session.userId, req.query.device_id);
    if (!device) {
      return res.status(404).json({ error: 'Chamber not found or access denied.' });
    }

    const { key: rangeKey, hours } = resolveRangeWindow(req.query.range);
    const sinceIso =
      req.query.range === 'all'
        ? '1970-01-01T00:00:00.000Z'
        : new Date(Date.now() - hours * 3600_000).toISOString();

    const rows = db
      .prepare(
        `SELECT r.id, r.created_at, r.device_id,
                COALESCE(b.label, '') AS batch_label,
                COALESCE(sp.name, '') AS seed_name,
                r.temp, r.humidity, r.fan_speed_percent, r.fan_rpm,
                r.cooling_on, r.sensor_ok, r.is_simulated
         FROM readings r
         LEFT JOIN batches b ON b.id = r.batch_id
         LEFT JOIN seed_profiles sp ON sp.id = b.seed_profile_id
         WHERE r.device_id = ? AND r.created_at >= ?
         ORDER BY r.created_at DESC, r.id DESC`
      )
      .all(device.id, sinceIso);

    const escapeCsv = (val) => {
      if (val === null || val === undefined) return '';
      const s = String(val);
      if (/[",\n\r]/.test(s)) {
        return `"${s.replace(/"/g, '""')}"`;
      }
      return s;
    };

    const header = [
      'id',
      'created_at_utc',
      'device_id',
      'batch_label',
      'seed_profile',
      'temp_c',
      'humidity_percent',
      'fan_command_percent',
      'fan_measured_rpm',
      'cooling_on',
      'sensor_ok',
      'source'
    ].join(',');

    const lines = rows.map((row) =>
      [
        row.id,
        row.created_at,
        row.device_id,
        row.batch_label,
        row.seed_name,
        row.temp,
        row.humidity,
        row.fan_speed_percent,
        row.fan_rpm !== null ? row.fan_rpm : 'unavailable',
        row.cooling_on ? 'ON' : 'OFF',
        row.sensor_ok ? 'OK' : 'FAULT',
        row.is_simulated ? 'SIMULATED' : 'HARDWARE'
      ]
        .map(escapeCsv)
        .join(',')
    );

    const csvContent = [header, ...lines].join('\r\n');
    const filename = `agriseed-${device.id}-${rangeKey}-${new Date().toISOString().slice(0, 10)}.csv`;

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(csvContent);
  });

  // ==========================================================================
  // 8. ALERTS & ACKNOWLEDGEMENT ROUTES (Strict User Ownership)
  // ==========================================================================
  app.get('/api/alerts', requireAuth, (req, res) => {
    const filter = String(req.query.filter || 'all').toLowerCase();
    const deviceId = req.query.device_id ? String(req.query.device_id).trim() : null;

    if (deviceId && !getOwnedDevice(req.session.userId, deviceId)) {
      return res.status(404).json({ error: 'Chamber not found or access denied.' });
    }

    let sql = `
      SELECT a.*, b.label AS batch_label
      FROM alerts a
      LEFT JOIN batches b ON b.id = a.batch_id
      WHERE a.user_id = ?
    `;
    const params = [req.session.userId];

    if (deviceId) {
      sql += ' AND a.device_id = ?';
      params.push(deviceId);
    }
    if (filter === 'active') {
      sql += ' AND a.acknowledged = 0';
    }
    sql += ' ORDER BY a.created_at DESC, a.id DESC LIMIT 100';

    const alerts = db.prepare(sql).all(...params);
    return res.json({ alerts });
  });

  app.post('/api/alerts/:alertId/acknowledge', requireAuth, requireCsrf, (req, res) => {
    const alertId = Number(req.params.alertId);
    if (!Number.isInteger(alertId) || alertId <= 0) {
      return res.status(400).json({ error: 'Invalid alert ID.' });
    }

    // Strict ownership enforcement: users can NEVER acknowledge another user's alert
    const alertRow = db
      .prepare('SELECT id, acknowledged FROM alerts WHERE id = ? AND user_id = ?')
      .get(alertId, req.session.userId);

    if (!alertRow) {
      return res.status(404).json({ error: 'Alert not found or access denied.' });
    }

    const now = nowUtc();
    db.prepare(
      'UPDATE alerts SET acknowledged = 1, acknowledged_at = ? WHERE id = ? AND user_id = ?'
    ).run(now, alertId, req.session.userId);

    return res.json({ ok: true, acknowledged_at: now });
  });

  // ==========================================================================
  // 9. BUILT-IN SIMULATOR CONTROLS (For Hardware-Free Browser Testing)
  // ==========================================================================
  app.get('/api/simulator/status', requireAuth, (req, res) => {
    const defaultDeviceId = process.env.DEFAULT_DEVICE_ID || 'chamber-01';
    const ownsDefault = Boolean(getOwnedDevice(req.session.userId, defaultDeviceId));
    if (!ownsDefault) {
      return res.json({ available: false, reason: 'Default chamber belongs to another local user.' });
    }
    const port = Number(process.env.PORT) || 3000;
    const sim = getOrCreateSimulator(port);
    return res.json({ available: true, ...sim.getStatus() });
  });

  app.post('/api/simulator/control', requireAuth, requireCsrf, async (req, res) => {
    const defaultDeviceId = process.env.DEFAULT_DEVICE_ID || 'chamber-01';
    const ownsDefault = Boolean(getOwnedDevice(req.session.userId, defaultDeviceId));
    if (!ownsDefault) {
      return res.status(403).json({ error: 'Only the owner of chamber-01 can control its built-in simulator.' });
    }

    const port = req.socket.localPort || Number(process.env.PORT) || 3000;
    const sim = getOrCreateSimulator(port);
    sim.serverUrl = `http://127.0.0.1:${port}`;

    const action = String((req.body && req.body.action) || '').toLowerCase();
    const mode = req.body && req.body.mode ? String(req.body.mode) : null;

    if (mode) {
      sim.setMode(mode);
    }

    if (action === 'start') {
      sim.start();
    } else if (action === 'stop') {
      sim.stop();
    } else if (action === 'step') {
      await sim.step();
    } else if (action === 'set_mode' && mode) {
      if (sim.running) {
        await sim.step();
      }
    } else {
      return res.status(400).json({ error: 'Unsupported simulator action.' });
    }

    return res.json({ available: true, ...sim.getStatus() });
  });

  // ==========================================================================
  // 10. STATIC FRONTEND ROUTES (Direct Dashboard Access — No Login Screen)
  // ==========================================================================
  const publicDir = path.join(__dirname, 'public');
  app.get(['/', '/index.html'], (_req, res) => {
    res.sendFile(path.join(publicDir, 'dashboard.html'));
  });
  app.use(express.static(publicDir));

  app.use('/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  return { app, db, getOrCreateSimulator };
}

// Start server when executed directly (`npm start` / `node server.js`)
const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(__filename);
if (isMain) {
  const host = process.env.HOST || '0.0.0.0';
  const port = Number(process.env.PORT) || 3000;

  const { app, db, getOrCreateSimulator } = createApp();
  const jobs = startScheduledJobs(db);

  const server = app.listen(port, host, () => {
    console.log(`AgriSeed Monitor running on http://${host}:${port}`);

    // Start built-in simulator by default unless explicitly disabled via AUTO_START_SIMULATOR=false
    const autoSim = String(process.env.AUTO_START_SIMULATOR ?? 'true').toLowerCase() !== 'false';
    if (autoSim) {
      const sim = getOrCreateSimulator(port);
      sim.serverUrl = `http://127.0.0.1:${port}`;
      sim.start();
      console.log(`Built-in hardware-free simulator active for ${sim.deviceId} (5s interval).`);
    }
  });

  const shutdown = () => {
    jobs.stop();
    server.close(() => {
      db.close();
      process.exit(0);
    });
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
