# AgriSeed Monitor — Smart Seed Storage Refrigerator

An offline-first local IoT monitoring and environmental control prototype designed for smallholder farmers and school agricultural innovation challenges.

The system pairs an **autonomous ESP32 controller** (regulating cooling hysteresis and a PWM DC circulation fan locally) with a **Node.js + Express + SQLite laptop server** and a mobile-friendly **vanilla HTML5/CSS3/JS dashboard** operating completely over a local Wi-Fi router **without requiring internet access**.

---

## 1. System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                LOCAL WI-FI ROUTER (NO INTERNET REQUIRED)                │
└──────────────────┬───────────────────────────────────┬──────────────────┘
                   │ Local HTTP + X-Device-Key         │ Local HTTP + Session + CSRF
                   ▼                                   ▼
      ┌──────────────────────────┐        ┌──────────────────────────┐
      │ ESP32 Seed Controller    │        │ Phone / Laptop Browser   │
      │ • DHT22 (GPIO 4)         │        │ • Dashboard Overview     │
      │ • PWM Fan Driver (GPIO25)│        │ • Live Dual-Axis Charts  │
      │ • Cooling Relay (GPIO 26)│        │ • Seed Batch Tracking    │
      │ • Autonomous Local Loop  │        │ • 50-row Logs & CSV      │
      └────────────┬─────────────┘        └────────────┬─────────────┘
                   │                                   │
                   └─────────────────┬─────────────────┘
                                     ▼
                    ┌──────────────────────────────────┐
                    │ Laptop Server (Node.js + Express)│
                    │ • SQLite (`data/app.db`)         │
                    │ • Alert Cooldowns & Auto-Resolve │
                    │ • Optional SMTP Email (if online)│
                    └──────────────────────────────────┘
```

---

## 2. Hardware & Software Prerequisites

### Laptop Server Software
- **Node.js 18+** (tested on Node 18 / 20 / 22) and `npm`.
- Any modern mobile or desktop web browser on the same Wi-Fi network.

### Physical Chamber Hardware (Optional when using Simulator)
- **ESP32 Development Board** (e.g., ESP32-WROOM-32 DevKitC).
- **DHT22 (AM2302)** temperature & relative humidity sensor + `4.7 kΩ–10 kΩ` pull-up resistor between `DATA` and `3.3V`.
- **PWM-compatible DC Circulation Fan** driven through a **logic-level N-channel MOSFET driver or dedicated 4-wire PWM fan interface** (never power a fan directly from an ESP32 GPIO!).
- **Opto-isolated Relay / Contactor / SSR Interface** properly rated for the cooling unit's inductive/compressor load (never drive a compressor directly from an ESP32 GPIO!).
- **Arduino IDE 2.x** with `esp32` board package + libraries:
  - `DHT sensor library` by Adafruit (+ `Adafruit Unified Sensor`)
  - `ArduinoJson` by Benoit Blanchon

---

## 3. Installation & Quick Start

```bash
# 1. Install dependencies (run once while setting up the laptop)
npm install

# 2. Optional: Copy .env.example to .env and customise secrets
cp .env.example .env

# 3. Start the local server (automatically creates data/app.db and starter profiles)
npm start
```

Open **`http://localhost:3000`** on the laptop (or `http://<LAPTOP-LAN-IP>:3000` from a phone on the same Wi-Fi).

---

## 4. Environment Configuration (`.env`)

| Variable | Default | Purpose |
| :--- | :--- | :--- |
| `HOST` | `0.0.0.0` | Binds Express to all local network interfaces so phones and ESP32 can connect over Wi-Fi. |
| `PORT` | `3000` | Local HTTP port. |
| `SESSION_SECRET` | *(change before demo)* | Signs `httpOnly` session cookies. |
| `DEFAULT_DEVICE_ID` | `chamber-01` | Identifier matching `firmware/seed_chamber.ino` and `simulate.js`. |
| `DEVICE_KEY` | `chamber-01-local-secret-key` | Shared secret verified against a `bcryptjs` hash in SQLite. |
| `DEVICE_OFFLINE_SECONDS` | `30` | Marks chamber offline and dims stale readings after this silence window. |
| `ALERT_COOLDOWN_MINUTES` | `15` | Deduplicates repeated alerts of the same kind. |
| `MANUAL_OVERRIDE_MINUTES` | `30` | Automatically reverts manual fan overrides back to `auto` mode. |
| `AUTO_START_SIMULATOR` | `true` | Starts built-in loopback simulator automatically (`set false` when using physical ESP32!). |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` | *(blank)* | Optional email notifications. Leave blank for offline operation. |

> **Transport Security Note**: Plain HTTP + `X-Device-Key` is suitable only on a trusted private local Wi-Fi network. Never port-forward or expose port `3000` directly to the public internet.

---

## 5. Finding Your Laptop's Local LAN IP & Firewall Setup

When connected to your Wi-Fi router (or a phone hotspot with client isolation disabled), find your laptop's IPv4 address:

- **Windows (Command Prompt / PowerShell)**:
  ```powershell
  ipconfig
  ```
  Look under **Wireless LAN adapter Wi-Fi** -> **IPv4 Address** (for example `192.168.1.5`).
- **macOS**:
  ```bash
  ipconfig getifaddr en0
  ```
- **Linux**:
  ```bash
  hostname -I
  ```

You can also view the detected LAN URL directly inside the dashboard's **WiFi Connection** tab!

### Firewall Rule
Ensure your laptop firewall allows inbound **TCP port `3000`** on **Private / Local** networks:
- **Windows Defender Firewall**: Allow `Node.js JavaScript Runtime` or inbound TCP `3000` on *Private* networks.
- **Ubuntu (`ufw`)**: `sudo ufw allow from 192.168.0.0/16 to any port 3000 proto tcp`

---

## 6. Database Behaviour (`data/app.db`)

- Uses **SQLite** (`better-sqlite3`) in **WAL** mode with `PRAGMA foreign_keys = ON` and prepared statements.
- Automatically creates `users`, `seed_profiles`, `devices`, `device_config`, `batches`, `readings`, and `alerts` on first startup and retains all records across restarts.
- Stores all timestamps in **UTC ISO-8601** (`YYYY-MM-DDTHH:MM:SS.sssZ`).
- Calculates `days_stored = floor((now_utc - started_at_utc) / 86400s)` and `days_remaining = max(0, planned_days - days_stored)`.
- Enforces **one active seed batch per physical chamber** via a partial unique index (`WHERE status = 'active'`).

---

## 7. Simulator Instructions (Hardware-Free Testing)

You can test without physical ESP32 hardware in two ways:

1. **In-App Simulator Console**: Open **WiFi Connection** in the left sidebar to start/pause the simulator or inject `High Temp`, `Low Temp`, `High Humidity`, `DHT22 Sensor Fault`, `2-Wire Fan (No RPM)`, or `Offline Disconnect`.
2. **Standalone Terminal Simulator (`simulate.js`)**:
   Set `AUTO_START_SIMULATOR=false` in `.env` if you want only the CLI simulator posting readings, then run:
   ```bash
   # Normal thermal hysteresis & PWM fan ramping
   npm run simulate

   # Simulate high temperature threshold breach
   node simulate.js --mode=high_temp

   # Simulate DHT22 sensor failure fallback
   node simulate.js --mode=sensor_fault

   # Simulate 2-wire fan without tachometer RPM wire
   node simulate.js --mode=no_rpm

   # Simulate Wi-Fi disconnect after 5 readings
   node simulate.js --disconnect-after=5
   ```
   All simulated readings are explicitly tagged as **Simulated** in the dashboard and CSV exports.

---

## 8. ESP32 Firmware Installation & Hardware Wiring (`firmware/seed_chamber.ino`)

### Pin Assignments (Verify against your specific ESP32 board!)
| Function | Suggested GPIO | Hardware Interface Requirement |
| :--- | :--- | :--- |
| **DHT22 Data** | `GPIO 4` | `3.3V` power + `4.7kΩ–10kΩ` pull-up resistor to `3.3V`. |
| **PWM Circulation Fan** | `GPIO 25` | 25 kHz PWM signal into a **4-wire PWM fan control pin** or **logic-level MOSFET low-side driver** with flyback diode. Never connect motor power to GPIO! |
| **Cooling Control** | `GPIO 26` | Drives an **opto-isolated relay / SSR / contactor** rated for the cooling compressor's locked-rotor and inductive current. |
| **Status LED** | `GPIO 2` | Solid when Wi-Fi & sensor OK; fast blink during `SENSOR_FAULT`. |
| **Optional Fan Tach** | `GPIO 27` | Keep `HAS_TACHOMETER = false` unless a `3.3V`-safe open-collector tach wire is installed. |

### Flashing Steps
1. Set `AUTO_START_SIMULATOR=false` in `.env` on your laptop so simulated readings don't mix with real ESP32 data.
2. Open `firmware/seed_chamber.ino` in Arduino IDE.
3. Update `WIFI_SSID`, `WIFI_PASSWORD`, `SERVER_BASE` (`http://<LAPTOP-LAN-IP>:3000`), and `DEVICE_KEY`.
4. Select your ESP32 board (works with both ESP32 Arduino Core `2.x` and `3.x`), upload, and open Serial Monitor at `115200` baud.

---

## 9. Safety Limitations & Agricultural Data Verification

1. **Not a Substitute for Primary Electrical/Refrigeration Cutouts**: This web dashboard and microcontroller prototype is a monitoring and supervisory controller. Real refrigeration compressors must retain their independent manufacturer overload protectors, pressure switches, thermal fuses, and proper earthing.
2. **Circulation Fan vs. Active Cooling**: A circulation fan only equalises temperature and airflow inside the cabinet — **a fan alone cannot lower chamber temperature**; the cooling unit must remove heat.
3. **Sensor Fault Limitation**: If the DHT22 disconnects or fails validation, the ESP32 disables the cooling relay safely, holds moderate airflow (`40%`), and raises a `sensor_failure` alarm. Safe seed storage cannot be guaranteed while the sensor is faulty.
4. **Provisional Seed Storage Profiles**: The starter profiles (*Wheat*, *Barley*, *Rice*, *Maize*, *Chickpea*, *Mustard*) use **unverified demonstration values**. Always verify crop-specific seed moisture, temperature, and RH standards with **ICAR**, **NBPGR**, or **FAO** guidelines before storing farmer seed lots.

---

## 10. Troubleshooting & Automated Acceptance Tests

- **Phone or ESP32 cannot reach `http://<LAN-IP>:3000`**: Confirm both devices are on the same `2.4 GHz` local Wi-Fi network (guest networks often enable AP client isolation) and port `3000` is permitted through your laptop firewall.
- **Dashboard shows "Pending ESP32 Sync"**: Configuration changes take effect on the hardware when the ESP32 next polls `GET /api/device/config` (every 5–10 seconds).
- **Run Automated Acceptance Test Suite**:
  ```bash
  npm test
  ```
