/**
 * seed-data.js
 * ----------------------------------------------------------------------------
 * Starter seed storage profiles inserted into SQLite only when the
 * `seed_profiles` table is empty.
 *
 * IMPORTANT AGRICULTURAL DISCLAIMER:
 * All temperature, relative humidity (RH), and shelf-life values below are
 * PROVISIONAL UNVERIFIED DEMONSTRATION VALUES created for a student engineering
 * prototype. Before storing real farmer seed stock, verify exact equilibrium
 * moisture content, temperature, and RH rules against official ICAR (Indian
 * Council of Agricultural Research), NBPGR (National Bureau of Plant Genetic
 * Resources), or FAO genebank standards.
 *
 * Notice also that different crops have distinct temperature and humidity
 * envelopes — do not assume one fixed refrigerator setting fits all seeds.
 */

export const PROVISIONAL_DISCLAIMER =
  'UNVERIFIED DEMO VALUES — Must be checked against authoritative ICAR, NBPGR, or FAO seed-storage guidelines before agricultural reliance.';

export const STARTER_SEED_PROFILES = [
  {
    name: 'Wheat',
    temp_min: 15.0,
    temp_max: 20.0,
    rh_min: 40.0,
    rh_max: 50.0,
    shelf_days: 360,
    notes:
      'Provisional demo profile (15–20 °C, 40–50% RH, 360 days). Keep grain dried to safe moisture before sealing chamber; verify against ICAR/NBPGR wheat storage standards.'
  },
  {
    name: 'Barley',
    temp_min: 15.0,
    temp_max: 20.0,
    rh_min: 40.0,
    rh_max: 50.0,
    shelf_days: 360,
    notes:
      'Provisional demo profile (15–20 °C, 40–50% RH, 360 days). Sensitive to high humidity germination loss; verify against ICAR/NBPGR barley recommendations.'
  },
  {
    name: 'Rice',
    temp_min: 15.0,
    temp_max: 20.0,
    rh_min: 40.0,
    rh_max: 50.0,
    shelf_days: 360,
    notes:
      'Provisional demo profile (15–20 °C, 40–50% RH, 360 days). Avoid condensation when removing paddy batches from cool storage; verify against ICAR/NBPGR standards.'
  },
  {
    name: 'Maize',
    temp_min: 15.0,
    temp_max: 18.0,
    rh_min: 40.0,
    rh_max: 50.0,
    shelf_days: 210,
    notes:
      'Provisional demo profile (15–18 °C, 40–50% RH, 210 days). Narrower upper temperature band and shorter medium-term storage horizon; verify against ICAR/NBPGR maize rules.'
  },
  {
    name: 'Chickpea',
    temp_min: 18.0,
    temp_max: 22.0,
    rh_min: 35.0,
    rh_max: 45.0,
    shelf_days: 330,
    notes:
      'Provisional demo profile (18–22 °C, 35–45% RH, 330 days). Pulse crops generally require lower relative humidity (35–45% RH) to deter bruchid and fungal activity; verify with ICAR/NBPGR.'
  },
  {
    name: 'Mustard',
    temp_min: 15.0,
    temp_max: 20.0,
    rh_min: 35.0,
    rh_max: 45.0,
    shelf_days: 300,
    notes:
      'Provisional demo profile (15–20 °C, 35–45% RH, 300 days). Oilseed crops have higher lipid content and need lower RH (35–45%) to prevent rancidity; verify with ICAR/NBPGR.'
  }
];
