/**
 * public/js/history.js
 * ----------------------------------------------------------------------------
 * Vanilla JavaScript controller for `history.html`:
 * - Supports 24h, 7d, and 30d aggregated charts (climate + fan/cooling state).
 * - Displays Min, Max, Average, and Sample Count summary metrics.
 * - Paginates raw SQLite readings at strictly 50 rows per page.
 * - Triggers authenticated CSV export and alert acknowledgements.
 */

(function () {
  const {
    apiFetch,
    checkSession,
    getSelectedDeviceId,
    bindSidebarShell,
    formatDateParts,
    escapeHtml
  } = window.AgriCommon;

  let currentRange = '24h';
  let currentPage = 1;
  let totalPages = 1;
  let alertFilter = 'all';

  let climateChart = null;
  let actuatorChart = null;

  function showNotice(msg, kind = 'error') {
    const el = document.getElementById('historyNotice');
    if (!el) return;
    el.textContent = msg;
    el.className = `feedback-banner ${kind}`;
    setTimeout(() => {
      if (el.textContent === msg) el.className = 'feedback-banner hidden';
    }, 5000);
  }

  function initCharts() {
    if (typeof window.Chart === 'undefined') return;

    const climateCtx = document.getElementById('historyClimateChart').getContext('2d');
    climateChart = new window.Chart(climateCtx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Temperature (°C)',
            data: [],
            yAxisID: 'yTemp',
            borderColor: '#184e31',
            backgroundColor: 'rgba(24, 78, 49, 0.14)',
            borderWidth: 2,
            fill: true,
            tension: 0.3,
            pointRadius: 1.5
          },
          {
            label: 'Humidity (%)',
            data: [],
            yAxisID: 'yRh',
            borderColor: '#7eb092',
            backgroundColor: 'rgba(126, 176, 146, 0.14)',
            borderWidth: 2,
            fill: true,
            tension: 0.3,
            pointRadius: 1.5
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { maxTicksLimit: 9, color: '#5d7062' } },
          yTemp: {
            type: 'linear',
            position: 'left',
            ticks: { color: '#184e31', callback: (v) => `${v}°C` }
          },
          yRh: {
            type: 'linear',
            position: 'right',
            grid: { drawOnChartArea: false },
            ticks: { color: '#4e7a61', callback: (v) => `${v}%` }
          }
        }
      }
    });

    const actCtx = document.getElementById('historyActuatorChart').getContext('2d');
    actuatorChart = new window.Chart(actCtx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Commanded Fan (%)',
            data: [],
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.12)',
            borderWidth: 2,
            fill: true,
            tension: 0.25,
            pointRadius: 1.5
          },
          {
            label: 'Cooling Duty (%)',
            data: [],
            borderColor: '#d97706',
            backgroundColor: 'rgba(217, 119, 6, 0.10)',
            borderWidth: 2,
            stepped: 'before',
            fill: false,
            pointRadius: 1
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { maxTicksLimit: 9, color: '#5d7062' } },
          y: {
            min: 0,
            max: 100,
            ticks: { color: '#5d7062', callback: (v) => `${v}%` }
          }
        }
      }
    });
  }

  async function loadHistory() {
    const deviceId = getSelectedDeviceId();
    const data = await apiFetch(
      `/api/history?device_id=${encodeURIComponent(deviceId)}&range=${encodeURIComponent(currentRange)}&page=${currentPage}`
    );

    const s = data.summary;
    document.getElementById('statSamples').textContent = `${s.sample_count}`;
    document.getElementById('statTempSummary').textContent =
      s.temp_avg !== null
        ? `${s.temp_min.toFixed(1)} / ${s.temp_avg.toFixed(1)} / ${s.temp_max.toFixed(1)} °C`
        : '—';
    document.getElementById('statRhSummary').textContent =
      s.humidity_avg !== null
        ? `${s.humidity_min.toFixed(0)} / ${s.humidity_avg.toFixed(0)} / ${s.humidity_max.toFixed(0)} %`
        : '—';
    document.getElementById('statFanCoolSummary').textContent =
      s.fan_avg !== null
        ? `${s.fan_avg.toFixed(0)}% Fan · ${s.cooling_duty_percent.toFixed(0)}% Cool`
        : '—';

    // Update Downsampled Charts
    const series = data.chart_series || [];
    const labels = series.map((pt) => {
      const dt = formatDateParts(pt.bucket_time);
      return currentRange === '24h' ? dt.time : `${dt.date.slice(5)} ${dt.time.slice(0, 5)}`;
    });

    if (climateChart) {
      climateChart.data.labels = labels;
      climateChart.data.datasets[0].data = series.map((pt) => pt.avg_temp);
      climateChart.data.datasets[1].data = series.map((pt) => pt.avg_humidity);
      climateChart.update('none');
    }

    if (actuatorChart) {
      actuatorChart.data.labels = labels;
      actuatorChart.data.datasets[0].data = series.map((pt) => pt.avg_fan_percent);
      actuatorChart.data.datasets[1].data = series.map((pt) => pt.cooling_duty_percent);
      actuatorChart.update('none');
    }

    // Update Raw Paginated Table (50 rows per page)
    const p = data.pagination;
    currentPage = p.page;
    totalPages = p.total_pages;

    document.getElementById('paginationInfoTop').textContent =
      `Page ${p.page} of ${p.total_pages} (50 rows/page)`;
    document.getElementById('paginationSummary').textContent =
      `Total ${p.total_rows} reading(s) in ${currentRange.toUpperCase()} window`;

    document.getElementById('prevPageBtn').disabled = p.page <= 1;
    document.getElementById('nextPageBtn').disabled = p.page >= p.total_pages;

    const tbody = document.getElementById('historyTableBody');
    const rows = data.readings || [];
    if (rows.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="10" style="text-align: center; color: var(--text-muted);">
            No readings found in the selected time range.
          </td>
        </tr>
      `;
    } else {
      tbody.innerHTML = rows
        .map((r) => {
          const dt = formatDateParts(r.created_at);
          return `
            <tr>
              <td>${dt.date}</td>
              <td>${dt.time}</td>
              <td>${escapeHtml(r.seed_name)} (${escapeHtml(r.batch_label)})</td>
              <td class="num">${r.sensor_ok && r.temp !== null ? r.temp.toFixed(2) : '—'}</td>
              <td class="num">${r.sensor_ok && r.humidity !== null ? r.humidity.toFixed(1) : '—'}</td>
              <td class="num">${r.fan_speed_percent.toFixed(0)}%</td>
              <td class="num">${r.fan_rpm !== null ? r.fan_rpm : 'Unavailable'}</td>
              <td>${r.cooling_on ? 'ON' : 'OFF'}</td>
              <td>${r.sensor_ok ? 'OK' : 'FAULT'}</td>
              <td>${r.is_simulated ? 'Simulated' : 'ESP32'}</td>
            </tr>
          `;
        })
        .join('');
    }
  }

  async function loadAlertsHistory() {
    const deviceId = getSelectedDeviceId();
    const res = await apiFetch(
      `/api/alerts?device_id=${encodeURIComponent(deviceId)}&filter=${encodeURIComponent(alertFilter)}`
    );
    const alerts = res.alerts || [];
    const tbody = document.getElementById('alertsHistoryBody');

    if (alerts.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; color: var(--text-muted);">
            No alerts recorded for this filter.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = alerts
      .map((a) => {
        const created = formatDateParts(a.created_at).full;
        const recovery = a.resolved_at
          ? `Recovered ${formatDateParts(a.resolved_at).full}`
          : 'Active / Unresolved';
        const actionCell = a.acknowledged
          ? `Acknowledged`
          : `<button type="button" class="btn btn-secondary btn-sm ack-history-btn" data-id="${a.id}">Acknowledge</button>`;

        return `
          <tr>
            <td>${created}</td>
            <td>${escapeHtml(a.device_id)}</td>
            <td>${escapeHtml(a.kind)}</td>
            <td style="white-space: normal; min-width: 240px;">${escapeHtml(a.message)}</td>
            <td>${recovery}</td>
            <td>${actionCell}</td>
          </tr>
        `;
      })
      .join('');

    tbody.querySelectorAll('.ack-history-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        try {
          await apiFetch(`/api/alerts/${btn.dataset.id}/acknowledge`, { method: 'POST' });
          await loadAlertsHistory();
        } catch (err) {
          showNotice(err.message, 'error');
          btn.disabled = false;
        }
      });
    });
  }

  function bindControls() {
    document.querySelectorAll('.range-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        currentRange = btn.dataset.range;
        currentPage = 1;
        document.querySelectorAll('.range-btn').forEach((b) => {
          b.className = `btn btn-sm range-btn ${b.dataset.range === currentRange ? 'btn-primary' : 'btn-secondary'}`;
        });
        loadHistory().catch((err) => showNotice(err.message));
      });
    });

    document.getElementById('prevPageBtn').addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage -= 1;
        loadHistory().catch((err) => showNotice(err.message));
      }
    });

    document.getElementById('nextPageBtn').addEventListener('click', () => {
      if (currentPage < totalPages) {
        currentPage += 1;
        loadHistory().catch((err) => showNotice(err.message));
      }
    });

    document.getElementById('exportCsvBtn').addEventListener('click', () => {
      const deviceId = getSelectedDeviceId();
      window.location.href = `/api/history/export?device_id=${encodeURIComponent(deviceId)}&range=${encodeURIComponent(currentRange)}`;
    });

    const allBtn = document.getElementById('filterAllAlertsBtn');
    const actBtn = document.getElementById('filterActiveAlertsBtn');
    allBtn.addEventListener('click', () => {
      alertFilter = 'all';
      allBtn.className = 'btn btn-primary btn-sm';
      actBtn.className = 'btn btn-secondary btn-sm';
      loadAlertsHistory().catch((err) => showNotice(err.message));
    });
    actBtn.addEventListener('click', () => {
      alertFilter = 'active';
      actBtn.className = 'btn btn-primary btn-sm';
      allBtn.className = 'btn btn-secondary btn-sm';
      loadAlertsHistory().catch((err) => showNotice(err.message));
    });
  }

  async function boot() {
    const sessionInfo = await checkSession({ redirectIfUnauth: true });
    if (!sessionInfo) return;

    bindSidebarShell();
    initCharts();
    bindControls();

    await Promise.all([loadHistory(), loadAlertsHistory()]);

    window.addEventListener('agriseed:device-changed', () => {
      currentPage = 1;
      loadHistory().catch(() => {});
      loadAlertsHistory().catch(() => {});
    });
  }

  boot().catch((err) => console.error('History init error:', err));
})();
