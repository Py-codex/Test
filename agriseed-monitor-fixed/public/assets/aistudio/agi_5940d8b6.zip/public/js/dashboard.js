/**
 * public/js/dashboard.js
 * ----------------------------------------------------------------------------
 * Vanilla JavaScript controller for `dashboard.html`:
 * - Polls `/api/dashboard` every 5 seconds with timeout & overlap protection.
 * - Distinguishes commanded PWM fan speed (%) from measured tachometer RPM
 *   (and labels simulated values vs hardware unavailable RPM).
 * - Renders the dual-axis local Chart.js real-time graph.
 * - Manages Control Panel settings, Seed Selection batches, WiFi/Simulator,
 *   and Seed Guide tabs.
 */

(function () {
  const {
    apiFetch,
    checkSession,
    getSelectedDeviceId,
    bindSidebarShell,
    formatDateParts,
    formatRelativeAge,
    escapeHtml,
    refreshSessionDevices
  } = window.AgriCommon;

  let seedProfiles = [];
  let latestDashboard = null;
  let controlModeDraft = 'auto';
  let formDirty = false;
  let pollTimer = null;
  let isPolling = false;
  let liveChart = null;

  // Live local clock ticker (1s)
  function startLiveClock() {
    const clockEl = document.getElementById('valLiveClock');
    const tick = () => {
      if (!clockEl) return;
      const now = new Date();
      clockEl.textContent = now.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    };
    tick();
    setInterval(tick, 1000);
  }

  function showNotice(message, kind = 'success') {
    const box = document.getElementById('globalNotice');
    if (!box) return;
    box.textContent = message;
    box.className = `feedback-banner ${kind}`;
    setTimeout(() => {
      if (box.textContent === message) {
        box.className = 'feedback-banner hidden';
      }
    }, 6000);
  }

  // Sidebar section switching (#overview, #wifi, #batches, #guide)
  function activateSection(sectionName) {
    const valid = ['overview', 'wifi', 'batches', 'guide'];
    const target = valid.includes(sectionName) ? sectionName : 'overview';

    document.querySelectorAll('.workspace-section').forEach((el) => {
      el.classList.toggle('hidden', el.id !== `section-${target}`);
    });

    document.querySelectorAll('.nav-item-btn[data-section]').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.section === target);
    });

    const sidebar = document.getElementById('appSidebar');
    if (sidebar) sidebar.classList.remove('open');

    if (window.location.hash !== `#${target}`) {
      history.replaceState(null, '', `#${target}`);
    }

    if (target === 'wifi') {
      loadNetworkInfo().catch(() => {});
    } else if (target === 'batches') {
      loadBatchesList().catch(() => {});
    }
  }

  function initSectionNavigation() {
    document.querySelectorAll('.nav-item-btn[data-section]').forEach((btn) => {
      btn.addEventListener('click', () => activateSection(btn.dataset.section));
    });

    const jumpBatchBtn = document.getElementById('manageBatchJumpBtn');
    if (jumpBatchBtn) {
      jumpBatchBtn.addEventListener('click', () => activateSection('batches'));
    }

    const initialHash = (window.location.hash || '#overview').replace(/^#/, '');
    activateSection(initialHash);
  }

  // Initialise local Chart.js Dual-Axis Real-Time Graph
  function initLiveChart() {
    const canvas = document.getElementById('liveDualChart');
    if (!canvas || typeof window.Chart === 'undefined') return;

    const ctx = canvas.getContext('2d');
    const tempGrad = ctx.createLinearGradient(0, 0, 0, 260);
    tempGrad.addColorStop(0, 'rgba(31, 92, 58, 0.24)');
    tempGrad.addColorStop(1, 'rgba(31, 92, 58, 0.01)');

    const rhGrad = ctx.createLinearGradient(0, 0, 0, 260);
    rhGrad.addColorStop(0, 'rgba(135, 181, 154, 0.22)');
    rhGrad.addColorStop(1, 'rgba(135, 181, 154, 0.01)');

    liveChart = new window.Chart(ctx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Temperature (°C)',
            data: [],
            yAxisID: 'yTemp',
            borderColor: '#184e31',
            backgroundColor: tempGrad,
            borderWidth: 2.3,
            fill: true,
            tension: 0.36,
            pointRadius: 2,
            pointHoverRadius: 5
          },
          {
            label: 'Humidity (%)',
            data: [],
            yAxisID: 'yRh',
            borderColor: '#7eb092',
            backgroundColor: rhGrad,
            borderWidth: 2,
            fill: true,
            tension: 0.36,
            pointRadius: 1.5,
            pointHoverRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1f2d24',
            titleColor: '#e6f0e8',
            bodyColor: '#ffffff',
            padding: 10,
            cornerRadius: 8
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(0, 0, 0, 0.04)' },
            ticks: { color: '#5d7062', maxTicksLimit: 8 }
          },
          yTemp: {
            type: 'linear',
            position: 'left',
            suggestedMin: 10,
            suggestedMax: 28,
            grid: { color: 'rgba(0, 0, 0, 0.06)' },
            ticks: {
              color: '#184e31',
              callback: (v) => `${v}°C`
            }
          },
          yRh: {
            type: 'linear',
            position: 'right',
            suggestedMin: 25,
            suggestedMax: 80,
            grid: { drawOnChartArea: false },
            ticks: {
              color: '#4e7a61',
              callback: (v) => `${v}%`
            }
          }
        }
      }
    });
  }

  function updateRadialGauge(percentValue, centerText) {
    const arc = document.getElementById('rpmGaugeArc');
    const label = document.getElementById('rpmGaugeCenter');
    const circumference = 2 * Math.PI * 25; // 157.08
    const clamped = Math.max(0, Math.min(100, Number(percentValue) || 0));
    const offset = circumference * (1 - clamped / 100);
    if (arc) {
      arc.style.strokeDashoffset = offset.toFixed(2);
    }
    if (label) {
      label.textContent = centerText;
    }
  }

  function renderDashboard(data) {
    latestDashboard = data;
    const {
      device,
      visual_status: vs,
      allowed_ranges: ranges,
      config,
      reconciliation,
      active_batch: batch,
      latest_reading: reading,
      chart_points: points,
      recent_logs: logs,
      active_alerts: alerts,
      simulator
    } = data;

    // 1. Health Status Strip
    const strip = document.getElementById('chamberStatusStrip');
    const statusTitle = document.getElementById('statusTitle');
    const statusDetail = document.getElementById('statusDetail');
    const glyphMap = { green: '●', amber: '▲', red: '✖', grey: '○' };

    strip.className = `status-strip ${vs.level}`;
    statusTitle.textContent = `${glyphMap[vs.level] || '○'} ${vs.label}`;
    statusDetail.textContent = vs.detail;

    const simQuickSummary = document.getElementById('simQuickSummary');
    const quickSimBtn = document.getElementById('quickSimToggleBtn');
    if (simulator) {
      quickSimBtn.classList.remove('hidden');
      simQuickSummary.textContent = simulator.running
        ? `Sim Active (${simulator.mode})`
        : 'Sim Paused';
      quickSimBtn.textContent = simulator.running ? 'Sim Settings' : 'Start Sim';
    } else {
      quickSimBtn.classList.add('hidden');
      simQuickSummary.textContent = '';
    }

    // 2. Device Freshness & Stale Guard
    const isStale = device.connectivity.is_stale;
    const freshnessEl = document.getElementById('deviceFreshnessText');
    const ageLabel = formatRelativeAge(device.connectivity.seconds_since_seen);
    freshnessEl.textContent = device.connectivity.is_online
      ? `${device.id} Online · Last reading ${ageLabel}`
      : `${device.id} Offline / Stale · Last seen ${ageLabel}`;

    ['cellTemp', 'cellHumidity', 'cellFan'].forEach((id) => {
      const cell = document.getElementById(id);
      if (cell) cell.classList.toggle('stale-dim', isStale);
    });

    // 3. Live Status Cells
    const valTemp = document.getElementById('valTemp');
    const subTemp = document.getElementById('subTemp');
    const valHumidity = document.getElementById('valHumidity');
    const subHumidity = document.getElementById('subHumidity');
    const valFanPrimary = document.getElementById('valFanPrimary');
    const subFan = document.getElementById('subFan');
    const subBatchClock = document.getElementById('subBatchClock');

    if (!reading) {
      valTemp.textContent = '—';
      valTemp.className = 'metric-value';
      subTemp.textContent = `Allowed ${ranges.temp_min.toFixed(1)}–${ranges.temp_max.toFixed(1)}°C · Target ${config.target_temp.toFixed(1)}°C`;

      valHumidity.textContent = '—';
      valHumidity.className = 'metric-value';
      subHumidity.textContent = `Allowed ${ranges.rh_min.toFixed(0)}–${ranges.rh_max.toFixed(0)}% RH`;

      valFanPrimary.textContent = '—';
      subFan.textContent = 'Waiting for telemetry';
      updateRadialGauge(0, '—');
    } else if (!reading.sensor_ok || reading.temp === null || reading.humidity === null) {
      valTemp.textContent = 'Sensor Fault';
      valTemp.className = 'metric-value fault';
      subTemp.textContent = `Fallback Active · Cooling OFF · Verify DHT22`;

      valHumidity.textContent = 'Sensor Fault';
      valHumidity.className = 'metric-value fault';
      subHumidity.textContent = `Allowed ${ranges.rh_min.toFixed(0)}–${ranges.rh_max.toFixed(0)}% RH`;

      valFanPrimary.textContent = `${reading.fan_speed_percent.toFixed(0)}% PWM`;
      subFan.textContent =
        reading.fan_rpm !== null
          ? `Fallback circulation · ${reading.fan_rpm} ${reading.is_simulated ? 'Sim ' : ''}RPM`
          : 'Fallback circulation · RPM Unavailable';
      updateRadialGauge(reading.fan_speed_percent, `${reading.fan_speed_percent.toFixed(0)}%`);
    } else {
      const stalePrefix = isStale ? 'Stale ' : '';
      valTemp.className = 'metric-value';
      valTemp.textContent = `${stalePrefix}${reading.temp.toFixed(1)}°C`;
      const coolingText = reading.cooling_on ? 'Cooling ON' : 'Cooling Standby';
      subTemp.textContent = `Allowed ${ranges.temp_min.toFixed(1)}–${ranges.temp_max.toFixed(1)}°C · Target ${config.target_temp.toFixed(1)}°C · ${coolingText}`;

      valHumidity.className = 'metric-value';
      valHumidity.textContent = `${stalePrefix}${reading.humidity.toFixed(1)}%`;
      subHumidity.textContent = `Allowed ${ranges.rh_min.toFixed(0)}–${ranges.rh_max.toFixed(0)}% RH · ${reading.is_simulated ? 'Simulated DHT22' : 'Hardware DHT22'}`;

      if (reading.fan_rpm !== null && reading.fan_rpm !== undefined) {
        valFanPrimary.textContent = `${reading.fan_rpm} RPM`;
        subFan.textContent = `Commanded: ${reading.fan_speed_percent.toFixed(0)}% (${config.control_mode === 'manual' ? 'Manual' : 'Auto'}) · ${reading.is_simulated ? 'Simulated RPM' : 'Measured RPM'}`;
        updateRadialGauge(reading.fan_speed_percent, 'RPM');
      } else {
        valFanPrimary.textContent = `${reading.fan_speed_percent.toFixed(0)}% PWM`;
        subFan.textContent = `Commanded: ${reading.fan_speed_percent.toFixed(0)}% (${config.control_mode === 'manual' ? 'Manual' : 'Auto'}) · Measured RPM Unavailable`;
        updateRadialGauge(reading.fan_speed_percent, `${reading.fan_speed_percent.toFixed(0)}%`);
      }
    }

    if (batch) {
      subBatchClock.textContent = `${batch.seed_name} (${batch.label}) · ${batch.days_stored}d stored · ${batch.days_remaining}d remaining`;
      document.getElementById('activeBatchHorizonBox').textContent =
        `${batch.days_stored}d stored / ${batch.days_remaining}d left`;
    } else {
      subBatchClock.textContent = 'No active seed batch — start one in Seed Selection';
      document.getElementById('activeBatchHorizonBox').textContent = 'No active batch';
    }

    // 4. Populate Control Panel if user isn't actively dragging sliders
    if (!formDirty) {
      syncControlFormFromConfig(config, batch);
    }
    renderReconciliationBar(config, reconciliation);

    // 5. Active Alerts
    renderActiveAlerts(alerts || []);

    // 6. Real-Time Chart
    if (liveChart && Array.isArray(points)) {
      liveChart.data.labels = points.map((p) => formatDateParts(p.created_at).time);
      liveChart.data.datasets[0].data = points.map((p) => (p.sensor_ok ? p.temp : null));
      liveChart.data.datasets[1].data = points.map((p) => (p.sensor_ok ? p.humidity : null));
      liveChart.update('none');
    }

    // 7. Recent Storage Logs Table
    renderRecentLogs(logs || []);

    // 8. Simulator & Config Previews in WiFi Section
    renderWifiTabState(config, reconciliation, simulator);
  }

  function syncControlFormFromConfig(config, batch) {
    controlModeDraft = config.control_mode;
    updateControlModeUI();

    document.getElementById('sliderTargetTemp').value = config.target_temp;
    document.getElementById('readoutTargetTemp').textContent = `${config.target_temp.toFixed(1)}°C`;

    document.getElementById('inputTempMin').value = config.temp_min.toFixed(1);
    document.getElementById('inputTempMax').value = config.temp_max.toFixed(1);
    document.getElementById('inputCoolOff').value = config.cooling_off_temp.toFixed(1);
    document.getElementById('inputCoolOn').value = config.cooling_on_temp.toFixed(1);

    document.getElementById('inputFanMin').value = config.fan_min_percent;
    document.getElementById('inputFanMax').value = config.fan_max_percent;
    document.getElementById('inputManualFan').value = config.manual_fan_percent;

    const sliderFan = document.getElementById('sliderFanControl');
    const readoutFan = document.getElementById('readoutFanControl');
    if (controlModeDraft === 'manual') {
      sliderFan.value = config.manual_fan_percent;
      readoutFan.textContent = `${config.manual_fan_percent}%`;
    } else {
      sliderFan.value = config.fan_max_percent;
      readoutFan.textContent = `${config.fan_max_percent}%`;
    }

    const presetSelect = document.getElementById('presetSeedSelect');
    if (presetSelect && batch && batch.seed_profile_id) {
      presetSelect.value = String(batch.seed_profile_id);
    }
  }

  function updateControlModeUI() {
    const autoBtn = document.getElementById('modeAutoBtn');
    const manualBtn = document.getElementById('modeManualBtn');
    const sliderLabel = document.getElementById('sliderFanLabel');
    const sliderFan = document.getElementById('sliderFanControl');
    const readoutFan = document.getElementById('readoutFanControl');
    const returnAutoBtn = document.getElementById('returnAutoBtn');

    const isManual = controlModeDraft === 'manual';
    autoBtn.className = `btn btn-sm ${!isManual ? 'btn-primary' : 'btn-secondary'}`;
    manualBtn.className = `btn btn-sm ${isManual ? 'btn-primary' : 'btn-secondary'}`;

    if (isManual) {
      sliderLabel.textContent = 'Manual Fan Speed (%)';
      const val = document.getElementById('inputManualFan').value || 45;
      sliderFan.value = val;
      readoutFan.textContent = `${val}%`;
      returnAutoBtn.classList.remove('hidden');
    } else {
      sliderLabel.textContent = 'Max Circulation Fan (%)';
      const val = document.getElementById('inputFanMax').value || 85;
      sliderFan.value = val;
      readoutFan.textContent = `${val}%`;
      returnAutoBtn.classList.add('hidden');
    }
  }

  function renderReconciliationBar(config, reconciliation) {
    const syncEl = document.getElementById('configSyncText');
    const expiryEl = document.getElementById('manualExpiryNote');

    if (reconciliation && reconciliation.synced) {
      syncEl.textContent = `Requested v${config.config_version} · Acknowledged by ESP32`;
      syncEl.style.color = 'var(--status-green-fg)';
    } else {
      const ackVer =
        reconciliation && reconciliation.acknowledged
          ? `v${reconciliation.acknowledged.config_version || '?'}`
          : 'none';
      syncEl.textContent = `Requested v${config.config_version} · Pending ESP32 Sync (Device at ${ackVer})`;
      syncEl.style.color = 'var(--status-amber-fg)';
    }

    if (config.control_mode === 'manual' && config.manual_expires_at) {
      const minsLeft = Math.max(
        0,
        Math.ceil((Date.parse(config.manual_expires_at) - Date.now()) / 60_000)
      );
      expiryEl.textContent = `Manual fan override (${config.manual_fan_percent}%) auto-returns to Automatic in ${minsLeft} min`;
    } else {
      expiryEl.textContent = `Auto cooling hysteresis (${config.cooling_off_temp.toFixed(1)}–${config.cooling_on_temp.toFixed(1)}°C) + ramped PWM fan (${config.fan_min_percent}–${config.fan_max_percent}%)`;
    }
  }

  function renderActiveAlerts(alerts) {
    const panel = document.getElementById('activeAlertsPanel');
    const list = document.getElementById('activeAlertsList');
    if (!alerts || alerts.length === 0) {
      panel.classList.add('hidden');
      list.innerHTML = '';
      return;
    }

    panel.classList.remove('hidden');
    list.innerHTML = alerts
      .map((a) => {
        const dt = formatDateParts(a.created_at);
        const isCritical =
          a.kind === 'high_temp' ||
          a.kind === 'low_temp' ||
          a.kind === 'sensor_failure';
        const resolvedNote = a.resolved_at
          ? ` · Recovered at ${formatDateParts(a.resolved_at).time}`
          : ' · Active condition';
        return `
          <div class="alert-row ${isCritical ? 'critical' : ''}">
            <div>
              <div class="alert-row-title">${escapeHtml(a.message)}</div>
              <div class="alert-row-meta tabular">${escapeHtml(a.kind.replace(/_/g, ' '))} · ${dt.full}${resolvedNote}</div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm ack-alert-btn" data-alert-id="${a.id}">
              Acknowledge
            </button>
          </div>
        `;
      })
      .join('');

    list.querySelectorAll('.ack-alert-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.alertId;
        btn.disabled = true;
        try {
          await apiFetch(`/api/alerts/${id}/acknowledge`, { method: 'POST' });
          await pollDashboard();
        } catch (err) {
          showNotice(err.message, 'error');
          btn.disabled = false;
        }
      });
    });
  }

  function renderRecentLogs(logs) {
    const tbody = document.getElementById('recentLogsBody');
    if (!logs || logs.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="9" style="text-align: center; color: var(--text-muted);">
            No sensor readings recorded yet. Start the simulator or connect your ESP32.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = logs
      .map((row) => {
        const dt = formatDateParts(row.created_at);
        const tempStr =
          row.sensor_ok && row.temp !== null ? row.temp.toFixed(1) : 'FAULT';
        const rhStr =
          row.sensor_ok && row.humidity !== null ? row.humidity.toFixed(1) : 'FAULT';
        const rpmStr =
          row.fan_rpm !== null && row.fan_rpm !== undefined
            ? `${row.fan_rpm}`
            : 'Unavailable';
        const coolStr = row.cooling_on ? 'ON' : 'Standby';
        const srcStr = row.is_simulated ? 'Simulated' : 'ESP32';

        return `
          <tr>
            <td>${dt.date}</td>
            <td>${dt.time}</td>
            <td>${escapeHtml(row.seed_name)}</td>
            <td class="num">${tempStr}</td>
            <td class="num">${rhStr}</td>
            <td class="num">${row.fan_speed_percent.toFixed(0)}%</td>
            <td class="num">${rpmStr}</td>
            <td>${coolStr}</td>
            <td>${srcStr}</td>
          </tr>
        `;
      })
      .join('');
  }

  function renderWifiTabState(config, reconciliation, simulator) {
    const reqPre = document.getElementById('requestedConfigPre');
    const ackPre = document.getElementById('ackConfigPre');
    if (reqPre && config) {
      reqPre.textContent = JSON.stringify(
        {
          config_version: config.config_version,
          target_temp: config.target_temp,
          temp_min: config.temp_min,
          temp_max: config.temp_max,
          cooling_on_temp: config.cooling_on_temp,
          cooling_off_temp: config.cooling_off_temp,
          fan_min_percent: config.fan_min_percent,
          fan_max_percent: config.fan_max_percent,
          control_mode: config.control_mode,
          manual_fan_percent: config.manual_fan_percent
        },
        null,
        2
      );
    }
    if (ackPre) {
      ackPre.textContent =
        reconciliation && reconciliation.acknowledged
          ? JSON.stringify(reconciliation.acknowledged, null, 2)
          : 'No configuration acknowledgement received from device yet.';
    }

    const simPanel = document.getElementById('simulatorPanel');
    const simLabel = document.getElementById('simStateLabel');
    const simSelect = document.getElementById('simScenarioSelect');
    if (simulator && simPanel) {
      simPanel.classList.remove('hidden');
      simLabel.textContent = simulator.running
        ? `Running on ${simulator.device_id} · Tick #${simulator.tick_count}`
        : `Paused on ${simulator.device_id}`;
      if (simSelect && document.activeElement !== simSelect) {
        simSelect.value = simulator.mode;
      }
    }
  }

  async function loadSeedProfiles() {
    const res = await apiFetch('/api/seed-profiles');
    seedProfiles = res.profiles || [];

    const presetSelect = document.getElementById('presetSeedSelect');
    const batchSelect = document.getElementById('batchSeedProfile');

    if (presetSelect) {
      presetSelect.innerHTML = seedProfiles
        .map(
          (p) =>
            `<option value="${p.id}">${escapeHtml(p.name)} (${p.temp_min}–${p.temp_max}°C · ${p.rh_min}–${p.rh_max}% RH)</option>`
        )
        .join('');
    }

    if (batchSelect) {
      batchSelect.innerHTML = seedProfiles
        .map(
          (p) =>
            `<option value="${p.id}">${escapeHtml(p.name)} — ${p.shelf_days} days (${p.temp_min}–${p.temp_max}°C)</option>`
        )
        .join('');
      batchSelect.addEventListener('change', () => {
        const chosen = seedProfiles.find((p) => String(p.id) === batchSelect.value);
        if (chosen) {
          document.getElementById('batchPlannedDays').value = chosen.shelf_days;
        }
      });
    }

    // Populate Seed Guide cards
    const guideGrid = document.getElementById('seedGuideGrid');
    if (guideGrid) {
      guideGrid.innerHTML = seedProfiles
        .map(
          (p) => `
          <article class="seed-item">
            <div>
              <h3 style="margin: 0 0 0.35rem; font-size: 1rem;">${escapeHtml(p.name)}</h3>
              <div class="meta-line tabular" style="font-weight: 600; color: var(--accent-primary); margin-bottom: 0.5rem;">
                ${p.temp_min}–${p.temp_max}°C · ${p.rh_min}–${p.rh_max}% RH · ${p.shelf_days} Days
              </div>
              <p class="meta-line" style="margin: 0; line-height: 1.45;">
                ${escapeHtml(p.notes)}
              </p>
            </div>
            <button type="button" class="btn btn-secondary btn-sm use-profile-btn" data-profile-id="${p.id}">
              Select for New Batch
            </button>
          </article>
        `
        )
        .join('');

      guideGrid.querySelectorAll('.use-profile-btn').forEach((btn) => {
        btn.addEventListener('click', () => {
          const pid = btn.dataset.profileId;
          const chosen = seedProfiles.find((p) => String(p.id) === pid);
          if (chosen && batchSelect) {
            batchSelect.value = pid;
            document.getElementById('batchPlannedDays').value = chosen.shelf_days;
          }
          activateSection('batches');
        });
      });
    }
  }

  async function loadNetworkInfo() {
    const info = await apiFetch('/api/network-info');
    const lanEl = document.getElementById('detectedLanUrl');
    if (lanEl) {
      if (info.lan_addresses && info.lan_addresses.length > 0) {
        lanEl.textContent = info.lan_addresses
          .map((a) => `http://${a.ip}:${info.port}   (${a.interface})`)
          .join('\n');
      } else {
        lanEl.textContent = `${info.example_url}   (Run ipconfig / hostname -I on your laptop to verify LAN IP)`;
      }
    }
  }

  async function loadBatchesList() {
    const deviceId = getSelectedDeviceId();
    document.getElementById('activeBatchChamberTag').textContent = `Chamber: ${deviceId}`;

    const res = await apiFetch('/api/batches');
    const batches = res.batches || [];
    const activeForChamber = batches.find(
      (b) => b.device_id === deviceId && b.status === 'active'
    );

    const activeBox = document.getElementById('activeBatchContainer');
    if (activeForChamber) {
      const pct = Math.min(
        100,
        Math.round((activeForChamber.days_stored / activeForChamber.planned_days) * 100)
      );
      activeBox.innerHTML = `
        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 1rem;">
          <div>
            <div style="font-size: 1.05rem; font-weight: 700;">
              ${escapeHtml(activeForChamber.label)} · ${escapeHtml(activeForChamber.seed_name)}
            </div>
            <div class="meta-line tabular" style="margin-top: 0.25rem;">
              Quantity: ${activeForChamber.quantity_kg} kg · Started: ${formatDateParts(activeForChamber.started_at).full} UTC · Envelope: ${activeForChamber.temp_min}–${activeForChamber.temp_max}°C, ${activeForChamber.rh_min}–${activeForChamber.rh_max}% RH
            </div>
            <div class="meta-line tabular" style="margin-top: 0.25rem; font-weight: 600; color: var(--accent-primary);">
              ${activeForChamber.days_stored} Days Stored · ${activeForChamber.days_remaining} Days Remaining (of ${activeForChamber.planned_days} planned days)
            </div>
          </div>
          <button type="button" id="closeActiveBatchBtn" class="btn btn-danger btn-sm">
            Close Active Batch
          </button>
        </div>
        <div class="progress-track">
          <div class="progress-fill" style="width: ${pct}%;"></div>
        </div>
      `;

      document
        .getElementById('closeActiveBatchBtn')
        .addEventListener('click', async (e) => {
          e.target.disabled = true;
          try {
            await apiFetch(`/api/batches/${activeForChamber.id}/close`, {
              method: 'POST'
            });
            showNotice(`Closed batch "${activeForChamber.label}".`, 'success');
            await loadBatchesList();
            await pollDashboard();
          } catch (err) {
            showNotice(err.message, 'error');
            e.target.disabled = false;
          }
        });
    } else {
      activeBox.innerHTML = `
        <p class="meta-line" style="margin: 0;">
          No active batch in <strong>${escapeHtml(deviceId)}</strong>. Use the form below to start tracking a new seed batch.
        </p>
      `;
    }

    const tbody = document.getElementById('batchesTableBody');
    if (batches.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted);">No batches created yet.</td></tr>`;
    } else {
      tbody.innerHTML = batches
        .map(
          (b) => `
          <tr>
            <td>${escapeHtml(b.label)}</td>
            <td>${escapeHtml(b.seed_name)}</td>
            <td>${escapeHtml(b.device_id)}</td>
            <td class="num">${b.quantity_kg}</td>
            <td>${formatDateParts(b.started_at).date}</td>
            <td class="num">${b.days_stored}</td>
            <td class="num">${b.status === 'active' ? b.days_remaining : '—'}</td>
            <td>${b.status === 'active' ? 'Active' : 'Closed'}</td>
          </tr>
        `
        )
        .join('');
    }
  }

  function bindControlFormEvents() {
    const form = document.getElementById('controlForm');
    const sliderTemp = document.getElementById('sliderTargetTemp');
    const readoutTemp = document.getElementById('readoutTargetTemp');
    const sliderFan = document.getElementById('sliderFanControl');
    const readoutFan = document.getElementById('readoutFanControl');
    const presetSelect = document.getElementById('presetSeedSelect');

    form.addEventListener('input', () => {
      formDirty = true;
    });

    sliderTemp.addEventListener('input', () => {
      const target = Number(sliderTemp.value);
      readoutTemp.textContent = `${target.toFixed(1)}°C`;
      // Automatically keep Cooling OFF / ON symmetrically +/- 0.7 °C around slider target
      document.getElementById('inputCoolOff').value = (target - 0.7).toFixed(1);
      document.getElementById('inputCoolOn').value = (target + 0.7).toFixed(1);
    });

    sliderFan.addEventListener('input', () => {
      const pct = Number(sliderFan.value);
      readoutFan.textContent = `${pct}%`;
      if (controlModeDraft === 'manual') {
        document.getElementById('inputManualFan').value = pct;
      } else {
        document.getElementById('inputFanMax').value = pct;
      }
    });

    presetSelect.addEventListener('change', () => {
      formDirty = true;
      const chosen = seedProfiles.find((p) => String(p.id) === presetSelect.value);
      if (!chosen) return;
      const mid = Number(((chosen.temp_min + chosen.temp_max) / 2).toFixed(1));
      sliderTemp.value = mid;
      readoutTemp.textContent = `${mid.toFixed(1)}°C`;
      document.getElementById('inputTempMin').value = chosen.temp_min.toFixed(1);
      document.getElementById('inputTempMax').value = chosen.temp_max.toFixed(1);
      const half = Math.max(0.4, Math.min(0.8, Number(((chosen.temp_max - chosen.temp_min) * 0.2).toFixed(1))));
      document.getElementById('inputCoolOff').value = (mid - half).toFixed(1);
      document.getElementById('inputCoolOn').value = (mid + half).toFixed(1);
    });

    document.getElementById('modeAutoBtn').addEventListener('click', () => {
      formDirty = true;
      controlModeDraft = 'auto';
      updateControlModeUI();
    });

    document.getElementById('modeManualBtn').addEventListener('click', () => {
      formDirty = true;
      controlModeDraft = 'manual';
      updateControlModeUI();
    });

    document.getElementById('returnAutoBtn').addEventListener('click', async () => {
      const deviceId = getSelectedDeviceId();
      try {
        await apiFetch(`/api/devices/${encodeURIComponent(deviceId)}/return-auto`, {
          method: 'POST'
        });
        formDirty = false;
        showNotice('Returned chamber fan control to Automatic mode.', 'success');
        await pollDashboard();
      } catch (err) {
        showNotice(err.message, 'error');
      }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const saveBtn = document.getElementById('saveConfigBtn');
      saveBtn.disabled = true;

      const deviceId = getSelectedDeviceId();
      const payload = {
        target_temp: Number(sliderTemp.value),
        temp_min: Number(document.getElementById('inputTempMin').value),
        temp_max: Number(document.getElementById('inputTempMax').value),
        cooling_off_temp: Number(document.getElementById('inputCoolOff').value),
        cooling_on_temp: Number(document.getElementById('inputCoolOn').value),
        fan_min_percent: Number(document.getElementById('inputFanMin').value),
        fan_max_percent: Number(document.getElementById('inputFanMax').value),
        manual_fan_percent: Number(document.getElementById('inputManualFan').value),
        manual_timeout_minutes: Number(document.getElementById('inputManualTimeout').value),
        control_mode: controlModeDraft
      };

      try {
        await apiFetch(`/api/devices/${encodeURIComponent(deviceId)}/config`, {
          method: 'PUT',
          body: payload
        });
        formDirty = false;
        showNotice(
          'Control configuration saved. ESP32 will apply it on next config poll.',
          'success'
        );
        await pollDashboard();
      } catch (err) {
        showNotice(err.message, 'error');
      } finally {
        saveBtn.disabled = false;
      }
    });
  }

  function bindSimulatorAndBatchForms() {
    const quickSimBtn = document.getElementById('quickSimToggleBtn');
    if (quickSimBtn) {
      quickSimBtn.addEventListener('click', () => activateSection('wifi'));
    }

    const sendSimAction = async (action) => {
      const mode = document.getElementById('simScenarioSelect').value;
      try {
        await apiFetch('/api/simulator/control', {
          method: 'POST',
          body: { action, mode }
        });
        await pollDashboard();
      } catch (err) {
        showNotice(err.message, 'error');
      }
    };

    document.getElementById('simStartBtn').addEventListener('click', () => sendSimAction('start'));
    document.getElementById('simStopBtn').addEventListener('click', () => sendSimAction('stop'));
    document.getElementById('simStepBtn').addEventListener('click', () => sendSimAction('step'));
    document
      .getElementById('simScenarioSelect')
      .addEventListener('change', () => sendSimAction('set_mode'));

    // Create Batch Form
    document.getElementById('createBatchForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = document.getElementById('createBatchBtn');
      btn.disabled = true;

      try {
        const payload = {
          device_id: getSelectedDeviceId(),
          seed_profile_id: Number(document.getElementById('batchSeedProfile').value),
          label: document.getElementById('batchLabel').value.trim(),
          quantity_kg: Number(document.getElementById('batchQty').value),
          planned_days: Number(document.getElementById('batchPlannedDays').value),
          apply_profile_temps: document.getElementById('batchApplyTemps').checked
        };
        await apiFetch('/api/batches', { method: 'POST', body: payload });
        document.getElementById('batchLabel').value = '';
        formDirty = false;
        showNotice('New seed batch started and linked to chamber readings.', 'success');
        await loadBatchesList();
        await pollDashboard();
      } catch (err) {
        showNotice(err.message, 'error');
      } finally {
        btn.disabled = false;
      }
    });

    // Register Additional Device Form
    document.getElementById('registerDeviceForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        const res = await apiFetch('/api/devices', {
          method: 'POST',
          body: {
            device_id: document.getElementById('newDeviceId').value.trim(),
            device_name: document.getElementById('newDeviceName').value.trim(),
            device_key: document.getElementById('newDeviceKey').value
          }
        });
        document.getElementById('newDeviceId').value = '';
        document.getElementById('newDeviceName').value = '';
        document.getElementById('newDeviceKey').value = '';
        await refreshSessionDevices();
        bindSidebarShell();
        showNotice(`Registered chamber "${res.device.id}".`, 'success');
      } catch (err) {
        showNotice(err.message, 'error');
      }
    });
  }

  async function pollDashboard() {
    if (isPolling) return;
    isPolling = true;
    try {
      const deviceId = getSelectedDeviceId();
      const data = await apiFetch(
        `/api/dashboard?device_id=${encodeURIComponent(deviceId)}`,
        { timeoutMs: 6000 }
      );
      renderDashboard(data);
    } catch (err) {
      const strip = document.getElementById('chamberStatusStrip');
      if (strip) {
        strip.className = 'status-strip grey';
        document.getElementById('statusTitle').textContent = '○ Local Server Unreachable';
        document.getElementById('statusDetail').textContent =
          err.message || 'Check Wi-Fi connection to laptop server.';
      }
    } finally {
      isPolling = false;
    }
  }

  async function boot() {
    startLiveClock();
    const sessionInfo = await checkSession();
    if (!sessionInfo) return;

    bindSidebarShell();
    initSectionNavigation();
    initLiveChart();
    bindControlFormEvents();
    bindSimulatorAndBatchForms();

    await loadSeedProfiles();
    await pollDashboard();

    window.addEventListener('agriseed:device-changed', () => {
      formDirty = false;
      pollDashboard();
      loadBatchesList().catch(() => {});
    });

    // Poll local HTTP endpoint every 5 seconds
    pollTimer = setInterval(pollDashboard, 5000);
    window.addEventListener('beforeunload', () => {
      if (pollTimer) clearInterval(pollTimer);
    });
  }

  boot().catch((err) => {
    console.error('Dashboard init error:', err);
  });
})();
