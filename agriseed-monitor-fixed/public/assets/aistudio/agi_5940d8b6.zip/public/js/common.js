/**
 * public/js/common.js
 * ----------------------------------------------------------------------------
 * Shared browser helpers for local session/CSRF bootstrap, HTTP requests,
 * date/time formatting, and mobile navigation drawer control.
 * Plain vanilla JavaScript — zero external client frameworks or CDNs.
 */

window.AgriCommon = (function () {
  let csrfToken = null;
  let ownedDevices = [];

  async function apiFetch(url, options = {}) {
    const timeoutMs = options.timeoutMs || 8000;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    const headers = Object.assign(
      { Accept: 'application/json' },
      options.headers || {}
    );

    const method = (options.method || 'GET').toUpperCase();
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }

    if (method !== 'GET' && method !== 'HEAD' && csrfToken) {
      headers['X-CSRF-Token'] = csrfToken;
    }

    try {
      const response = await fetch(url, {
        ...options,
        method,
        headers,
        credentials: 'same-origin',
        signal: controller.signal
      });

      const contentType = response.headers.get('content-type') || '';
      const data = contentType.includes('application/json')
        ? await response.json()
        : await response.text();

      if (!response.ok) {
        const message =
          data && typeof data === 'object' && data.error
            ? data.error
            : `Request failed (HTTP ${response.status})`;
        const err = new Error(message);
        err.status = response.status;
        err.payload = data;
        throw err;
      }

      return data;
    } finally {
      clearTimeout(timer);
    }
  }

  async function checkSession() {
    const info = await apiFetch('/api/auth/me');
    csrfToken = info.csrfToken || null;
    ownedDevices = info.devices || [];
    return info;
  }

  function getSelectedDeviceId() {
    const saved = localStorage.getItem('agriseed_selected_device');
    if (saved && ownedDevices.some((d) => d.id === saved)) {
      return saved;
    }
    if (ownedDevices.length > 0) {
      localStorage.setItem('agriseed_selected_device', ownedDevices[0].id);
      return ownedDevices[0].id;
    }
    return 'chamber-01';
  }

  function setSelectedDeviceId(id) {
    localStorage.setItem('agriseed_selected_device', id);
  }

  function bindSidebarShell() {
    const toggleBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('appSidebar');
    if (toggleBtn && sidebar) {
      toggleBtn.addEventListener('click', () => {
        const isOpen = sidebar.classList.toggle('open');
        toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
    }

    const chamberSelect = document.getElementById('sidebarChamberSelect');
    if (chamberSelect && ownedDevices.length > 0) {
      chamberSelect.innerHTML = '';
      const activeId = getSelectedDeviceId();
      ownedDevices.forEach((dev) => {
        const opt = document.createElement('option');
        opt.value = dev.id;
        opt.textContent = `${dev.device_name} (${dev.id})`;
        if (dev.id === activeId) opt.selected = true;
        chamberSelect.appendChild(opt);
      });
      chamberSelect.onchange = (e) => {
        setSelectedDeviceId(e.target.value);
        window.dispatchEvent(new CustomEvent('agriseed:device-changed', { detail: e.target.value }));
      };
    }
  }

  function formatDateParts(isoString) {
    if (!isoString) return { date: '—', time: '—', full: '—' };
    const d = new Date(isoString);
    if (Number.isNaN(d.getTime())) return { date: '—', time: '—', full: '—' };
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const min = String(d.getMinutes()).padStart(2, '0');
    const sec = String(d.getSeconds()).padStart(2, '0');
    return {
      date: `${yyyy}-${mm}-${dd}`,
      time: `${hh}:${min}:${sec}`,
      full: `${yyyy}-${mm}-${dd} ${hh}:${min}:${sec}`
    };
  }

  function formatRelativeAge(seconds) {
    if (seconds === null || seconds === undefined) return 'Never connected';
    if (seconds < 5) return 'Just now';
    if (seconds < 60) return `${seconds}s ago`;
    const mins = Math.floor(seconds / 60);
    if (mins < 60) return `${mins}m ${seconds % 60}s ago`;
    const hrs = Math.floor(mins / 60);
    return `${hrs}h ${mins % 60}m ago`;
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function setCsrfToken(token) {
    csrfToken = token;
  }

  return {
    apiFetch,
    checkSession,
    getSelectedDeviceId,
    setSelectedDeviceId,
    bindSidebarShell,
    formatDateParts,
    formatRelativeAge,
    escapeHtml,
    setCsrfToken,
    getOwnedDevices: () => ownedDevices,
    refreshSessionDevices: async () => {
      const info = await apiFetch('/api/auth/me');
      ownedDevices = info.devices || [];
      return ownedDevices;
    }
  };
})();
