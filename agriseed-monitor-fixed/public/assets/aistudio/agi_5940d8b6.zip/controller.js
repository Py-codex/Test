/**
 * controller.js
 * ----------------------------------------------------------------------------
 * Server-side control-configuration validation, alert generation with cooldown
 * deduplication, alert auto-recovery, and live chamber health status scoring.
 *
 * IMPORTANT ENGINEERING NOTE:
 * The laptop server validates and stores desired operating envelopes, while the
 * ESP32 executes the actual real-time cooling relay hysteresis and PWM fan loop
 * locally so seed protection continues even if Wi-Fi drops.
 */

import { nowUtc } from './db.js';
import { sendAlertEmail } from './mailer.js';

// Hardware safety guardrails for a refrigerated seed storage chamber
export const HARDWARE_BOUNDS = {
  ABS_TEMP_MIN: 2.0, // Prevent sub-zero freezing damage unless specialised cryopreservation hardware is used
  ABS_TEMP_MAX: 35.0,
  MIN_OPERATING_SPAN: 1.5, // temp_max - temp_min must be at least 1.5 °C
  MIN_HYSTERESIS: 0.6, // cooling_on_temp - cooling_off_temp >= 0.6 °C prevents rapid compressor short-cycling
  MIN_COMPRESSOR_OFF_SEC: 180, // 3-minute minimum compressor rest before restart
  MIN_COMPRESSOR_ON_SEC: 60, // 1-minute minimum compressor run once engaged
  FAN_ABS_MIN: 0,
  FAN_ABS_MAX: 100
};

/**
 * Validates user-submitted chamber configuration before saving to SQLite or
 * serving to the ESP32. Rejects unsafe thresholds that could cause rapid relay
 * chattering or freezing.
 */
export function validateControlConfig(input, currentConfig = {}) {
  const errors = [];

  const tempMin = Number(input.temp_min ?? currentConfig.temp_min);
  const tempMax = Number(input.temp_max ?? currentConfig.temp_max);
  const targetTemp = Number(input.target_temp ?? currentConfig.target_temp);

  if (!Number.isFinite(tempMin) || !Number.isFinite(tempMax) || !Number.isFinite(targetTemp)) {
    errors.push('Temperature target and operating limits must be valid numbers.');
  } else {
    if (tempMin < HARDWARE_BOUNDS.ABS_TEMP_MIN || tempMax > HARDWARE_BOUNDS.ABS_TEMP_MAX) {
      errors.push(
        `Operating temperature limits must stay within ${HARDWARE_BOUNDS.ABS_TEMP_MIN} °C and ${HARDWARE_BOUNDS.ABS_TEMP_MAX} °C.`
      );
    }
    if (tempMax - tempMin < HARDWARE_BOUNDS.MIN_OPERATING_SPAN) {
      errors.push(
        `Upper limit must exceed lower limit by at least ${HARDWARE_BOUNDS.MIN_OPERATING_SPAN} °C.`
      );
    }
    if (targetTemp < tempMin + 0.3 || targetTemp > tempMax - 0.3) {
      errors.push(
        'Target temperature must sit at least 0.3 °C inside the configured [temp_min, temp_max] band.'
      );
    }
  }

  // Cooling ON / OFF hysteresis thresholds:
  // Either explicitly supplied or derived symmetrically around target_temp.
  const defaultHalfBand = 0.7;
  const coolingOnTemp =
    input.cooling_on_temp !== undefined
      ? Number(input.cooling_on_temp)
      : Number((targetTemp + defaultHalfBand).toFixed(1));
  const coolingOffTemp =
    input.cooling_off_temp !== undefined
      ? Number(input.cooling_off_temp)
      : Number((targetTemp - defaultHalfBand).toFixed(1));

  if (!Number.isFinite(coolingOnTemp) || !Number.isFinite(coolingOffTemp)) {
    errors.push('Cooling ON and OFF thresholds must be valid numbers.');
  } else {
    if (coolingOnTemp - coolingOffTemp < HARDWARE_BOUNDS.MIN_HYSTERESIS) {
      errors.push(
        `Cooling hysteresis (ON minus OFF threshold) must be at least ${HARDWARE_BOUNDS.MIN_HYSTERESIS} °C to protect the compressor from rapid switching.`
      );
    }
    if (coolingOffTemp < HARDWARE_BOUNDS.ABS_TEMP_MIN || coolingOnTemp > HARDWARE_BOUNDS.ABS_TEMP_MAX) {
      errors.push('Cooling ON/OFF thresholds exceed safe refrigeration bounds.');
    }
    if (coolingOffTemp > targetTemp || coolingOnTemp < targetTemp) {
      errors.push('Target temperature must lie between the Cooling OFF and Cooling ON thresholds.');
    }
  }

  const fanMin = Math.round(Number(input.fan_min_percent ?? currentConfig.fan_min_percent ?? 25));
  const fanMax = Math.round(Number(input.fan_max_percent ?? currentConfig.fan_max_percent ?? 85));

  if (!Number.isFinite(fanMin) || !Number.isFinite(fanMax)) {
    errors.push('Fan minimum and maximum percentages must be valid numbers.');
  } else {
    if (fanMin < HARDWARE_BOUNDS.FAN_ABS_MIN || fanMax > HARDWARE_BOUNDS.FAN_ABS_MAX) {
      errors.push('Fan speed limits must stay between 0% and 100%.');
    }
    if (fanMin > fanMax) {
      errors.push('Minimum fan speed cannot exceed maximum fan speed.');
    }
  }

  const controlMode = String(input.control_mode ?? currentConfig.control_mode ?? 'auto').toLowerCase();
  if (controlMode !== 'auto' && controlMode !== 'manual') {
    errors.push('Control mode must be either "auto" or "manual".');
  }

  let manualFanPercent = Math.round(
    Number(input.manual_fan_percent ?? currentConfig.manual_fan_percent ?? Math.max(fanMin, 40))
  );
  if (!Number.isFinite(manualFanPercent) || manualFanPercent < 0 || manualFanPercent > 100) {
    errors.push('Manual fan speed must be between 0% and 100%.');
  } else if (controlMode === 'manual' && (manualFanPercent < fanMin || manualFanPercent > fanMax)) {
    errors.push(
      `Manual fan speed (${manualFanPercent}%) must stay within the configured fan hardware limits (${fanMin}%–${fanMax}%).`
    );
  } else {
    manualFanPercent = Math.min(fanMax, Math.max(fanMin, manualFanPercent));
  }

  const defaultTimeoutMin = Number(process.env.MANUAL_OVERRIDE_MINUTES) || 30;
  const timeoutMinutes = Math.min(
    240,
    Math.max(1, Math.round(Number(input.manual_timeout_minutes ?? defaultTimeoutMin)))
  );

  const manualExpiresAt =
    controlMode === 'manual'
      ? new Date(Date.now() + timeoutMinutes * 60_000).toISOString()
      : null;

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  return {
    valid: true,
    value: {
      target_temp: Number(targetTemp.toFixed(1)),
      temp_min: Number(tempMin.toFixed(1)),
      temp_max: Number(tempMax.toFixed(1)),
      cooling_on_temp: Number(coolingOnTemp.toFixed(1)),
      cooling_off_temp: Number(coolingOffTemp.toFixed(1)),
      fan_min_percent: fanMin,
      fan_max_percent: fanMax,
      manual_fan_percent: manualFanPercent,
      control_mode: controlMode,
      manual_expires_at: manualExpiresAt
    }
  };
}

/**
 * Formats the structured configuration payload served to the ESP32 on
 * GET /api/device/config.
 */
export function buildDeviceConfigPayload(configRow, activeBatchProfile = null) {
  return {
    device_id: configRow.device_id,
    config_version: configRow.config_version,
    target_temp: configRow.target_temp,
    temp_min: configRow.temp_min,
    temp_max: configRow.temp_max,
    cooling_on_temp: configRow.cooling_on_temp,
    cooling_off_temp: configRow.cooling_off_temp,
    min_compressor_off_sec: HARDWARE_BOUNDS.MIN_COMPRESSOR_OFF_SEC,
    min_compressor_on_sec: HARDWARE_BOUNDS.MIN_COMPRESSOR_ON_SEC,
    fan_min_percent: configRow.fan_min_percent,
    fan_max_percent: configRow.fan_max_percent,
    control_mode: configRow.control_mode,
    manual_fan_percent: configRow.manual_fan_percent,
    manual_expires_at: configRow.manual_expires_at,
    rh_min: activeBatchProfile ? activeBatchProfile.rh_min : 35.0,
    rh_max: activeBatchProfile ? activeBatchProfile.rh_max : 55.0,
    policy_note:
      'Prototype configuration — local hysteresis cooling + ramped PWM circulation fan. Requires field calibration.',
    updated_at: configRow.updated_at
  };
}

/**
 * Raises an alert for the chamber owner if an identical alert kind has not been
 * created within the cooldown window (`ALERT_COOLDOWN_MINUTES`).
 */
export async function raiseAlertWithCooldown(db, { userId, deviceId, batchId = null, kind, message }) {
  if (!userId) {
    return null;
  }

  const cooldownMinutes = Math.max(1, Number(process.env.ALERT_COOLDOWN_MINUTES ?? 15));
  const cutoffIso = new Date(Date.now() - cooldownMinutes * 60_000).toISOString();

  // Suppress duplicate alerts if an unresolved alert of the same kind already exists
  // OR if one was created inside the cooldown window.
  const recent = db
    .prepare(
      `SELECT id, resolved_at, created_at
       FROM alerts
       WHERE user_id = ? AND device_id = ? AND kind = ?
         AND (resolved_at IS NULL OR created_at >= ?)
       ORDER BY created_at DESC
       LIMIT 1`
    )
    .get(userId, deviceId, kind, cutoffIso);

  if (recent) {
    return null;
  }

  const now = nowUtc();
  const info = db
    .prepare(
      `INSERT INTO alerts (user_id, device_id, batch_id, kind, message, created_at, acknowledged)
       VALUES (?, ?, ?, ?, ?, ?, 0)`
    )
    .run(userId, deviceId, batchId, kind, message, now);

  const alertId = Number(info.lastInsertRowid);

  // Attempt optional SMTP notification if user email exists and SMTP is configured.
  const user = db.prepare('SELECT email FROM users WHERE id = ?').get(userId);
  if (user && user.email) {
    const emailResult = await sendAlertEmail({
      to: user.email,
      subject: `[AgriSeed Alert] ${kind.replace(/_/g, ' ').toUpperCase()} on ${deviceId}`,
      text: `${message}\n\nChamber: ${deviceId}\nRecorded UTC: ${now}`
    });

    // If SMTP was configured by the user yet failed to deliver, record a non-blocking warning once per cooldown.
    if (!emailResult.sent && !emailResult.skipped && kind !== 'smtp_failure') {
      const existingMailWarn = db
        .prepare(
          `SELECT id FROM alerts
           WHERE user_id = ? AND device_id = ? AND kind = 'smtp_failure' AND created_at >= ?
           LIMIT 1`
        )
        .get(userId, deviceId, cutoffIso);

      if (!existingMailWarn) {
        db.prepare(
          `INSERT INTO alerts (user_id, device_id, batch_id, kind, message, created_at, acknowledged)
           VALUES (?, ?, ?, 'smtp_failure', ?, ?, 0)`
        ).run(
          userId,
          deviceId,
          batchId,
          `Optional email notification failed (${emailResult.reason}). Local monitoring continues normally.`,
          now
        );
      }
    }
  }

  return alertId;
}

export function resolveAlertsByKind(db, { deviceId, kinds }) {
  if (!kinds || kinds.length === 0) return;
  const now = nowUtc();
  const placeholders = kinds.map(() => '?').join(', ');
  db.prepare(
    `UPDATE alerts
     SET resolved_at = ?
     WHERE device_id = ? AND resolved_at IS NULL AND kind IN (${placeholders})`
  ).run(now, deviceId, ...kinds);
}

/**
 * Evaluates a newly received reading against configured chamber limits and
 * active seed batch RH limits, creating or resolving alerts automatically.
 */
export async function evaluateReadingAlerts(db, { device, config, activeBatch, reading }) {
  const userId = device.user_id;
  if (!userId) return;

  const batchId = activeBatch ? activeBatch.id : null;
  const rhMin = activeBatch ? activeBatch.rh_min : 35.0;
  const rhMax = activeBatch ? activeBatch.rh_max : 55.0;

  // Resolve any offline alert since we just received a live packet
  resolveAlertsByKind(db, { deviceId: device.id, kinds: ['device_offline'] });

  if (!reading.sensor_ok || reading.temp === null || reading.humidity === null) {
    await raiseAlertWithCooldown(db, {
      userId,
      deviceId: device.id,
      batchId,
      kind: 'sensor_failure',
      message: `DHT22 sensor fault reported by ${device.id}. ESP32 entered safe fallback mode; verify sensor wiring on GPIO 4.`
    });
    return;
  }

  // Sensor reading is valid -> resolve any prior sensor_failure alert
  resolveAlertsByKind(db, { deviceId: device.id, kinds: ['sensor_failure'] });

  // Temperature threshold checks
  if (reading.temp > config.temp_max) {
    await raiseAlertWithCooldown(db, {
      userId,
      deviceId: device.id,
      batchId,
      kind: 'high_temp',
      message: `High chamber temperature: ${reading.temp.toFixed(1)} °C exceeds upper limit (${config.temp_max.toFixed(1)} °C).`
    });
    resolveAlertsByKind(db, { deviceId: device.id, kinds: ['low_temp'] });
  } else if (reading.temp < config.temp_min) {
    await raiseAlertWithCooldown(db, {
      userId,
      deviceId: device.id,
      batchId,
      kind: 'low_temp',
      message: `Low chamber temperature: ${reading.temp.toFixed(1)} °C is below lower limit (${config.temp_min.toFixed(1)} °C).`
    });
    resolveAlertsByKind(db, { deviceId: device.id, kinds: ['high_temp'] });
  } else if (
    reading.temp <= config.temp_max - 0.3 &&
    reading.temp >= config.temp_min + 0.3
  ) {
    resolveAlertsByKind(db, { deviceId: device.id, kinds: ['high_temp', 'low_temp'] });
  }

  // Relative humidity threshold checks
  if (reading.humidity > rhMax) {
    await raiseAlertWithCooldown(db, {
      userId,
      deviceId: device.id,
      batchId,
      kind: 'high_humidity',
      message: `High relative humidity: ${reading.humidity.toFixed(1)}% exceeds allowed limit (${rhMax.toFixed(0)}% RH). Check door seal and desiccant.`
    });
    resolveAlertsByKind(db, { deviceId: device.id, kinds: ['low_humidity'] });
  } else if (reading.humidity < rhMin) {
    await raiseAlertWithCooldown(db, {
      userId,
      deviceId: device.id,
      batchId,
      kind: 'low_humidity',
      message: `Low relative humidity: ${reading.humidity.toFixed(1)}% is below allowed minimum (${rhMin.toFixed(0)}% RH).`
    });
    resolveAlertsByKind(db, { deviceId: device.id, kinds: ['high_humidity'] });
  } else if (reading.humidity <= rhMax - 1.5 && reading.humidity >= rhMin + 1.5) {
    resolveAlertsByKind(db, { deviceId: device.id, kinds: ['high_humidity', 'low_humidity'] });
  }
}

/**
 * Computes the 4-colour chamber status required by Section 11:
 * - grey: device offline or reading stale / missing
 * - red: limit exceeded or sensor fault
 * - amber: approaching limit, manual fan override active, or config sync pending
 * - green: within configured operating range
 */
export function computeVisualChamberStatus({
  isOnline,
  isStale,
  latestReading,
  config,
  rhMin,
  rhMax,
  configSynced
}) {
  if (!isOnline || isStale || !latestReading) {
    return {
      level: 'grey',
      label: !latestReading ? 'No Readings Yet' : 'Device Offline / Stale Data',
      detail: !latestReading
        ? 'Waiting for ESP32 or Simulator telemetry on local Wi-Fi.'
        : 'Last reading is older than the live freshness window. Values shown are historical.'
    };
  }

  if (!latestReading.sensor_ok || latestReading.temp === null || latestReading.humidity === null) {
    return {
      level: 'red',
      label: 'Sensor Fault — Fallback Active',
      detail: 'DHT22 failed validation. Safe fallback circulation active; safe refrigeration cannot be guaranteed until sensor is restored.'
    };
  }

  const t = latestReading.temp;
  const h = latestReading.humidity;

  if (t > config.temp_max || t < config.temp_min || h > rhMax || h < rhMin) {
    const reasons = [];
    if (t > config.temp_max) reasons.push(`Temp ${t.toFixed(1)} °C > ${config.temp_max.toFixed(1)} °C`);
    if (t < config.temp_min) reasons.push(`Temp ${t.toFixed(1)} °C < ${config.temp_min.toFixed(1)} °C`);
    if (h > rhMax) reasons.push(`Humidity ${h.toFixed(1)}% > ${rhMax.toFixed(0)}%`);
    if (h < rhMin) reasons.push(`Humidity ${h.toFixed(1)}% < ${rhMin.toFixed(0)}%`);
    return {
      level: 'red',
      label: 'Operating Limit Exceeded',
      detail: reasons.join(' · ')
    };
  }

  const nearTempLimit = t >= config.temp_max - 0.8 || t <= config.temp_min + 0.8;
  const nearRhLimit = h >= rhMax - 2.5 || h <= rhMin + 2.5;

  if (nearTempLimit || nearRhLimit || config.control_mode === 'manual' || !configSynced) {
    const notes = [];
    if (nearTempLimit) notes.push('Temperature approaching boundary');
    if (nearRhLimit) notes.push('Humidity approaching boundary');
    if (config.control_mode === 'manual') notes.push('Manual fan override active');
    if (!configSynced) notes.push('Waiting for ESP32 config acknowledgement');
    return {
      level: 'amber',
      label: 'Attention / Advisory',
      detail: notes.join(' · ')
    };
  }

  return {
    level: 'green',
    label: 'Nominal Operating Range',
    detail: 'Temperature, relative humidity, and device heartbeat are within target limits.'
  };
}
